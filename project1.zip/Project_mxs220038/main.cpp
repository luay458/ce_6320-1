#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
#include <climits>
#include <cctype>
#include <algorithm>


#define MAX_LINE_LENGTH 2000000
#define MAX_INPUTS 10000000
#define MAX_NODES 10000000

struct Gate {
    std::string name;
    std::vector<std::string> inputs;
    int numInputs;
};

struct PathNode {
    int index;
    int delay;
};

struct Path {
    std::vector<PathNode> path;
    int length;
};

struct Graph {
    int numNodes;
    std::vector<std::vector<int>> adjMatrix;
    std::vector<int> delays;
};

int firstIndex = 0;

// Function declarations
void printGate(const Gate& gate);
void freeGates(std::vector<Gate>& gates);
std::string strtrim(std::string str);
int findGateIndexByName(const std::vector<Gate>& gates, const std::string& name,const std::string& direction);
Graph createGraph(const std::vector<Gate>& gates);
void freeGraph(Graph& graph);
std::vector<int> calculateFanouts(const Graph& graph);
Path dijkstra(const Graph& graph, int startIdx, int endIdx);
void printShortestPath(const Path& path, const std::vector<Gate>& gates);

// Implementation of the function to trim leading and trailing spaces
std::string strtrim(std::string str) {
    size_t start = str.find_first_not_of(" \t\n\r\f\v");
    size_t end = str.find_last_not_of(" \t\n\r\f\v");
    if (start != std::string::npos && end != std::string::npos) {
        return str.substr(start, end - start + 1);
    }
    return "";
}

// Implementation of the function to print the gate and its inputs
void printGate(const Gate& gate) {
    std::cout << "Gate: " << gate.name << ", NumInputs: " << gate.numInputs << std::endl;
    for (int i = 0; i < gate.numInputs; ++i) {
        std::cout << "  Input[" << i << "]: " << gate.inputs[i] << std::endl;
    }
}

// Implementation of the function to free memory allocated for gates
void freeGates(std::vector<Gate>& gates) {
    for (auto& gate : gates) {
        gate.inputs.clear();
    }
    gates.clear();
}


int findGateIndexByName(const std::vector<Gate>& gates, const std::string& name, const std::string& direction) {
    std::string trimmedName = strtrim(name);
	std::string Direction = direction;
    if(Direction == "FORWARD"){
		for (int i = 0; i < gates.size(); ++i) {
            	if (gates[i].name.compare(0, trimmedName.length(), trimmedName) == 0) {
                	return i;
            		}
        	}
	}else if(Direction =="BACKWARD"){
		for (int i = gates.size() - 1; i >= 0; --i) {
            	if (gates[i].name.compare(0, trimmedName.length(), trimmedName) == 0) {
                	return i;
            		}
        	}
	}else{
		return -1;
	}
}
int findGateIndexByNameReverse(const std::vector<Gate>& gates, const std::string& name) {
    std::string trimmedName = strtrim(name);
    /*if (trimmedName.find("INPUT") != std::string::npos || trimmedName.find("OUTPUT") != std::string::npos) {
        for (int i = gates.size() - 1; i >= 0; --i) {
            if (gates[i].name == trimmedName) {
                return i;
            }
        }
    }*/
 //else{
        for (int i = gates.size() - 1; i >= 0; --i) {
            if (gates[i].name.compare(0, trimmedName.length(), trimmedName) == 0) {
                return i;
            }
        }
    
    return -1; // Signal not found
}


// Modify the calculateFanouts function to return the fanouts array
std::vector<int> calculateFanouts(const Graph& graph) {
    std::vector<int> fanouts(graph.numNodes, 0);
    for (int i = 1; i < graph.numNodes; ++i) {
        int fanoutCount = 0;
        for (int j = 0; j < graph.numNodes; ++j) {
            if (graph.adjMatrix[i][j] == 1) {
                fanoutCount++;
            }
        }
        fanouts[i] = fanoutCount;
    }
    return fanouts;
}

Graph createGraph(const std::vector<Gate>& gates) {
    Graph graph;
    graph.numNodes = gates.size();
    graph.adjMatrix.resize(graph.numNodes, std::vector<int>(graph.numNodes, 0));
    graph.delays.resize(graph.numNodes, 0);
	std::string Forward;
	Forward="FORWARD";
    // Populate adjacency matrix
    for (int i = 0; i < graph.numNodes; ++i) {
        for (int j = 0; j < gates[i].numInputs; ++j) {
            int inputIndex = findGateIndexByName(gates, gates[i].inputs[j],Forward);
            if (inputIndex != -1) {
                graph.adjMatrix[inputIndex][i] = 1; // There's a connection from input to output
            }
        }
    }
    // Calculate fanouts
    std::vector<int> fanouts = calculateFanouts(graph);
    // Update delays based on fanouts
    for (int i = 0; i < graph.numNodes; ++i) {
        graph.delays[i] = fanouts[i];
    }
    return graph;
}

// Implementation of Dijkstra's algorithm to find the shortest path
Path dijkstra(const Graph& graph, int startIdx, int endIdx) {
    Path path;
    path.length = 0;
    std::vector<int> distances(graph.numNodes, INT_MAX);
    std::vector<int> visited(graph.numNodes, 0);
    std::vector<PathNode> pathNodes(graph.numNodes);
    // Set distance of the start node to 0
    distances[startIdx] = 0;
    for (int i = 1; i <= graph.numNodes; ++i) {
        distances[i] = INT_MAX;
    }
    distances[startIdx] = 0;
    int iteration = 0;
    while (iteration < graph.numNodes) {
        int minDistance = INT_MAX;
        int currentIdx = -1;
        // Find the unvisited node with the smallest distance
        for (int j = 0; j < graph.numNodes; ++j) {
            if (!visited[j] && distances[j] < minDistance) {
                minDistance = distances[j];
                currentIdx = j;
            }
        }
        if (currentIdx == -1) {
            // No unvisited node found
            break;
        }
        visited[currentIdx] = 1;
        // Update distances for adjacent nodes
        for (int j = 0; j < graph.numNodes; ++j) {
            if (!visited[j] && graph.adjMatrix[currentIdx][j] &&
                (distances[currentIdx] != INT_MAX &&
                 (distances[currentIdx] + graph.delays[j] < distances[j] || distances[j] == INT_MAX))) {
                distances[j] = distances[currentIdx] + graph.delays[j];
                pathNodes[j].index = currentIdx;
                pathNodes[j].delay = distances[j];
            }
        }
        iteration++;
    }
    // Backtrack to construct the path
    int currentIdx = endIdx;
    while (currentIdx != startIdx) {
        path.path.push_back(pathNodes[currentIdx]);
        path.length++;
        currentIdx = pathNodes[currentIdx].index;
    }
    // Reverse the path
    std::reverse(path.path.begin(), path.path.end());
    return path;
}

void printShortestPath(const Path& path, const std::vector<Gate>& gates) {
    if (path.path[path.length].delay != INT_MAX) {
        std::cout << "Delay for the Shortest Path: " << path.path[path.length].delay << std::endl;
        std::cout << "Shortest Path:" << std::endl;
        if (path.length == -1) {
            std::cout << "  No path found" << std::endl;
            return;
        }
        //std::cout << gates[firstIndex].name << " --> ";
        for (int i = 2; i <= path.length; ++i) {
            int gateIndex = path.path[i].index;
            std::cout << gates[gateIndex].name;
            if (i < path.length) {
                std::cout << " , ";
            }
        }
        std::cout << std::endl;
    } else {
        std::cout << "Total delay: INFINITY" << std::endl;
        std::cout << "Shortest Path: NOT FOUND" << std::endl;
    }
}

// Function to free memory allocated for the graph
void freeGraph(Graph& graph) {
    graph.adjMatrix.clear();
    graph.delays.clear();
}

int main(int argc, char* argv[]) {
    Path path;
    int totalDelay;

    if (argc != 4) {
        std::cout << "Incorrect number of arguments" << std::endl;
        return 1;
    }

    std::ifstream file(argv[1]);
    if (!file) {
        std::cout << "Wrong file name" << std::endl;
        return 1;
    }

    std::string line;
	std::string Forward; 
	std::string Backward;
	Forward="FORWARD";
	Backward="BACKWARD";
    
    int numGates = 0;
    std::vector<Gate> gates;

    while (std::getline(file, line)) {
        if (line[0] == '#') {
            continue;
        }
        if (line.find("=") != std::string::npos || line.find("INPUT") != std::string::npos || line.find("OUTPUT") != std::string::npos) {
            size_t openParenthesis = line.find('(');
            size_t equalSign = line.find('=');

            if (line.find("INPUT") != std::string::npos) {
                std::string inputName = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                gates.push_back({inputName, {}, 0});
                numGates++;
            } else if (line.find("OUTPUT") != std::string::npos) {
                std::string outputName = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                gates.push_back({outputName, {}, 0});
                numGates++;
            } else if (equalSign != std::string::npos) {
                std::string gateName = strtrim(line.substr(0, equalSign));
                std::string inputsBuffer = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                std::vector<std::string> inputs;
                size_t pos = 0;
                while ((pos = inputsBuffer.find(',')) != std::string::npos) {
                    std::string token = strtrim(inputsBuffer.substr(0, pos));
                    inputs.push_back(token);
                    inputsBuffer.erase(0, pos + 1);
                }
                inputs.push_back(strtrim(inputsBuffer));
                gates.push_back({gateName, inputs, static_cast<int>(inputs.size())});
                numGates++;
            }
        }
    }
    file.close();

    int startIdx = findGateIndexByName(gates, argv[2],Forward);
    int verifyStartIdx = findGateIndexByName(gates, argv[2],Backward);
    firstIndex = startIdx;
    int endIdx = findGateIndexByName(gates, argv[3],Backward);
    int verifyEndIdx = findGateIndexByName(gates, argv[3],Forward);

    if (verifyStartIdx == -1) {
        std::cout << "Signal " << argv[2] << " not found in file " << argv[1] << std::endl;
        return 1;
    }
    if (verifyEndIdx == -1) {
        std::cout << "Signal " << argv[3] << " not found in file " << argv[1] << std::endl;
        return 1;
    }
    if (startIdx > verifyEndIdx) {
        std::cout << "Signal " << argv[2] << " is not an input pin" << std::endl;
        return 1;
    }

    Graph graph = createGraph(gates);
    Path shortestPath = dijkstra(graph, startIdx, endIdx);

    if (shortestPath.path.empty() || shortestPath.path[0].delay == INT_MAX) {
        std::cout << "Delay for Shortest Path: INFINITY" << std::endl;
        std::cout << "Shortest Path: NOT FOUND" << std::endl;
    } else {
        std::cout << "Delay: " << shortestPath.path.back().delay << std::endl;
        std::cout << "Shortest Path:" << std::endl;
        for (const auto& node : shortestPath.path) {
            int gateIndex = node.index;
            std::cout << gates[gateIndex].name;
            if (&node != &shortestPath.path.back()) {
                std::cout << " ,";
            }
        }
	std::cout << " , "<<argv[3]<<"\n";
        std::cout << std::endl;
    }

    freeGates(gates);
    freeGraph(graph);
    return 0;
}




