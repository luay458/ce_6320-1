// Include necessary header files
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <limits>
#include <algorithm>

// Define constants for maximum line length, maximum inputs, and custom data structures
#define MAX_LINE_LENGTH 2000
#define MAX_INPUTS 10000

// Define a structure to represent a logic gate
struct LogicGate {
    std::string gateName;      // Name of the logic gate
    std::vector<std::string> inputNames;   // Vector of input names
    int numInputs;       // Number of inputs
};

// Define a structure to represent a node in the shortest path
struct PathNode {
    int nodeIndex;       // Index of the node
    int nodeDelay;       // Delay associated with the node
};

// Define a structure to represent a path in the logic graph
struct Path {
    std::vector<PathNode> path;      // Vector of path nodes
    int length;          // Length of the path
};

// Define a structure to represent a logic graph
struct LogicGraph {
    int numNodes;        // Number of nodes (logic gates)
    std::vector<std::vector<int>> adjacencyMatrix; // Adjacency matrix representing connections between nodes
    std::vector<int> delays;         // Vector to store delays associated with nodes
};

// Function declarations
std::string customStrDup(const std::string& s);                          // Duplicate a string
std::string trimString(const std::string& str);                                // Trim leading and trailing spaces in a string
void printLogicGate(const LogicGate& gate);                 // Print information about a logic gate
void freeLogicGates(std::vector<LogicGate>& gates);         // Free memory allocated for logic gates
int findGateIndexByName(const std::vector<LogicGate>& gates, const std::string& name); // Find gate index by name
int findGateIndexByNameReverse(const std::vector<LogicGate>& gates, const std::string& name); // Find gate index by name in reverse order
LogicGraph createLogicGraph(const std::vector<LogicGate>& gates); // Create a logic graph from gates
void freeLogicGraph(LogicGraph& graph);                      // Free memory allocated for a logic graph
std::vector<int> calculateFanouts(const LogicGraph& graph);              // Calculate fanouts for nodes in a logic graph
Path dijkstraShortestPath(const LogicGraph& graph, int startIdx, int endIdx); // Find the shortest path using Dijkstra's algorithm
void printShortestPath(const Path& path, const std::vector<LogicGate>& gates); // Print the shortest path and associated information

// Implementation of the custom string duplication function
std::string customStrDup(const std::string& s) {
    return s;
}

// Implementation of the function to trim leading and trailing spaces in a string
std::string trimString(const std::string& str) {
    std::string trimmedStr = str;
    // Trim leading spaces
    trimmedStr.erase(0, trimmedStr.find_first_not_of(" \t\n\r\f\v"));
    // Trim trailing spaces
    trimmedStr.erase(trimmedStr.find_last_not_of(" \t\n\r\f\v") + 1);
    return trimmedStr;
}

// Implementation of the function to print information about a logic gate
void printLogicGate(const LogicGate& gate) {
    std::cout << "Logic Gate: " << gate.gateName << ", NumInputs: " << gate.numInputs << std::endl;
    for (int i = 0; i < gate.numInputs; ++i) {
        std::cout << "  Input[" << i << "]: " << gate.inputNames[i] << std::endl;
    }
}

// Implementation of the function to free memory allocated for logic gates
void freeLogicGates(std::vector<LogicGate>& gates) {
    for (auto& gate : gates) {
        gate.inputNames.clear();
    }
    gates.clear();
}

// Implementation of the function to find the index of a gate by name (updated for exact match)
int findGateIndexByName(const std::vector<LogicGate>& gates, const std::string& name) {
    // Trim leading and trailing spaces from the specified name
    std::string trimmedName = trimString(name);
    // Check if the name corresponds to an input or output
    if (trimmedName.find("INPUT") != std::string::npos || trimmedName.find("OUTPUT") != std::string::npos) {
        // For input/output names, search for an exact match
        for (int i = 0; i < gates.size(); ++i) {
            if (gates[i].gateName == trimmedName) {
                return i;
            }
        }
    } else {
        // For gate names, check for a prefix match
        for (int i = 0; i < gates.size(); ++i) {
            if (gates[i].gateName.find(trimmedName) == 0) {
                return i;
            }
        }
    }
    return -1; // Signal not found
}

// Implementation of the reverse search function to find the index of a gate by name
int findGateIndexByNameReverse(const std::vector<LogicGate>& gates, const std::string& name) {
    // Trim leading and trailing spaces from the specified name
    std::string trimmedName = trimString(name);
    // Check if the name corresponds to an input or output
    if (trimmedName.find("INPUT") != std::string::npos || trimmedName.find("OUTPUT") != std::string::npos) {
        // For input/output names, search for an exact match starting from the end
        for (int i = gates.size() - 1; i >= 0; --i) {
            if (gates[i].gateName == trimmedName) {
                return i;
            }
        }
    } else {
        // For gate names, check for a prefix match starting from the end
        for (int i = gates.size() - 1; i >= 0; --i) {
            if (gates[i].gateName.find(trimmedName) == 0) {
                return i;
            }
        }
    }
    return -1; // Signal not found
}

// Modify the calculateFanouts function to return the fanouts vector
std::vector<int> calculateFanouts(const LogicGraph& graph) {
    std::vector<int> fanouts(graph.numNodes, 0);
    // Traverse each column of the adjacency matrix
    for (int j = 0; j < graph.numNodes; ++j) {
        for (int i = 0; i < graph.numNodes; ++i) {
            if (graph.adjacencyMatrix[i][j] == 1) {
                fanouts[i]++;
            }
        }
    }
    return fanouts;
}

// Implementation of the function to create a logic graph from logic gates
LogicGraph createLogicGraph(const std::vector<LogicGate>& gates) {
    LogicGraph graph;
    graph.numNodes = gates.size();
    graph.adjacencyMatrix.resize(graph.numNodes, std::vector<int>(graph.numNodes, 0));
    graph.delays.resize(graph.numNodes, 0);
    // Populate adjacency matrix
    for (int i = 0; i < graph.numNodes; ++i) {
        for (int j = 0; j < gates[i].numInputs; ++j) {
            int inputIndex = findGateIndexByName(gates, gates[i].inputNames[j]);
            if (inputIndex != -1) {
                graph.adjacencyMatrix[inputIndex][i] = 1; // There's a connection from input to output
            }
        }
    }
    // Calculate fanouts
    std::vector<int> fanouts = calculateFanouts(graph);
    // Update delays based on fanouts
    for (int i = 0; i < graph.numNodes; ++i) {
        graph.delays[i] = fanouts[i];
    }
    return graph;
}

// Implementation of Dijkstra's algorithm to find the shortest path
Path dijkstraShortestPath(const LogicGraph& graph, int startIdx, int endIdx) {
    Path path;
    path.length = 0;
    std::vector<int> distances(graph.numNodes, std::numeric_limits<int>::max());
    std::vector<int> visited(graph.numNodes, 0);
    // Set distance of the start node to 0
    distances[startIdx] = 0;
    int iteration = 0;
    while (iteration < graph.numNodes) {
        int minDistance = std::numeric_limits<int>::max();
        int currentIdx = -1;
        // Find the unvisited node with the smallest distance
        for (int j = 0; j < graph.numNodes; ++j) {
            if (!visited[j] && distances[j] < minDistance) {
                minDistance = distances[j];
                currentIdx = j;
            }
        }
        if (currentIdx == -1) {
            // No unvisited node found
            break;
        }
        visited[currentIdx] = 1;
        // Update distances for adjacent nodes
        for (int j = 0; j < graph.numNodes; ++j) {
            if (!visited[j] && graph.adjacencyMatrix[currentIdx][j] &&
                (distances[currentIdx] != std::numeric_limits<int>::max() &&
                 (distances[currentIdx] + graph.delays[j] < distances[j] || distances[j] == std::numeric_limits<int>::max()))) {
                distances[j] = distances[currentIdx] + graph.delays[j];
                PathNode node;
                node.nodeIndex = currentIdx;
                node.nodeDelay = distances[j];
                path.path.push_back(node);
            }
        }
        iteration++;
    }
    // Backtrack to construct the path
    int currentIdx = endIdx;
    while (currentIdx != startIdx) {
        PathNode node;
        node.nodeIndex = currentIdx;
        node.nodeDelay = distances[currentIdx];
        path.path.push_back(node);
        currentIdx = path.path[path.length].nodeIndex;
    }
    // Reverse the path
    std::reverse(path.path.begin(), path.path.end());
    // Update the path length
    path.length = path.path.size() - 1;
    return path;
}

// Function to print the shortest path and associated information
void printShortestPath(const Path& path, const std::vector<LogicGate>& gates) {
    if (path.path[path.length].nodeDelay != std::numeric_limits<int>::max()) {
        std::cout << "Total delay: " << path.path[path.length].nodeDelay << std::endl;
        std::cout << "Shortest Path:" << std::endl;
        if (path.length == -1) {
            std::cout << "  No path found" << std::endl;
            return;
        }
        std::cout << gates[0].gateName << " --> "; // Assuming gates[0] is the first gate
        for (int i = 1; i <= path.length; ++i) {
            int gateIndex = path.path[i].nodeIndex;
            std::cout << gates[gateIndex].gateName;
            if (i < path.length) {
                std::cout << " --> ";
            }
        }
        std::cout << std::endl;
    } else {
        std::cout << "Total delay: INFINITY" << std::endl;
        std::cout << "Shortest Path: NOT FOUND" << std::endl;
    }
}

// Function to free memory allocated for the graph
void freeLogicGraph(LogicGraph& graph) {
    graph.adjacencyMatrix.clear();
    graph.delays.clear();
}

// Main function
int main(int argc, char* argv[]) {
    // Check the number of arguments
    if (argc != 4) {
        std::cout << "Incorrect number of arguments" << std::endl;
        return 1;
    }
    // Open the benchmark file for reading
    std::ifstream file(argv[1]);
    if (!file) {
        std::cerr << "Wrong file name" << std::endl;
        return 1;
    }
    // Variables to store the gate and its inputs
    std::string line;
    int numGates = 0;
    std::vector<LogicGate> gates;
    // Inside the main function (modified)
    while (std::getline(file, line)) {
        // Skip lines starting with "#"
        if (line[0] == '#') {
            continue;
        }
        // Check if the line contains a gate assignment or INPUT/OUTPUT
        if (line.find("=") != std::string::npos || line.find("INPUT") != std::string::npos || line.find("OUTPUT") != std::string::npos) {
            // Find the position of '(' or '='
            size_t openParenthesis = line.find('(');
            size_t equalSign = line.find('=');
            // Check if it is an INPUT line
            if (line.find("INPUT") != std::string::npos) {
                // Extract the input name and add it to the list of gates
                std::string inputName = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                LogicGate inputGate;
                inputGate.gateName = inputName;
                inputGate.numInputs = 0;
                gates.push_back(inputGate);
                numGates++;
            }
            // Check if it is an OUTPUT line
            else if (line.find("OUTPUT") != std::string::npos) {
                // Extract the output name and add it to the list of gates
                std::string outputName = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                LogicGate outputGate;
                outputGate.gateName = outputName;
                outputGate.numInputs = 0;
                gates.push_back(outputGate);
                numGates++;
            }
            // Otherwise, it is a regular gate assignment
            else if (equalSign != std::string::npos) {
                // Extract the gate name
                std::string gateName = trimString(line.substr(0, equalSign));
                // Extract the inputs
                std::string inputsBuffer = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                std::vector<std::string> inputNames;
                size_t pos = 0;
                while ((pos = inputsBuffer.find(',')) != std::string::npos) {
                    std::string token = trimString(inputsBuffer.substr(0, pos));
                    inputNames.push_back(token);
                    inputsBuffer.erase(0, pos + 1);
                }
                inputNames.push_back(trimString(inputsBuffer));
                // Create a new logic gate
                LogicGate gate;
                gate.gateName = gateName;
                gate.inputNames = inputNames;
                gate.numInputs = inputNames.size();
                gates.push_back(gate);
                numGates++;
            }
        }
    }
    // Close the file
    file.close();
    // Find start and end gate indices
    int startIdx = findGateIndexByName(gates, argv[2]);
    int verifyStartIdx = findGateIndexByNameReverse(gates, argv[2]);
    int endIdx = findGateIndexByNameReverse(gates, argv[3]);
    int verifyEndIdx = findGateIndexByName(gates, argv[3]);
    // Check if the start and end gates are inputs and outputs, respectively
    if (verifyStartIdx == -1) {
        std::cerr << "Signal " << argv[2] << " not found in file " << argv[1] << std::endl;
        freeLogicGates(gates);
        return 1;
    }
    if (verifyEndIdx == -1) {
        std::cerr << "Signal " << argv[3] << " not found in file " << argv[1] << std::endl;
        freeLogicGates(gates);
        return 1;
    }
    // Check if the start and end locations are reversed
    if (startIdx > verifyEndIdx) {
        std::cerr << "Signal " << argv[2] << " is not an input pin" << std::endl;
        freeLogicGates(gates);
        return 1;
    }
    // Create a graph from gates
    LogicGraph graph = createLogicGraph(gates);
    // Apply Dijkstra's algorithm
    Path shortestPath = dijkstraShortestPath(graph, startIdx, endIdx);
    // Print the shortest path
    printShortestPath(shortestPath, gates);
    // Free allocated memory
    freeLogicGates(gates);
    freeLogicGraph(graph);
    return 0;
}


