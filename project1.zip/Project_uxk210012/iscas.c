// This code implements CS6320 Project. By Uthama Kadengodlu (UXK210012)

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "limits.h"

#define MAX 1000

struct CE6320
{
    char Node_name[15];							                // Holds current Node Name
    char Fanin_NodeName[20][15];				                // Holds Fan-in node names of current node
    char Fanout_NodeName[80][15];				                // Holds Fan-out node names of current node
    int Node_index;								       			// Holds current node index
    int Fanin_Count;							                // Holds fan-in count of current node
    int Fanin_NodeIndex[20];					                // Holds index of fan-in nodes of current node
    int Fanout_Count;							                // Holds Fan-out count of current node
    int Fanout_NodeIndex[80];					                // Holds index of fan-out nodes of current node
    int node_type;								        		// Indicates if node is input, output or interior
};

struct CE6320 *iscas = NULL;					                // Instance of structure CE6320

char line[MAX];									                // Holds characters of a line present in file

int **array = NULL;								                // Adjacency matrix
int Total_gate = 0;             				                // Holds Total count of Gates
int input_node = -1;							                // Holds the index of input node requested
int output_node = -1;							                // Holds the index of output node requested


void validity_check(int arg_count, char *arg[]);
void gate_total(char *arg[]);
void extract(char *arg[]);
void fanout(void);
void matrix(void);
void print_path(int delay[], int *previous, int destination);
void dijkstra(int start, int *delay, int *previous);


// This function checks for the validity of the command passed to the executable
void validity_check(int arg_count, char *arg[])
{
    FILE *fp;                       			                // File pointer to read input file
    int isInputGate = 0;            			                // Flag to indicate validity of input pin
    int isOutputGate = 0;           			                // Flag to indicate validity of output pin
    int inputposwrong = 0;                                      // Flag to indicate if input is in wrong position
    int outputposwrong = 0;                                     // Flag to indicate if output is in wrong position

    //Check for command count validity of 4
    if(arg_count !=4)
    {
        printf("Incorrect number of arguments\n");
        exit(0);
    }

    fp = fopen(arg[1], "r");        			                // Open the file in read mode

    //Check if file is present
    if(fp == NULL)
    {
        printf("Wrong file name\n");
        exit(1);
    }

    // Read file line by line
    while (fgets(line, MAX, fp))
    {
        // Check for INPUT pin
        if (strncmp(line,"INPUT(", 6) == 0)
        {
            // Tokenize the line starting after "INPUT(" and before ")"
            char *pinName = strtok(line + 6, ")\n");
            // This line is an input gate
            if (strcmp(pinName, arg[2]) == 0)
            {
                isInputGate = 1;                                // Input gate is correct
            }
            // Check if Input pin is in 4th position of command
            if (strcmp(pinName, arg[3]) ==0)
            {
                isInputGate = 1;                                // Input gate is correct
                inputposwrong = 1;                              // Input gate position is wrong
            }
            pinName = NULL; 									// Clear the pointer
        }

        //Check for OUTPUT pin
        if (strncmp(line,"OUTPUT(", 7) == 0)
        {
            // Tokenize the line starting after "INPUT(" and before ")"
            char *pinName = strtok(line + 7, ")\n");
            // This line is an output gate
            if (strcmp(pinName, arg[3]) == 0)
            {
                isOutputGate = 1;                               // Output gate is correct
            }
            // Check if Output pin is in 3rd position of command
            if (strcmp(pinName, arg[2]) == 0)
            {
                isOutputGate = 1;                               // Output gate is correct
                outputposwrong = 1;                             // Output gate position is wrong
            }
            pinName = NULL; 
        }
    }

    // INPUT Pin not found
    if (!isInputGate && !outputposwrong)
    {
        printf("Signal %s not found in file %s\n", arg[2], arg[1]);
        fclose(fp);                                             // Close the file
        exit(0);                                                // Exit the executable
    }
    //OUTPUT Pin not found
    else if (!isOutputGate && !inputposwrong)
    {
        printf("Signal %s not found in file %s\n", arg[3], arg[1]);
        fclose(fp);                                             // Close the file
        exit(0);                                                // Exit the executable
    }
    // INPUT and OUTPUT Pin are correct
    else
    {
        if(isInputGate && isOutputGate)
        {
            if(strcmp(arg[2],arg[3])==0)
            {
                // Input and output are same node
                printf("Distance is 0. No shortest path from node to itself\n");
                fclose(fp);                                     // Close the file
                exit(1);
            }
            else if(inputposwrong && outputposwrong)
            {
                // Signal in position 3 is not input pin
                printf("Signal %s is not input pin\n",arg[2]);
                fclose(fp);                                     // Close the file
                exit(0);
            }
        }
        else
        {
            if(outputposwrong && !inputposwrong)
            {
                // Signal in position 4 is not output pin
                printf("Signal %s is not input pin\n",arg[2]);
                fclose(fp);                                     // Close the file
                exit(0);
            }
            if(inputposwrong && !outputposwrong)
            {
                // Signal in position 3 is not input pin
                printf("Signal %s is not output pin\n",arg[3]);
                fclose(fp);                                     // Close the file
                exit(0);
            }
        }
    }
}

// This function gets the count of total nodes present in the file
void gate_total(char *arg[])
{
    int value = 0;                  			                // Holds value obtained from reading required line
    int IP_Gate = 0;                			                // Holds number of Input Gates
    int OP_Gate = 0;                			                // Holds number of OUTPUT Gates
    int IT_Gate = 0;                			                // Holds number of Interior Gates

    FILE *fp;                       			                // File pointer to read input file
    fp = fopen(arg[1], "r");        			                // Open the file in read mode

    // Read characters line by line
    while(fgets(line,MAX,fp))
    {
        // Extract number of input gates
        if(strstr(line, "lines from primary input  gates .......")!=NULL)
        {
            if(sscanf(line,"#         lines from primary input  gates .......     %d", &value) == 1)
            {
                IP_Gate = value;                                // Input nodes
            }
        }
		// Extract number of output gates
        else if(strstr(line, "lines from primary output gates .......")!=NULL)
        {
            if(sscanf(line,"#         lines from primary output gates .......     %d", &value) == 1)
            {
                OP_Gate = value;                                // Output nodes
            }
        }
		// Extract number of interior gates
        else if(strstr(line, "lines from interior gate outputs ......")!=NULL)
        {
            if(sscanf(line,"#         lines from interior gate outputs ......     %d", &value) == 1)
            {
                IT_Gate = value;                                // Interior nodes
            }
        }
        else
        {
            // Do Nothing
        }
    }

	Total_gate = IP_Gate + OP_Gate + IT_Gate;                   // Get total count of gate

    fclose(fp);                                                 // Close the file
}

// This function extracts the node information from the file
void extract(char *arg[])
{
    int Fanin_PointIndex;										// Points to the index of Fan-in node
	int loop_count = 0;											// Variable used for node index count
	
    FILE *fp;                       							// File pointer to read input file
    fp = fopen(arg[1], "r");        							// Open the file in read mode

    while (fgets(line, MAX, fp))								// Read file line by line
    {
        Fanin_PointIndex = 0;									// Index variable representing position in Fan-in Nodename variable
		
		// Check for Input Pins and extract
        if (strncmp(line, "INPUT(", 6) == 0)					// Check if line starts from "INPUT("
        {
			// Tokenize the line starting after "INPUT(" and before new line to get node name
            char *pinName = strtok(line + 6, ")\n");
			
			// Copy the node name
            strcpy(iscas[loop_count].Node_name, pinName);
			
			// Copy Fan-in name as "Input"
            strcpy(iscas[loop_count].Fanin_NodeName[Fanin_PointIndex], "INPUT");
			
			// Copy loop count as node index
            iscas[loop_count].Node_index = loop_count;
			
			// Keep fan-in count as 1 for INPUT
            iscas[loop_count].Fanin_Count = 1;
			
			// Node type as 1 for INPUT
            iscas[loop_count].node_type = 1;
            loop_count++;										// Increment node index
            pinName = NULL; 									// Clear the pointer
        }
        // Check for OUTPUT pins and extract
        else if (strncmp(line, "OUTPUT(", 7) == 0)              // Check if line starts from "OUTPUT("
        {
			// Tokenize the line starting after "OUTPUT(" and before new line to get node name
            char *pinName = strtok(line + 7, ")\n");
			
			// Copy the node name
            strcpy(iscas[loop_count].Node_name, pinName);
			
			// Copy loop count as node index
            iscas[loop_count].Node_index = loop_count;
			
			// Node type as 2 for OUTPUT
            iscas[loop_count].node_type = 2;
            loop_count++;										// Increment node index
            pinName = NULL; 									// Clear the pointer
        }
        
    }
    fclose(fp);													// Close the file

    fp = fopen(arg[1], "r");        							// Open the file in read mode
	
	// Check for interior gates
    while (fgets(line, MAX, fp))								// Read file line by line
    {
		int loop, temp;											// Loop and temporary variable
        Fanin_PointIndex = 0;									// Index variable representing position in Fan-in Nodename variable
        
		// Check if line starts from "G"
        if (strncmp(line, "G", 1) == 0)
        {
            char *gateName;										// Holds Gate Name
			char *gateFunction;									// Holds gate function name
			
			// Finds first occurence of "=" in the line
            char *equalSignPos = strstr(line, "=");

            // Check if the equal sign was found
            if (equalSignPos != NULL)
            {
                // Tokenize the line and copy Node name
                gateName = strtok(line, " =\n");
				
				// Get gate name after "=" sign
                gateFunction = equalSignPos + 1;
                temp = -1;										// Used to indicate if node is OUTPUT or not
				
				// Check if node is OUTPUT
                for(loop = 0; loop <= loop_count; loop++)
                {
                    if(strcmp(gateName,iscas[loop].Node_name)==0)
                    {
						// Node present in interior gate section is OUTPUT node
                        temp = loop_count;						// Store the Index of new node
                        loop_count = loop;						// Copy the already present node index
                    }
                    else
                    {
						// Node is not OUTPUT node and indicate its type sa interior node
                        iscas[loop_count].node_type = 3;
                    }
                }
				
				// Copy the node name
                strcpy(iscas[loop_count].Node_name, gateName);
				
				// Copy the node index
                iscas[loop_count].Node_index = loop_count;

                // Tokenize the gate function which has fan-in details. Delimiters are "(", ")", ",",space and newline
                char *token = strtok(gateFunction, "(), \n");
                while (token != NULL)
                {
					// Check if token starts from "G"
                    if (strncmp(token, "G", 1) == 0)
                    {
						// Copy the node name to Fan-in node name
                        strcpy(iscas[loop_count].Fanin_NodeName[Fanin_PointIndex], token);
                        
						// Get the node index of fan-in node by comparing the token with already stored details
						for(loop = 0; loop <= loop_count; loop++)
                        {
							// Check if fan-in node name matches with node name already stored
                            if(strcmp(token, iscas[loop].Node_name)==0)
                            {
								// MATCH. Get the node index and store it in fan-in node index
                                iscas[loop_count].Fanin_NodeIndex[Fanin_PointIndex] = iscas[loop].Node_index;
                            }
                        }
                        Fanin_PointIndex++;						// Increment the index
                    }
                    token = strtok(NULL, "(), \n");				// Tokenize further. Delimiters are "(", ")", ",",space and newline
                }
				
				// Get the total fan-in count
                iscas[loop_count].Fanin_Count = Fanin_PointIndex;
				
				// Get back the original node index value for interior gate from OUTPUT node index
                if(temp > -1)
                {
                    loop_count = temp;							// Restore original node index
                }
                else
                {
                    loop_count++;								// Already interior gate, increment node index
                }
                
                // Clear the pointers
                gateName = NULL;
                equalSignPos = NULL;
                gateFunction = NULL;
                token = NULL;
            }
            else
            {
                // Do Nothing
            }
        } 
    }

    fclose(fp);													// Close the file
}

// This function is used to get the fan-out details
void fanout(void)
{
    int loop1, loop2, loop3, fanout_index;						// Variables for various loops and index variable to store fan-out name

    // Check if node used as fan-in in other nodes
    for(loop1 = 0; loop1 < Total_gate; loop1++)
    {
        fanout_index = 0;

        // Node to be checked if used in outer loop node
        for(loop2 = 0 ; loop2 < Total_gate; loop2++)
        {
            loop3 = 0;

            // Iterate through multiple fan in present in Second loop node
            while(loop3 < iscas[loop2].Fanin_Count)
            {
                // Check if First loop node name matches with Fan in node stored in second loop node
                if(strcmp(iscas[loop1].Node_name, iscas[loop2].Fanin_NodeName[loop3]) == 0)
                {
                    // MATCH -> Get node name (fanout) and its index
                    strcpy(iscas[loop1].Fanout_NodeName[fanout_index],iscas[loop2].Node_name);
                    iscas[loop1].Fanout_NodeIndex[fanout_index] = iscas[loop2].Node_index;

                    // Increment the index to store next fanout index
                    fanout_index++;
                }

                // Increment to check through the multiple fan in in second loop node
                loop3++;
            }
        }
		
        // Store the fanout count in first loop node
        iscas[loop1].Fanout_Count = fanout_index;

        // If node is of OUTPUT type, store Fan-out as "OUTPUT" and fan-out count as 1.
		if(iscas[loop1].node_type == 2)
        {
            iscas[loop1].Fanout_Count = 1;
            strcpy(iscas[loop1].Fanout_NodeName[0], "OUTPUT");
        }
    }
}

// This function creates the adjacency matrix
void matrix(void)
{
	int loop1, loop2, temp;										// Multiple loop variables and temporary variable to store node index
	
	// Iterate through all gates
	for(loop1 = 0; loop1 < Total_gate; loop1++)
	{
		if(iscas[loop1].node_type != 2)
        {
			// Iterate through fan-out details of outer loop gate
			for(loop2 = 0; loop2 < iscas[loop1].Fanout_Count; loop2++)
			{
				// Get the fan-out index
				temp = iscas[loop1].Fanout_NodeIndex[loop2];
			
				// Go to the index and get the fan-out count which is to be stored as graph weight/ circuit delay
				array[loop1][temp] = iscas[temp].Fanout_Count;
			}
		}
	}
}

// This function implements Dijkstra's algorithm
void dijkstra(int start, int *delay, int *previous)
{
    int loop1, loop2, loop3, short_delay, weight;               // Variables for loop, smallest delay and weight
    int visited[Total_gate];									// Array to flag visited nodes

    for (loop1 = 0; loop1 < Total_gate; loop1++)
	{
        delay[loop1] = INT_MAX; 								// Initialize delay to Integer MAX (mimics INFINITY)
        previous[loop1] = -1;      								// Initialize previous nodes to -1
        visited[loop1] = 0;    									// Mark all nodes as not visited
    }

    delay[start] = 0; 											// Delay from the start node to itself is 0

    // Iterate through all the nodes to get the delay
	for (loop1 = 0; loop1 < Total_gate - 1; loop1++)
	{
		// Find the unvisited node with smallest delay
        short_delay = -1;										// Set smallest delay as -1 for this iteration
        for (loop2 = 0; loop2 < Total_gate; loop2++)
		{
			// Check if node is unvisited and delay is smaller than the previous smallest delay
            if (!visited[loop2] && (short_delay == -1 || delay[loop2] < delay[short_delay]))
			{
                short_delay = loop2;                            // Smaller delay found, store the index
            }
        }

        visited[short_delay] = 1;								// Set the index with smallest delay as visited

        for (loop3 = 0; loop3 < Total_gate; loop3++)
		{
			// Get the weight from the adjacency matrix for the node with smallest delay
            weight = array[short_delay][loop3];
			
			// Update the weights along with the previous weight
            if (weight != 0 && delay[short_delay] != INT_MAX && delay[short_delay] + weight < delay[loop3])
			{
				// Update weight and array containing previous node
                delay[loop3] = delay[short_delay] + weight;
                previous[loop3] = short_delay;
            }
        }
    }
}

// This function prints the delay and path
void print_path(int *delay, int *previous, int destination)
{

    int path[Total_gate];										// Store entire path for delay
    int pathIndex = 0;											// Path index to get entire path
    int current = destination;									// Store OUTPUT node index
	int loop, inf_flag = 0;										// Loop variable and infinity flag
	
	// Get the entire path traced back from required output to required input
    while (current != -1)
	{
        path[pathIndex] = current;								// Store the destination
        pathIndex++;											// Increment Index
        current = previous[current];							// Go back to the previous node
    }
	
    // Iterate through all node index to get desired node index
	for (loop = 0; loop < Total_gate; loop++)
	{
        if(output_node == loop)
        {
            // MATCH. Output node index found
            if(delay[loop] == INT_MAX)
            {
                // Since delay is Integer MAX, this means there is no path from input to output
                printf("Delay is INFINITY\n");
                inf_flag = 1;                                   // Set infinity flag
            }
            else
            {
                // Print the delay
                printf("Delay from Source is %d\n", delay[loop]);
            }
        }
    }
	
    // Check for infinity flag to get the path
    if(!inf_flag)
    {
        printf("Shortest path is:\n");

        // Last Index has the first element. Hence, iterate down
        for (loop = pathIndex - 1; loop >= 0; loop--)
	    {
            printf("%s ", iscas[path[loop]].Node_name);         // Print the path
        }
        printf("\n");
    }
	
}

int main(int argc, char *argv[])
{
    int loop;                                                   // Loop variable adjacency matrix allocation

    // Check for command validity
    validity_check(argc, argv);

    // Get total number of gates
    gate_total(argv);

    // Allocate memory for structure
    iscas = malloc(2 * Total_gate * sizeof(struct CE6320));

    // Initialize allocated memory as 0
    memset(iscas, 0, Total_gate * sizeof(struct CE6320));

    // Extract information
    extract(argv);

    // Get the fanout details
    fanout();
	
    // Allocate memory for first dimension of adjacency matrix array 
	array = malloc(Total_gate * sizeof(int *));

    for (loop = 0; loop < Total_gate; loop++)
    {
        // Allocate memory for second dimension of adjacency matrix array
        array[loop] = malloc(Total_gate * sizeof(int));

        // Initialize memory allocation with 0
        memset(array[loop], 0, Total_gate * sizeof(int));
    }

    // Create adjacency matrix
	matrix();

    // Get the index of input and output
    for(loop = 0; loop < Total_gate; loop++)
    {
        if(strcmp(argv[2],iscas[loop].Node_name)==0)
        {
            input_node = iscas[loop].Node_index;
        }
        else if(strcmp(argv[3],iscas[loop].Node_name)==0)
        {
            output_node = iscas[loop].Node_index;
            break;
        }
        else
        {
            // Do nothing
        }
    }

    int delay[Total_gate];                                      // Holds the entire delay
    int previous[Total_gate];                                   // Holds the previous node delay

    // Executed Dijkstra's algorithm to get the shortest path
    dijkstra(input_node, delay, previous);

    // Prints the delay and path
    print_path(delay, previous, output_node);

    // Clear Memories for adjacent matrix and structure instance
    for (loop = 0; loop < Total_gate; loop++)
    {
        free(array[loop]);
    }
    free(array);
    free(iscas);

    return 0;
}
