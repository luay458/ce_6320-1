//ce6320 project Suryoun Lee (sxl190025)

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <limits>
#include <sstream>
#include <algorithm>

using namespace std;

typedef pair<int, int> pii;
const int MAX_NODES = 1000;
const int INF = numeric_limits<int>::max();
vector<pii> adj[MAX_NODES];

void dijkstra(int start, vector<int>& dist, vector<int>& prev) {
    priority_queue<pii, vector<pii>, greater<pii>> pq;
    pq.push(make_pair(0, start));
    dist[start] = 0;
    prev[start] = -1; 

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (dist[u] > 100) break; 

        for (size_t i = 0; i < adj[u].size(); ++i) {
            int v = adj[u][i].first;
            int weight = adj[u][i].second;

            if (dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                prev[v] = u; 
                pq.push(make_pair(dist[v], v));
            }
        }
    }
}

vector<int> reconstructPath(int start, int end, const vector<int>& prev) {
    vector<int> path;
    for (int at = end; at != -1; at = prev[at]) {
        path.push_back(at);
    }
    reverse(path.begin(), path.end());
    return path;
}

string getSignalNameFromNode(int node, const unordered_map<string, int>& signalToNode) {
    for (const auto& pair : signalToNode) {
        if (pair.second == node) {
            return pair.first;
        }
    }
    return "Unknown";
}

bool parseFile(const string& filename, unordered_set<string>& signals, unordered_map<string, int>& signalToNode) {
    ifstream file(filename);
    if (!file.is_open()) {
        return false;
    }

    string line;
    int nodeCounter = 0;
    unordered_map<string, int> gateFanout; 

    while (getline(file, line)) {
        if (line.empty() || line[0] == '#') continue; 

        stringstream ss(line);
        string token;
        ss >> token;

        if (token.find("INPUT") != string::npos || token.find("OUTPUT") != string::npos) {
            size_t start = line.find('(') + 1;
            size_t end = line.find(')');
            string signalName = line.substr(start, end - start);
            signals.insert(signalName);
            signalToNode[signalName] = nodeCounter++;
        } else {
            string gate = token;
            string equals, expression;
            ss >> equals >> expression;
            string connectedSignal = expression.substr(expression.find('(') + 1, expression.find(')') - expression.find('(') - 1);
            if (signalToNode.find(connectedSignal) == signalToNode.end()) {
                signalToNode[connectedSignal] = nodeCounter++;
            }
            gateFanout[connectedSignal]++;

            int delay = 1; 
            adj[signalToNode[connectedSignal]].push_back(make_pair(signalToNode[gate], delay)); 
        }
    }

    file.close();
    return true;
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cout << "Incorrect number of arguments" << endl;
        return 1;
    }

    string filename = argv[1];
    string inputSignal = argv[2];
    string outputSignal = argv[3];

    unordered_set<string> signals;
    unordered_map<string, int> signalToNode;

    if (!parseFile(filename, signals, signalToNode)) {
        cout << "File error: unable to open or parse file " << filename << endl;
        return 1;
    }

    if (signals.find(inputSignal) == signals.end() || signals.find(outputSignal) == signals.end()) {
        cout << "Signal " << (signals.find(inputSignal) == signals.end() ? inputSignal : outputSignal) << " not found in file " << filename << endl;
        return 1;
    }

    vector<int> dist(MAX_NODES, INF);
    vector<int> prev(MAX_NODES, -1);
    dijkstra(signalToNode[inputSignal], dist, prev);

    if (dist[signalToNode[outputSignal]] == INF) {
        cout << "No path from " << inputSignal << " to " << outputSignal << endl;
    } else {
        vector<int> path = reconstructPath(signalToNode[inputSignal], signalToNode[outputSignal], prev);
        cout << inputSignal << " -> " << outputSignal << " : Shortest path is : ";
        for (size_t i = 0; i < path.size(); i++) {
            cout << getSignalNameFromNode(path[i], signalToNode);
            if (i < path.size() - 1) cout << " -> ";
        }
        cout << " = " << dist[signalToNode[outputSignal]] << endl;
    }

    return 0;
}

