#include<iostream>
#include<fstream>
#include<string>
#include<map>
#include<list> 
#include<limits>
#include<algorithm> 
#include<vector>


using namespace std; 

struct myGates              
 {
    string type;            //Type of the node: can be INPUT, OUTPUT or GATE
    string nodeName;                                       
    int delay;             // Delay is the fanout of gates.
 };


list<myGates>nodes;       //List to store my nodes or gate names 

void printNodes()        //Function to print the List "nodes". 
    {
        for (const auto& node : nodes) 
            {
                cout<<node.nodeName<<" "<<node.delay<<" "<<node.type<<endl;  
            }
    }

class makeGraph
 {
    public:
    map<string,list<string>> adjacencyList;       //Mapping Gate names with a list of all outputs 

    void addConnectedNodes(const string& sourceNode, const string& destNode)
        {
            adjacencyList[sourceNode].push_back(destNode);  //Makes edge between input and outputs 
        }


    void delayCalculation()      //Function to calculate the delay of gates
        {
            for(auto &it : adjacencyList)
                {
                    const string &nodeName = it.first;                  //Get the node name 
                    list<string> &neighbor = it.second;                 //Get the list of neighbors 
                    int delay = static_cast<int>(neighbor.size());      //Get the delay as size of the list 
                    for(auto &gate: nodes)
                        {
                            if(gate.nodeName == nodeName)
                                {
                                    gate.delay = delay;        
                                    break; 
                                }
                        }
                }
        }


     void print()                     //This function to display the map adjacencyList 
        {
            for(const auto& pairs : adjacencyList)
                {
                    cout<<pairs.first;
                    for(const string& neighbor :pairs.second){
                        cout<<"--> "<<neighbor<<" "; 
                    }
                    cout<<endl; 
                }
            cout<<endl; 
        }

    int djikstraAlgo(const string& sourceGate, const string& destGate)
        {    
            list<pair<string, int>>unvisitedNodes;      //Stores all unvisited gates with name and delay 
            map<string, string> previousNode; 
            bool destinationReached = false;
            for (const auto& gate : nodes) {
                if (gate.type == "OUTPUT" || gate.type == "GATE") {
                    unvisitedNodes.push_back(std::make_pair(gate.nodeName, 9999)); //Stores all the gates with a delay of 9999
                    }
                }

            auto sourceNodeIt = find_if(nodes.begin(),nodes.end(),[sourceGate](const myGates& gate){
                return gate.nodeName==sourceGate;
            });
            
            if(sourceNodeIt != nodes.end()){
            unvisitedNodes.push_back(make_pair(sourceGate,sourceNodeIt->delay));   //Initialise the source node; 
             }
                            
            
            while(!unvisitedNodes.empty())
                {
                    auto minIt = min_element(unvisitedNodes.begin(), unvisitedNodes.end(),  //Compairs and finds the node with lesser delay 
                    [](const pair<string, int>& a, const pair<string, int>& b) {                     
                        return a.second < b.second;
                    });
                    
                    auto currentNode = *minIt;  
                    unvisitedNodes.erase(minIt);                      
                    
                    if (currentNode.first == destGate) 
                        {   if(currentNode.second == 9999){
                                cout<< "Shortest distance: INFINITY"<< endl; 
                                return -1;   
                                }  

                            else
                                {               
                                   	int distance = currentNode.second;
                                        vector<string> path;
                                        string current = destGate;

                                        while (current != sourceGate)
                                            {
                                                path.push_back(current);
                                                current = previousNode[current];
                                            }

                                        path.push_back(sourceGate);
                                        reverse(path.begin(), path.end());

                                        cout << "Shortest path from " << sourceGate << " to " << destGate << ": ";
                                        for (const auto &node : path)
                                            {
                                                cout << node << " -> ";
                                            }
                                        cout << "\b\b\b  " << endl; // Remove the last "->" and add newline
                                        cout << "Shortest distance: " << distance << endl;
                                        destinationReached = true; 
                                        return distance;
                                }
                        }
                    
                    for (const string &neighbor : adjacencyList[currentNode.first]) {                
                        auto nodeIt = find_if(nodes.begin(), nodes.end(), [neighbor](const myGates &gate) {  //nodeIt points to the output node of the current Node
                            return gate.nodeName == neighbor;
                        });                                            
                             
                        if (nodeIt != nodes.end()) {
                            int distanceToNeighbor = currentNode.second + nodeIt->delay;   //Updates the distance of the node                             
                            auto unvisitedIt = find_if(unvisitedNodes.begin(), unvisitedNodes.end(),     
                                [neighbor](const pair<string, int> &p) {                 //Find the node in unvisited list 
                                    return p.first == neighbor;
                                });

                            if (unvisitedIt != unvisitedNodes.end() && distanceToNeighbor < unvisitedIt->second) { //Update the delay of that node in unvisited list 
                                unvisitedIt->second = distanceToNeighbor;
                                previousNode[neighbor] = currentNode.first;
                                 
                                    }
                        }
                    }
                
                }

                return -1;
        }
 }myGraph; 


int parseFile(const string& filename)
  {

	ifstream file(filename); 
	if(!file.is_open())
	  {
	  	cout<<"Wrong file name"<<endl; 
        return 0; 
      }

	string line; 

	while(getline(file,line))
	 {
		if(line.find("INPUT(")==0)      //Find the string INPUT and save that node as type INPUT
		  {
			string inputName=line.substr(6,line.find(')')-6);           
           	        myGates inputGate; 
           		inputGate.nodeName = inputName; 
            		inputGate.delay = 0; 
			inputGate.type = "INPUT";
            	        nodes.push_back(inputGate); 

		  }
		else if(line.find("OUTPUT(")==0)     //Find the string OUTPUT and save that node as type OUTPUT
		  {
		 	string outputName=line.substr(7,line.find(')') - 7); 
            		myGates outputGate; 
            		outputGate.nodeName = outputName; 
            		outputGate.delay = 0; 
			outputGate.type = "OUTPUT";
            		nodes.push_back(outputGate); 

		  }
        else if(line.find("=")!=string::npos)
          {
            if(line.find("G")==0)
                {
                    string intermediateNodes=line.substr(0,line.find(" =")- 0);
                    bool ifExist = false; 
                    for(const auto& gate : nodes)
                        {
                            if(gate.nodeName == intermediateNodes && (gate.type=="INPUT" || gate.type=="OUTPUT")){
                                ifExist = true; 
                                break;
                            }
                        }
                    if (!ifExist)                                    //Find the '='  sign and save the node before it as type GATE 
                        {   myGates middleNodes; 
                            middleNodes.nodeName=intermediateNodes;
                            middleNodes.type="GATE";
                            middleNodes.delay=std::numeric_limits<int>::max();
                            nodes.push_back(middleNodes); 
                            
                        } 

                    size_t posOfEq = line.find("=");       
                    string findExp = line.substr(posOfEq+2); 
                    while(findExp.find("G") !=string::npos)
                        {
                            size_t start = findExp.find("G");             //Find the '=' sign and find the gates inside ()
                            size_t end = findExp.find(")"); 
                            string InputsOfGate = findExp.substr(start, end-1 - start + 1); 
                            InputsOfGate.erase(remove_if(InputsOfGate.begin(), InputsOfGate.end(), ::isspace), InputsOfGate.end());
                            size_t pos = 0; 
                            while(pos<InputsOfGate.length()){
                                size_t commaPos = InputsOfGate.find(',',pos); 
                                if(commaPos == std::string::npos)
                                    commaPos = InputsOfGate.length(); 

                                string gateName = InputsOfGate.substr(pos,commaPos - pos);
                                myGraph.addConnectedNodes(gateName,intermediateNodes);        //Adds connection between the gates   
                                pos = commaPos+1; 
                                }
                        
                            findExp = findExp.substr(end+1); 
                        }

                        

                }
            }     
     
    }
	file.close(); 
    return 1; 
   
}




int main(int argc, char* argv[])
 {
	if(argc !=4)
	  {

		std::cout<<"Incorrect number of argument"<<std::endl; 

	  }
	else 
       {
            string fileName = argv[1]; 
            string inputGate = argv[2]; 
            string outputGate = argv[3]; 
            
            int parse_result = parseFile(fileName); 

            if(parse_result)
               {   

                    bool inputFound = false; 
                    bool outputFound = false; 
		    bool flag = true; 
                    for(const auto& gate : nodes)
                      {
                        
                        if(gate.nodeName == inputGate)
                            {
                                inputFound = true;
                                
                                if(gate.type != "INPUT"){
                                cout<<"Signal "<<inputGate<<" not an input pin"<<endl;
                                    flag = false; 
                                    return 0; 	
                                    }  
                            } 
                      }

                    for(const auto& gate : nodes)
                        {
                            if (gate.nodeName == outputGate){
                                outputFound = true;
                                if(gate.type != "OUTPUT"){
                                    cout<<"Signal "<<outputGate<<" not an output pin"<<endl;
                                    flag = false;  
                                    return 0;  
                                    }
                            }

                        } 

                    if(!inputFound)
                        cout<<"Signal "<<inputGate<<" not found in file "<< fileName<<endl;
                    else if (!outputFound)
                        cout<<"Signal "<<outputGate<<" not found in file "<<fileName<<endl; 

                    else if(inputFound && outputFound && flag)
                       {
                        myGraph.delayCalculation(); 
                        //printNodes(); 
                        //myGraph.print(); 
                        myGraph.djikstraAlgo(inputGate, outputGate); 
                       }
                }

            
	
        }  

  }


