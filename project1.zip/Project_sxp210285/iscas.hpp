#ifndef ISCAS_HPP
#define ISCAS_HPP

#include <string>
#include <vector>

using namespace std;

bool fileExists(const string& filename);
bool inputSignalExistsInFile(const string& filename, const string& signalName);
bool outputSignalExistsInFile(const string& filename, const string& signalName);

int minDistance(const vector<int>& dist, const vector<char>& sptSet);
void printPath(const vector<int>& parent, int node, map<string, int> gate);
void dijkstra(const vector<vector<int>>& graph, int input, int output, map<string, int> gate);
string removeCarriageReturn(const string& s);

#endif