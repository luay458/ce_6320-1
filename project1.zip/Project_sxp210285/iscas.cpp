#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <sstream>
#include <map>
#include <algorithm>
#include <climits>
#include <cctype>

#include "iscas.hpp"

using namespace std;

const int INF = INT_MAX;

// Function to check if a file exists
bool fileExists(const string& filename) {
    ifstream file(filename);
    return file.good();
}

// Function to check if the Input signal name exists in the bench file
bool inputSignalExistsInFile(const string& filename, const string& signalName) {
    ifstream file(filename);
    string line;

    while (getline(file, line)) {
        // Signal definition starts with "INPUT(" 
        if ((line.find("INPUT(" + signalName + ")") != string::npos)) {
            return true;
        }
    }

    return false;
}

// Function to check if the Output signal name exists in the bench file
bool outputSignalExistsInFile(const string& filename, const string& signalName) {
    ifstream file(filename);
    string line;

    while (getline(file, line)) {
        // Signal definition starts with "OUTPUT("
        if ((line.find("OUTPUT(" + signalName + ")") != string::npos)) {
            return true;
        }
    }

    return false;
}

// Function to find the vertex with the minimum distance value
int minDistance(const vector<int>& dist, const vector<char>& sptSet) {
    int minDist = INF;
    int minIndex = -1;

    for (size_t i = 0; i < dist.size(); ++i) {
        if (!sptSet[i] && dist[i] < minDist) {
            minDist = dist[i];
            minIndex = static_cast<int>(i);
        }
    }

    return minIndex;
}

// Function to priint the shortest path
void printPath(const std::vector<int>& parent, int node, map<string, int> gate) {
    if (parent[node] == -1) { 
        for (auto& it : gate) {
            if (it.second == node) {
                std::cout << it.first;
            }
        }
        return;
    }
    printPath(parent, parent[node], gate);
    for (auto& it : gate) {
        if (it.second == node) {
            cout << " -> " << it.first;
        }
    }
}

// Function to find the shortest path between the given input and output gate 
void dijkstra(const vector<vector<int>>& graph, int input, int output, map<string, int> gate) {
    int vertex = graph.size();

    vector<int> dist(vertex, INF);
    vector<char> sptSet(vertex, false);
    vector<int> parent(vertex, -1);

    dist[input] = 0;

    for (int count = 0; count < vertex - 1; ++count) {
        int u = minDistance(dist, sptSet);
        if (u == -1) {
            // No valid vertex found
            break;
        }

        sptSet[u] = true;

        for (int v = 0; v < vertex; ++v) {
            if (!sptSet[v] && graph[u][v] != 0 && dist[u] != INF && dist[u] + graph[u][v] < dist[v]) {
                dist[v] = dist[u] + graph[u][v];
                parent[v] = u;
            }
        }
    }

    if (dist[output] == INF) {
            cout << "No path from source to target.\n";
        return;
    }

    for (auto& it : gate) {
        if (it.second == input) {
            cout << it.first << " -> ";
        }
    }

    for (auto& it : gate) {
        if (it.second == output) {
            cout << it.first << " : ";
        }
    }

    cout << "Shortest path is : ";
    printPath(parent, output, gate);
    cout << " = " << dist[output] << endl;
}

// Function to remove the carriage return from the obtained gates after parsing the file
string removeCarriageReturn(const string& s) {
    string result = s;
    result.erase(std::remove(result.begin(), result.end(), '\r'), result.end());
    return result;
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " <filename> <input_gate> <output_gate>" << endl;
        return 1; // Exit with an error code
    }

    const string filename = argv[1];
    const string inputGate = argv[2];
    const string outputGate = argv[3];

    if (!fileExists(filename)) {
        cerr << "Wrong file name"<< endl;
        return 1; // Exit with an error code
    }

    if (!inputSignalExistsInFile(filename, inputGate)) {
        cerr << "Signal " << inputGate << " not found in file " << filename << endl;
        if (!outputSignalExistsInFile(filename, outputGate)) {
            cerr << "Signal " << outputGate << " not found in file " << filename << endl;
        }
        return 1; // Exit with an error code
    }

    if (!outputSignalExistsInFile(filename, outputGate)) {
        cerr << "Signal " << outputGate << " not found in file " << filename << endl;
        return 1; // Exit with an error code
    }

    ifstream inputFile(filename);
    map<string, int> gateList;
    map<map<string, int>, int> delayList;

    if (inputFile.is_open()) {
        string line;
        int index = 0;
        // get the list of gates - gateList
        while (getline(inputFile, line)) {
            // Parse each line of the file to extract gate connections
            if (!(line.length() == 0 || line[0] == '#' || line.find("OUTPUT") == 0 || line.empty() || isspace(line[0]))) {
                if ((line.find("INPUT(") != string::npos)) {
                    stringstream iss(line);
                    string in, gateIn;
                    getline(iss, in, '(');
                    getline(iss, gateIn, ')');
                    gateList[gateIn] = index;
                    
                }
                else {
                    stringstream ss(line);
                    string gate;
                    ss >> gate;
                    gateList[gate] = index;
                }

                index++;
            }
        }

        // To determine the size of the adjacency matrix
        int size = gateList.size();

        // Create and initialize the adjacency matrix with zeros (no connections)
        std::vector<std::vector<int>> adjacencyMatrix(size, std::vector<int>(size, 0));

        for (const auto& pair : gateList) {
            inputFile.clear();
            inputFile.seekg(0);
            unsigned int count = 0;
            int nodeA = 0;
            vector<int> nodeB = { 0 };
            string delayLine;
            while (std::getline(inputFile, delayLine)) {
                // Parse each line of the file to extract delay(delayList) and gate connections 
                if (!(delayLine.length() == 0 || delayLine[0] == '#' || delayLine.find("OUTPUT") == 0 || delayLine.find("INPUT") == 0)) {
                    stringstream ss(delayLine);
                    string gate;
                    ss >> gate;
                    string equalSign;
                    ss >> equalSign;
                    string operation;
                    getline(ss, operation, '(');
                    string input;
                    if (operation == " nand" || operation == " nor" || operation == " and" || operation == " or" || operation == " not" || operation == " buf" || operation == " xor") {
                        while (getline(ss, input, ',')) {

                            if (input.find(',') != string::npos) {
                                input.erase(remove(input.begin(), input.end(), ','), input.end());
                            }

                            string inputGate;
                            // To remove the ')' from the input (last input)
                            for (char c : input) {
                                if (c != ')') {
                                    inputGate += c;
                                }
                            }

                            if (inputGate.find(' ') != string::npos) {
                                inputGate.erase(remove(inputGate.begin(), inputGate.end(), ' '), inputGate.end());
                            }

                            string cleanedPairFirst = removeCarriageReturn(pair.first);
                            string cleanedInputGate = removeCarriageReturn(inputGate);

                            // To count the number of occurances of the gate to get Fanout
                            if (cleanedPairFirst == cleanedInputGate) {
                                count++;
                                nodeB.push_back(gateList[gate]);
                            }
                        }
                    }
                }
            }
            
            // Assign fanout to every gate 
            delayList[gateList] = count;
            nodeA = pair.second;

            //Create Adjacency matrix
            for (int i = 0; i < nodeB.size(); ++i) {
                if ((nodeB[i] != 0) && (i == 0)) {
                    adjacencyMatrix[nodeA][nodeB[i]] = delayList[gateList];
                }
                else if (i > 0) {
                    if ((nodeB[i] != 0) && (nodeB[i] != nodeB[i - 1])) {
                        adjacencyMatrix[nodeA][nodeB[i]] = delayList[gateList];
                    }
                }
                else {
                        // do nothing
                }
            }            
        }

        // Dijkstra's algorithm to find shortest path and print the result
        dijkstra(adjacencyMatrix, gateList[inputGate], gateList[outputGate], gateList);

        // Close input file
        inputFile.close();
    }
    else {
        cout << "Unable to open file";
    }

    return 0; // Exit successfully
}
