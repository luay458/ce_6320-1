/*
Author: Prasad Arjun Dait
Net Id: PAD220002
Subject: CE-6320 Applied Data Structures and Algorithms.
*/

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <map>
#include <sstream>
using namespace std;
struct node_data { //Structure to sotore node info
    string node_name; //name
    int fan_out; //fan out count
	int delay;	//Delay from input node
	bool isvisited; //Dijkstra's algorithm visited node 
	int prev_node_index; //previous node details to track path from input to output
    struct linked_node *next; //Storees indexes of Adjacent Nodes (Fan out nodes)
};
struct linked_node { //Linked List to store indexes of adjacent nodes (Fan out nodes)
    int node_index;
    struct linked_node *next;
};


//Find Shortest path
/*
Function Name: shortest_path
Input: Index to array of node_data structure, node_data
Output: node_data structure filled with path details and delay.
Description: A recursive function that implements modified Dijkstra's algorithm for directed graphs.
First update Delay of all adjacent Nodes and set isvisited to true.
Combinational loops are ignored in this section since the combinational loops if break in one iteration will provide shortest path.
*/
int shortest_path(int input_index, node_data *my_node){
	
	struct linked_node *t;
	int total_delay = my_node[input_index].delay + my_node[input_index].fan_out;
	t = my_node[input_index].next;

	if((t == NULL) || (my_node[input_index].fan_out == 0)){
		return 1;
	}

	while(t != NULL){
		if((total_delay < my_node[t->node_index].delay) || (my_node[t->node_index].delay == 0)){
			my_node[t->node_index].delay = total_delay;
			my_node[t->node_index].prev_node_index = input_index;
		}
		t = t->next;
	}
	my_node[input_index].isvisited = true;
	t = my_node[input_index].next;
	//Directed graph update other Nodes details
	while(t != NULL){
		shortest_path(t->node_index, my_node);
		t = t->next;
	}
	return 1;
	
}


//Add Adjacent Nodes index
/*
Function Name: add_adjacent_nodes
Input: Index to array of node_data structure, node_data, index of adjacent node
Output: add details of adjacent nodes to the
Description: A function that adds adjacent node details to the noee_data structure(Nodes)
*/
void add_adjacent_nodes(int index_add, int node_data_index,node_data *my_node){
	int i;
	struct linked_node *t;
	struct linked_node *a;
	if(my_node[node_data_index].next == NULL){
		t = new linked_node;
		t->node_index = index_add;
		my_node[node_data_index].next = t;
		t->next = NULL;
	}
	else{
		t = new linked_node;
		t->node_index = index_add;
		a = my_node[node_data_index].next;
		my_node[node_data_index].next = t;
		t->next = a;
	}
}

/*
Function Name: create_graph
Input: MAP of Node_names and its indexes , node_data, filename
Output: Graph is created with node_data structure storing node details and linked to adjacent node linked list
Description: A function creates graph.
*/
void create_graph(map<string,int> my_map,node_data *my_node, string filename){

	string read_line,data_in;
	string temp,temp_node;
	fstream fp_benchfile; //File pointer

	fp_benchfile.open(filename.c_str(), ios::in);
	if(fp_benchfile.is_open()){
		while (!fp_benchfile.eof()) 
		{
			getline(fp_benchfile, read_line);
			if(!read_line.empty() && (read_line.find("#") == -1)){
				if(read_line.find("INPUT") != -1)
				{
					temp = read_line.substr((read_line.find("(") + 1),(read_line.find(")")));
					temp = temp.substr(0,(temp.length() - 1));
					if(my_map[temp]){
						my_node[my_map[temp]].fan_out = 0;
						my_node[my_map[temp]].node_name = temp;
						my_node[my_map[temp]].next = NULL;
						my_node[my_map[temp]].delay = 0;
						my_node[my_map[temp]].isvisited = false;
						my_node[my_map[temp]].prev_node_index = -1;
					}
				}
				else if((read_line.find("INPUT") == -1) && (read_line.find("OUTPUT") == -1))
				{
					temp_node = read_line.substr(0,(read_line.find("=")));
					temp_node.erase(remove(temp_node.begin(), temp_node.end(), ' '), temp_node.end());
					my_node[my_map[temp_node]].fan_out = 0;
					my_node[my_map[temp_node]].node_name = temp_node;
					my_node[my_map[temp_node]].next = NULL;
					my_node[my_map[temp_node]].delay = 0;
					my_node[my_map[temp_node]].isvisited = false;
					my_node[my_map[temp_node]].prev_node_index = -1;
					temp = read_line.substr((read_line.find("(") + 1),(read_line.find(")")));
					temp = temp.substr(0,(temp.length() - 1));
					temp.erase(remove(temp.begin(), temp.end(), ' '), temp.end());
					stringstream inputnodes(temp);
					while (getline(inputnodes, data_in, ',')) {
						data_in.erase(remove(data_in.begin(), data_in.end(), ' '), data_in.end()); 
						if(my_map[data_in]){
							my_node[my_map[data_in]].fan_out++;
							my_node[my_map[data_in]].node_name = data_in;
							add_adjacent_nodes(my_map[temp_node], my_map[data_in], my_node);
						}
				    } 
				}
			}
		}
	}
	fp_benchfile.close();

}

/*
Function Name: print_output
Input: node_data, output_index, total_nodes(maximum stack size)
Output: Print Data of Shortest path and Delay on terminal window.
Description: This function collects information from the node_data structure and stores the info in stack (Output to input).
Later it pops the information from stack and prints it in format "Input -> Node1 -> node2 -----> Output"
Prints Path delay for given path.
*/
void print_output(node_data *my_node, int output_index, int total_nodes){
	int top = -1;
    int *stack = new int[total_nodes];
	int prev_temp = my_node[output_index].prev_node_index;
	top++; //PUSH Data to stack
    stack[top] = output_index;
	while((prev_temp != 0) && (top != total_nodes-1)){
		top++; //PUSH Data to stack
        stack[top] = prev_temp;
		prev_temp = my_node[stack[top]].prev_node_index;
	}

	//POP Data and provide result
	cout<<"Shortest Path: ";
	while(top != -1){
		cout<<my_node[stack[top]].node_name;
		top--; //POP Data from stack
		if(top != -1){
			cout<<" -> ";
		}
		else
		{
			cout<<endl;
		}
	}
	cout<<"Delay: "<<my_node[output_index].delay<<endl;
	delete stack;
}


//main function
int main(int argc, char *argv[])
{
	fstream fp_benchfile; //File pointer
	int total_nodes = 0;
	string read_line,data_in;
	string temp;
	bool input_found = false;
	bool output_found = false;
	bool input_isInput = true;
	bool output_isOutput = true;
	node_data *node_details;
	map <string,int> nodes; //index information with respect to node_name


	//Initial Checks
	if(argc!=4){
		cout << "Incorrect number of arguments"<< endl;
		return 1;
	}

	fp_benchfile.open(argv[1], ios::in);
	total_nodes = 0;
	if(fp_benchfile.is_open()){
		while (!fp_benchfile.eof()) 
		{
			getline(fp_benchfile, read_line);
			if(!read_line.empty() && (read_line.find("#") == -1)){
				if(read_line.find("INPUT") != -1)
				{
					total_nodes++;
					temp = read_line.substr((read_line.find("(") + 1),(read_line.find(")")));
					temp = temp.substr(0,(temp.length() - 1));
					if(temp.compare(argv[2]) == 0){
						input_found = true;
					}
					nodes[temp] = total_nodes;
					output_isOutput = (temp.compare(argv[3]) == 0)? false: output_isOutput;
				}
				else if(read_line.find("OUTPUT") != -1)
				{
					temp = read_line.substr((read_line.find("(") + 1),(read_line.find(")")));
					temp = temp.substr(0,(temp.length() - 1));
					if(temp.compare(argv[3]) == 0){
						output_found = true;
					}
					input_isInput = (temp.compare(argv[2]) == 0)? false: input_isInput;
				}
				else{
					total_nodes++;
					temp = read_line.substr(0,(read_line.find("=")));
					temp.erase(remove(temp.begin(), temp.end(), ' '), temp.end());
					nodes[temp] = total_nodes;
				}
			}
		}
		fp_benchfile.close();
	}
	else{
		cout << "Wrong file name"<< endl;
		return 0;
	}

	if((!input_found) && (input_isInput)){
		cout << "Signal "<<argv[2]<<" not found in file"<<argv[1]<< endl;
		return 0;
	}
	else if((!output_found) && (output_isOutput)){
		cout << "Signal "<<argv[3]<<" not found in file"<<argv[1]<< endl;
		return 0;
	}
	else if((!input_found) && (!output_found) && (input_isInput) && (output_isOutput)){
		cout << "Signal "<<argv[2]<<" not found in file"<<argv[1]<< endl;
		return 0;
	}
	else if((!input_found) && (!output_found) && (!input_isInput) && (!output_isOutput)){
		cout << "Signal "<<argv[2]<<" is not an input pin"<< endl;
		return 0;
	}
	else if((!input_found) && (output_found) && (!input_isInput) && (output_isOutput)){
		cout << "Signal "<<argv[2]<<" is not an input pin"<< endl;
		return 0;
	}
	else if((input_found) && (!output_found) && (input_isInput) && (!output_isOutput)){
		cout << "Signal "<<argv[3]<<" is not an output pin"<< endl;
		return 0;
	}
	total_nodes++;
	node_details = new node_data[total_nodes];

	create_graph(nodes,node_details, argv[1]);
	node_details[nodes[argv[2]]].prev_node_index = 0;
	shortest_path(nodes[argv[2]],node_details);

	if(node_details[nodes[argv[3]]].prev_node_index == -1){
		cout<<"Path Does not exist."<<endl;
		return 1;
	}
	print_output(node_details, nodes[argv[3]],total_nodes);
	return 1;
}
