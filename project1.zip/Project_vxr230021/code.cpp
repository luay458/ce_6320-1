#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <climits>
#include <sstream>
using namespace std;

// Forward declaration of the Edge structure
struct Edge;

// Define a structure to represent a node in the circuit graph
struct Node {
    string name;
    int delay;
    vector<Edge> edges; // Store outgoing edges from this node
};

// Define a structure to represent an edge in the circuit graph
struct Edge {
    Node* to;
};

// Define a data structure to represent the circuit graph
map<string, Node> circuitGraph;

// Implement a function to read circuit data from the provided file
void readCircuitData(const string& circuitFileName) {
    ifstream file(circuitFileName);
    if (!file.is_open()) {
        cerr << "Error: Unable to open circuit file." << endl;
        exit(1);
    }

    string line;
    while (getline(file, line)) {
        // Ignore comments and empty lines
        if (line.empty() || line[0] == '#') {
            continue;
        }

        istringstream iss(line);
        string token;
        iss >> token;

        if (token == "INPUT") {
            string inputName;
            iss >> inputName;
            // Create a node for the input, add it to the circuit graph
            Node inputNode;
            inputNode.name = inputName;
            inputNode.delay = 0; // Inputs have no delay
            circuitGraph[inputName] = inputNode;
        } else if (token == "GATE") {
            string gateType, gateName, input1, input2;
            int delay;
            iss >> gateType >> gateName >> input1 >> input2 >> delay;
            // Create nodes and edges for the gate, add them to the circuit graph
            Node gateNode;
            gateNode.name = gateName;
            gateNode.delay = delay;
            gateNode.edges.push_back({&circuitGraph[input1]});
            gateNode.edges.push_back({&circuitGraph[input2]});
            circuitGraph[gateName] = gateNode;
        } else if (token == "OUTPUT") {
            string outputName, sourceGate;
            iss >> outputName >> sourceGate;
            // Create a node for the output, add it to the circuit graph
            Node outputNode;
            outputNode.name = outputName;
            outputNode.delay = 0; // Outputs have no delay
            circuitGraph[outputName] = outputNode;
            // Add an edge from the source gate to the output
            circuitGraph[sourceGate].edges.push_back({&circuitGraph[outputName]});
        }
    }
}

// Implement Dijkstra's algorithm to find the shortest path
void dijkstraShortestPath(const string& startNode, const string& endNode) {
    // Create a priority queue for Dijkstra's algorithm
    priority_queue<pair<int, Node*>, vector<pair<int, Node*>>, greater<pair<int, Node*>>> pq;
    
    // Initialize distances to infinity and set the startNode's distance to 0
    map<string, int> distances;
    for (const auto& entry : circuitGraph) {
        distances[entry.first] = INT_MAX;
    }
    distances[startNode] = 0;
    
    // Push the startNode to the priority queue
    pq.push({0, &circuitGraph[startNode]});
    
    while (!pq.empty()) {
        int currentDelay = pq.top().first;
        Node* currentNode = pq.top().second;
        pq.pop();
        
        // If the current node is the endNode, you've found the shortest path
        if (currentNode->name == endNode) {
            cout << "Shortest delay path from " << startNode << " to " << endNode << ": " << currentDelay << " units" << endl;
            return;
        }
        
        // Traverse the outgoing edges
        for (const Edge& edge : currentNode->edges) {
            int newDelay = currentDelay + edge.to->delay;
            if (newDelay < distances[edge.to->name]) {
                distances[edge.to->name] = newDelay;
                pq.push({newDelay, edge.to});
            }
        }
    }
    
    // If the loop finishes and you haven't found the endNode, it means there's no path
    cout << "No path from " << startNode << " to " << endNode << " found." << endl;
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " <circuitFile> <inputNode> <outputNode>" << endl;
        return 1;
    }

    string circuitFileName = argv[1];
    string startNode = argv[2];
    string endNode = argv[3];

    // Read the circuit data
    readCircuitData(circuitFileName);

    // Find the shortest delay path using Dijkstra's algorithm
    dijkstraShortestPath(startNode, endNode);

    return 0;
}