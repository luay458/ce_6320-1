#include<iostream>
#include<fstream>
#include<string>
#include<map>
#include<limits.h>
#include<sstream>
#include<typeinfo>
#include <vector>

using namespace std;

string input_iscas_file = "c17.bench.txt";
string testBench[11] = {
    "c17.bench",
    "c432.bench",
    "c499.bench",
    "c880.bench",
    "c1355.bench",
    "c1908.bench",
    "c2670.bench",
    "c3540.bench",
    "c5315.bench",
    "c6288.bench",
    "c7552.bench"
};

// source and sink for shortest path algorithm
int source =0;
int sink =0;

// Purpose: function to return the value of # vetrex, i/p, o/p, fan-in, fan-out
int getTotalNodes(string fileName, int x){
    // x == 1 return 'total gates'
    // x == 2 return 'input gates'
    // x == 3 return 'output'
    // x == 4 return 'interior'
    // x == 5 return 'fan-in'
    // x == 6 return 'fan-out'

    //Separation charaters to parse the input string.
    char splitter = ' ';
    char comaSplitter = ','; 
    char braces1 = '(';
    char braces2 = ')';

    //vlauses stored to allocate memory for the graph node
    int sizeOfInputArray;
    int sizeOfOutputArray;
    int sizeOfInteriorArray;
    int fanIn;
    int fanOut;

    //
    int myTextSize;

    string temp;

    string myText;

    const char* fileNameCStr = fileName.c_str();
    ifstream MyReadFile(fileNameCStr);
    
    int counter = 0;
    while (getline (MyReadFile, myText)) {
        if (myText[0] == '#' && counter <= 15) {
            myTextSize = myText.size();

            int i =0;
            while(i<=myTextSize){
                if (myText[i] != splitter && myText[i] != comaSplitter && myText[i] !=braces1 && myText[i] !=braces2 &&i < myTextSize){
                    temp = temp + myText[i];
                }   
                else if(myText[i] == splitter || myText[i] == comaSplitter || myText[i] ==braces1 || myText[i] ==braces2 || i == myTextSize) {
                    if (counter == 6 && (x ==1 || x == 2) && (i == myTextSize)){
                        std::stringstream ss(temp);
                        ss >> sizeOfInputArray;
                        //sizeOfInputArray = std::stoi(temp);
                    }
                    else if (counter == 7 && (x ==1 || x == 3) && (i == myTextSize)){
                        std::stringstream ss(temp);
                        ss >> sizeOfOutputArray;
                        //sizeOfOutputArray = std::stoi(temp);
                    }
                    else if (counter == 8 && (x ==1 || x == 4) && (i == myTextSize)){
                        std::stringstream ss(temp);
                        ss >> sizeOfInteriorArray;
                        //sizeOfInteriorArray = std::stoi(temp);
                    }
                    else if ( counter == 11 && (x ==1 || x == 5) && (i == myTextSize)){
                        std::stringstream ss(temp);
                        ss >> fanIn;
                        //fanIn = std::stoi(temp);
                    }
                    else if (counter == 12 && (x ==1 || x == 6) && (i == myTextSize)){
                        std::stringstream ss(temp);
                        ss >> fanOut;
                        //fanOut = std::stoi(temp);
                    }
                    else{
                        sizeOfInputArray    = sizeOfInputArray;
                        sizeOfOutputArray   = sizeOfOutputArray;
                        sizeOfInteriorArray = sizeOfInteriorArray;
                        fanIn = fanIn;
                        fanOut = fanOut;
                    }
                    temp.clear();
                }
                else {
                    temp.clear();
                }
                i++;
            }
        }
        counter++;
    }
    MyReadFile.close();
    if(x ==1){
        return (sizeOfInputArray + sizeOfOutputArray + sizeOfInteriorArray);
    }
    else if(x ==2){
        return sizeOfInputArray ;
    }
    else if(x ==3){
        return sizeOfOutputArray;
    }
    else if(x ==4){
        return sizeOfInteriorArray;
    }
    else if(x ==5){
        return fanIn;
    }
    else if(x ==6){
        return fanOut;
    }
    else {
        return 0;
    }
}

// total number of nodes/vertex in the graph
int totalVertex = 0;
int inputVertex = 0;
int outputVertex = 0;
int interiorVertex = 0;

// String array to store vertex
std::string* vertexTotal;
std::string* vertexInput;
std::string* vertexOutput;
std::string* vertexInterior;

// array to store weights
int* weights = 0;

// map data structure to store weight and node index
std::map<std::string, int> vertexTotalMap;
std::map<std::string, int> weightMap;

// 2-D array to create adjacencyMatrix
int** storeMatrix;

// Purpose: function to return the value of # vetrex, i/p, o/p, fan-in, fan-out
int storeVertex(string fileName, int x){
    // x == 1 stores 'total gates'
    // x == 2 store 'input gates'
    // x == 3 store 'output gates'

    //flags
    int inputStream = 0;
    int outputStream = 0;
    int combCircuitStream = 0;
    
    //Separation charaters to parse the input string.
    char splitter = ' ';
    char comaSplitter = ','; 
    char braces1 = '(';
    char braces2 = ')';

    //vlauses stored to allocate memory for the graph node
    int fanIn;
    int fanOut;

    string temp;

    string myText;

    const char* fileNameCStr = fileName.c_str();
    ifstream MyReadFile(fileNameCStr);

    int j=0;
    int k=0;
    while (getline (MyReadFile, myText)) {
        int myTextSize = myText.size(); 
        int i =0;
        while(i<=myTextSize){
            if(myText[0] != '#' && myText[i] == '='){
                break;
            }
            else if (myText[i] != splitter && myText[i] != comaSplitter && myText[i] !=braces1 && myText[i] !=braces2 &&i < myTextSize){
                    temp = temp + myText[i];
            }
            else if (myText[i] == splitter || myText[i] == comaSplitter || myText[i] ==braces1 || myText[i] ==braces2 ||i == myTextSize){
                
                if (temp.substr(0,5) == "INPUT" ){
                    inputStream         = 1;
                    outputStream        = 0;
                    combCircuitStream   = 0;
                    //cout <<"temp = " << temp << "  inputStream = "<< inputStream << "  outputStream = " << outputStream << "  combCircuitStream = "<< combCircuitStream <<endl;
                }
                else if (myText.substr(0,6) == "OUTPUT"){
                    outputStream        = 1;
                    inputStream         = 0;
                    combCircuitStream   = 0;
                    //cout <<"temp = " << temp << "  inputStream = "<< inputStream << "  outputStream = " << outputStream << "  combCircuitStream = "<< combCircuitStream <<endl;  
                }
                else if (myText[0] == 'G' ){
                    combCircuitStream   = 1;    //once set high will remain high forerver
                    outputStream        = 0;
                    inputStream         = 0;
                    //cout <<"temp = " << temp << "  inputStream = "<< inputStream << "  outputStream = " << outputStream << "  combCircuitStream = "<< combCircuitStream <<endl;
                }
                else if (inputStream ==1 && outputStream ==1 && combCircuitStream ==1){
                    combCircuitStream   = 1; 
                    outputStream        = 0;
                    inputStream         = 0;
                }
                else {
                    outputStream        = outputStream;
                    inputStream         = inputStream;
                    combCircuitStream   = combCircuitStream;
                }
                //cout <<"inputStream = "<< inputStream << "  outputStream = " << outputStream << "  combCircuitStream = "<< combCircuitStream <<endl;
                if(x ==1 && (inputStream ==1 || combCircuitStream ==1)){
                    if (temp.substr(0,1) == "G"){
                        //cout << temp<< "." << endl;
                        vertexTotal[j] = temp;
                        //cout<< "vertexTotal["<< j << "] = " <<vertexTotal[j] <<endl;
                        j++;
                    }
                }
                else if(x ==2 && inputStream ==1){
                    if (temp.substr(0,1) == "G"){
                        //cout << temp<< "." << endl;
                        vertexInput[j] = temp;
                        //cout<< "vertexInput["<< j << "] = " <<vertexInput[j] <<endl;
                        j++;
                    }
                }
                else if(x ==3 && outputStream ==1){
                    if (temp.substr(0,1) == "G"){
                        //cout << temp<< "." << endl;
                        vertexOutput[j] = temp;
                        //cout<< "vertexOutput["<< j << "] = " <<vertexOutput[j] <<endl;
                        j++;
                    }
                }
                temp.clear();
            }
            else {
                temp.clear();
            }
            i++;
        }
    }
    MyReadFile.close(); 
    return 0;
}

// Purpose: function to store the weights
int weightCalculation(string fileName){
    //flag
    int input2Gates = 0;
    
    //Separation charaters to parse the input string.
    char splitter = ' ';
    char comaSplitter = ','; 
    char braces1 = '(';
    char braces2 = ')';

    //vlauses stored to allocate memory for the graph node
    int fanIn;
    int fanOut;

    string temp;

    string myText;

    const char* fileNameCStr = fileName.c_str();
    ifstream MyReadFile(fileNameCStr);

    int k=0;
    while (getline (MyReadFile, myText)) {
        int myTextSize = myText.size(); 
        int i =0;
        while(i<=myTextSize){
            if(myText[0] == '#') {
                break;
            }
            else if(myText[i] == '=' && input2Gates == 0) {
                input2Gates = 1;
                temp.clear();
            }
            else if (myText[i] != splitter && myText[i] != comaSplitter && myText[i] !=braces1 && myText[i] !=braces2 &&i < myTextSize){
                temp = temp + myText[i];
            }
            else if (input2Gates == 1 && (myText[i] == splitter || myText[i] == comaSplitter || myText[i] ==braces1 || myText[i] ==braces2 ||i == myTextSize)){
                if (temp.substr(0,1) == "G"){
                    for( int a = 0 ; a<totalVertex; a++){
                        if (vertexTotal[a] == temp){
                            weights[a] = weights[a] +1;
                            //cout<< temp <<", weights["<< a << "] = " <<weights[a] <<endl;         
                        }
                    }
                }
                temp.clear();
            }
            else {
                temp.clear();
            }
            i++;
        }
        input2Gates =0;
    }
    MyReadFile.close(); 
    return 0;
}

// Purpose: function to store the adjacencyMatrix
int adjacencyMatrix(string fileName){
    //flags
    int inputStream = 0;
    int outputStream = 0;
    int combCircuitStream = 0;
    int input2Gates = 0;
    
    //Separation charaters to parse the input string.
    char splitter = ' ';
    char comaSplitter = ','; 
    char braces1 = '(';
    char braces2 = ')';

    //vlauses stored to allocate memory for the graph node
    int fanIn;
    int fanOut;

    string temp;

    string parentNode;
    int parentNodeIndex;

    int childNodeIndex;

    string myText;

    const char* fileNameCStr = fileName.c_str();
    ifstream MyReadFile(fileNameCStr);

    int j=0;
    int k=0;
    while (getline (MyReadFile, myText)) {
        int myTextSize = myText.size(); 
        int i =0;
        while(i<=myTextSize){
            if(myText[0] == '#'){
                break;
            }
            else if(myText[i] != splitter && myText[i] != comaSplitter && myText[i] !=braces1 && myText[i] !=braces2 &&i < myTextSize){
                    temp = temp + myText[i];
            }
            else if(myText[i] == '=' && input2Gates == 0) {
                input2Gates = 1;
                temp.clear();
            }
            else if(myText[i] == splitter || myText[i] == comaSplitter || myText[i] ==braces1 || myText[i] ==braces2 ||i == myTextSize){
                
                if (temp.substr(0,5) == "INPUT" ){
                    inputStream         = 1;
                    outputStream        = 0;
                    combCircuitStream   = 0;
                }
                else if (myText.substr(0,6) == "OUTPUT"){
                    outputStream        = 1;
                    inputStream         = 0;
                    combCircuitStream   = 0;
                }
                else if (myText[0] == 'G' ){
                    combCircuitStream   = 1;    //once set high will remain high forerver
                    outputStream        = 0;
                    inputStream         = 0;
                }
                else if (inputStream ==1 && outputStream ==1 && combCircuitStream ==1){
                    combCircuitStream   = 1; 
                    outputStream        = 0;
                    inputStream         = 0;
                }
                else {
                    outputStream        = outputStream;
                    inputStream         = inputStream;
                    combCircuitStream   = combCircuitStream;
                }
                
                if(input2Gates == 0 && combCircuitStream ==1){
                    if (temp.substr(0,1) == "G"){
                        //cout << temp<< "." << endl;
                        parentNode = temp;
                        parentNodeIndex = vertexTotalMap[parentNode];
                        //cout<< "parentNode = " <<parentNode;
                        //cout<< ", parentNodeIndex = " <<parentNodeIndex <<endl;
                        input2Gates = 1;
                    }
                }
                else if(input2Gates == 1 && combCircuitStream ==1){
                    if (temp.substr(0,1) == "G"){
                        //cout << temp<< "." << endl;
                        childNodeIndex = vertexTotalMap[temp];
                        storeMatrix[childNodeIndex][parentNodeIndex] = weightMap[temp];
                    }
                }
                temp.clear();
            }
            else {
                temp.clear();
            }
            i++;
        }
        input2Gates =0;
    }
    MyReadFile.close();
    return 0;
}

// Purpose:  function to find minimum length
int minPathLength(int length[], bool shortPathCheckSheet[], int totalVertexInGraph) {
	int minLength = INT_MAX;
    int minLength_index;
	for (int i = 0; i < totalVertexInGraph; i++){
        if (shortPathCheckSheet[i] == false && length[i] <= minLength){
            minLength = length[i], minLength_index = i;
        }
    }
	return minLength_index;
}
// Purpose: function to print shortest path & length 
void shortPathDisplay(int length[], int totalVertexInGraph, const vector<int>& parentNode,  int sink, int srcNode) {
	cout << "Shortest Path Length \t Shortest Path" << endl;
	cout << "\t" <<length[sink]<< "\t\t" << vertexTotal[sink];
    if (length[sink] >= 2147483647){
        cout << endl <<"no path between provided input and output." << endl; 
    }
    else{
        int i = sink;
        while (i != srcNode) {
            cout << " <- " << vertexTotal[parentNode[i]];
            i = parentNode[i];
        }
        cout<< endl;
    }
}
// Purpose: function to find the shortest path between source and all vertices.
void shortPathFinder(int **weightedGraph, int srcNode, int totalVertexInGraph, int sinkNode) {
	vector<int> parentNode(totalVertexInGraph, -1);
	cout << "------------------------------------------------------"<<endl;
	bool shortPathCheckSheet[totalVertexInGraph]; 
    int length[totalVertexInGraph]; 
	for (int i = 0; i < totalVertexInGraph; i++){
        length[i] = INT_MAX; 
        shortPathCheckSheet[i] = false;
    }
	length[srcNode] = 0;
	for (int i = 0; i < totalVertexInGraph - 1; i++) {
		int u = minPathLength(length, shortPathCheckSheet, totalVertexInGraph);
		shortPathCheckSheet[u] = true;
		for (int v = 0; v < totalVertexInGraph; v++){
            if (!shortPathCheckSheet[v] && weightedGraph[u][v] && length[u] != INT_MAX && length[u] + weightedGraph[u][v] < length[v]) {
				length[v] = weightedGraph[u][v] + length[u];
				parentNode[v] = u;
			} 
        }
	}
	shortPathDisplay(length, totalVertexInGraph, parentNode, sinkNode, srcNode);
}

//Flags regarding input from command console
int inputFileFlag   =0;
int checkInputGate  =0;
int checkOutputGate =0;

int main(int argc, char *argv[]){
    
    //command to clear command console 
    //system("cls");
    
    cout <<"------------> number of arguments   = "<< argc<<endl;
    if(argc !=4){
        cout << "------------------------------------------------------"<<endl;
        cout <<"Incorrect number of arguments"<<endl;
        return 0;   
    }

    cout <<"------------> bench under test      = "<< argv[1]<<endl;
    for(int i =0; i< 11; i++){
        if(argv[1] == testBench[i]){
            inputFileFlag =1;
            //input_iscas_file = string("/home/013/a/ax/axy220002/dsa/") + argv[1];
            input_iscas_file = argv[1];        
        }
    }
    if(inputFileFlag == 0){
        cout << "------------------------------------------------------"<<endl;
        cout <<"Wrong file name"<<endl;
        return 0;   
    }
    
    totalVertex = getTotalNodes(input_iscas_file, 1);
    //cout <<"total vertex = " << totalVertex <<"." <<endl;

    inputVertex = getTotalNodes(input_iscas_file, 2);
    //cout <<"input vertex = " << inputVertex <<"." <<endl;

    outputVertex = getTotalNodes(input_iscas_file, 3);
    //cout <<"output vertex = " << outputVertex <<"." <<endl;

    interiorVertex = getTotalNodes(input_iscas_file, 4);
    //cout <<"interior vertex = " << interiorVertex <<"." <<endl;

    //allocating memory w.r.t. # gates in design
    vertexTotal     = new std::string[totalVertex];
    vertexInput     = new std::string[inputVertex];
    vertexOutput    = new std::string[outputVertex];
    //vertexInterior  = new std::string[interiorVertex];

    //Storing Input nodes
    storeVertex(input_iscas_file, 2);
    cout <<"------------> Input Gate    = "<< argv[2]<<endl;
    for(int i =0; i< inputVertex; i++){
        if(argv[2] == vertexInput[i]){
            checkInputGate =1;
        }
    }
    

    //Storing Output nodes 
    storeVertex(input_iscas_file, 3);

    if(checkInputGate == 0){
        for(int i =0; i< outputVertex; i++){
            if(argv[2] == vertexOutput[i]){
                cout << "------------------------------------------------------"<<endl;
                cout <<"Signal " << argv[2] <<" is not an input pin"<< endl;
                return 0;  
            }
        }
        cout << "------------------------------------------------------"<<endl;
        cout <<"Signal " << argv[2] <<" not found in file "<< argv[1] <<endl;
        return 0;   
    }

    cout <<"------------> Output Gate   = "<< argv[3]<<endl;
    for(int i =0; i< outputVertex; i++){
        if(argv[3] == vertexOutput[i]){
            checkOutputGate =1;
        }
    }
    if(checkOutputGate == 0){
        for(int i =0; i< inputVertex; i++){
            if(argv[3] == vertexInput[i]){
                cout << "------------------------------------------------------"<<endl;
                cout <<"Signal " << argv[3] <<" is not an output pin"<< endl;
                return 0;  
            }
        }
        cout << "------------------------------------------------------"<<endl;
        cout <<"Signal " << argv[3] <<" not found in file "<< argv[1] <<endl;
        return 0;   
    }

    //Purpose: delete memory added for input, output array
    delete[] vertexInput;
    delete[] vertexOutput;

    //Storing Total nodes
    storeVertex(input_iscas_file, 1);

    for(int i =0; i< totalVertex; i++){
        vertexTotalMap[vertexTotal[i]] = i;
        //cout<< "vertexTotalMap[" << vertexTotal[i] << "] = " << i << endl;
    }

    //allocating memory w.r.t. total # gates in design, initil value '0'
    weights = new int[totalVertex]{};

    // Purpose: Calculating weight and storing it an array respectivley  
    weightCalculation(input_iscas_file);
    
    //store weight in 'weightMap' using node string as key
    for(int i =0; i< totalVertex; i++){
        weightMap[vertexTotal[i]] = weights[i];
        //cout<< "weightMap[" << vertexTotal[i] << "] = " << weights[i] << endl;
    }

    //Declare a pointer to a pointer to int (int**)
    storeMatrix = new int*[totalVertex];
    
    //Allocate memory to each row
    for (int i = 0; i < totalVertex; ++i) {
        storeMatrix[i] = new int[totalVertex];
    }

    //Initialize the matrix to '0'
    for(int i =0; i< totalVertex; i++){
        for(int j =0; j< totalVertex; j++){
            storeMatrix[i][j] = 0;
        }
    }

    //Purpose: Creating adjacency Matrix
    adjacencyMatrix(input_iscas_file);

    int source = vertexTotalMap[argv[2]];
    int sink = vertexTotalMap[argv[3]];

	shortPathFinder(storeMatrix, source, totalVertex, sink);
}