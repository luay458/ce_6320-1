#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
#include <climits>
#include <cctype>
#include <algorithm>
// Struct representing a logic gate
struct Gate {
    std::string name; 
    std::vector<std::string> inputs; // Inputs to the gate
    int numInputs; // Number of inputs to the gate
};

// Struct representing a node in a path
struct PathNode {
    int index; // Index of the node
    int delay; // Delay associated with reaching this node
};

// Struct representing a path
struct Path {
    std::vector<PathNode> path; 
    int length; // Length of the path
};

// Struct representing a graph
struct Graph {
    int numNodes; // Number of nodes in the graph
    std::vector<std::vector<int>> adjMatrix; // Adjacency matrix representing connections between nodes
    std::vector<int> delays; // Delays associated with each node in the graph
};


int firstIndex = 0;

// Declarations of Functions
void printGate(const Gate& gate);
void GatesMemory(std::vector<Gate>& gates);
void GraphMemory(Graph& graph);
int IndexingGates(const std::vector<Gate>& gates, const std::string& name,const std::string& direction);
std::vector<int> CalculatingDelay(const Graph& graph);
std::string trimString(std::string str);
Graph constructGraph(const std::vector<Gate>& gates);
Path dAlgorithm(const Graph& graph, int startIdx, int endIdx);


int main(int argc, char* argv[]) {
    Path path;
    int totalDelay;

    if (argc != 4) {  // Check if the correct number of command-line arguments is provided
        std::cout << "Incorrect number of arguments" << std::endl;
        return 1;
    }

    std::ifstream file(argv[1]); // Open the input file specified in the command-line argument
    if (!file) {
        std::cout << "Wrong file name" << std::endl;
        return 1;
    }

    std::string line;
	std::string Forward;   // Initialize strings 'Forward' and 'Backward' with respective values
	std::string Backward;
	Forward="FORWARD";
	Backward="BACKWARD";
    
    int numGates = 0;
    std::vector<Gate> gates;
// Read lines from the input file and parse gates and signals
    while (std::getline(file, line)) {
        if (line[0] == '#') {
            continue;
        }
         // Check for lines containing '=' or keywords like 'INPUT' or 'OUTPUT'
        if (line.find("=") != std::string::npos || line.find("INPUT") != std::string::npos || line.find("OUTPUT") != std::string::npos) {
            // Find positions of '(' and '=' in the line            
            size_t openParenthesis = line.find('(');
            size_t equalSign = line.find('=');

            if (line.find("INPUT") != std::string::npos) {   // Handling input gate declaration
                std::string inputName = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                gates.push_back({inputName, {}, 0});
                numGates++;
            } else if (line.find("OUTPUT") != std::string::npos) {  // Handling output gate declaration
                std::string outputName = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                gates.push_back({outputName, {}, 0}); // Create a gate and add it to the 'gates' vector
                numGates++;
              // Handling regular gate declaration with inputs
            } else if (equalSign != std::string::npos) {
                std::string gateName = trimString(line.substr(0, equalSign));
                std::string inputsBuffer = line.substr(openParenthesis + 1, line.find(')') - openParenthesis - 1);
                std::vector<std::string> inputs;
                size_t pos = 0;
                while ((pos = inputsBuffer.find(',')) != std::string::npos) {
                    std::string token = trimString(inputsBuffer.substr(0, pos));
                    inputs.push_back(token);
                    inputsBuffer.erase(0, pos + 1);
                }
                inputs.push_back(trimString(inputsBuffer));
                  // Create a gate with its name, inputs, and count of inputs, then add it to the 'gates' vector
                gates.push_back({gateName, inputs, static_cast<int>(inputs.size())});
                numGates++;
            }
        }
    }
    file.close();// Close the input file
// Determine indices for start and end gates based on input signals
    int startIdx = IndexingGates(gates, argv[2],Forward);
    int verifyStartIdx = IndexingGates(gates, argv[2],Backward);
    firstIndex = startIdx;
    int endIdx = IndexingGates(gates, argv[3],Backward);
    int verifyEndIdx = IndexingGates(gates, argv[3],Forward);
 // Validate the existence of start and end signals
    if (verifyStartIdx == -1) {
        std::cout << "Signal " << argv[2] << " not found in file " << argv[1] << std::endl;
        return 1;
    }
    if (verifyEndIdx == -1) {
        std::cout << "Signal " << argv[3] << " not found in file " << argv[1] << std::endl;
        return 1;
    }
    if (startIdx > verifyEndIdx) {
        std::cout << "Signal " << argv[2] << " is not an input pin" << std::endl;
        return 1;
    }

    Graph graph = constructGraph(gates); //Creating an instance of the Graph struct
    Path shortestPath = dAlgorithm(graph, startIdx, endIdx);/// Find the shortest path in the constructed graph from 'startIdx' to 'endIdx'

    if (shortestPath.path[0].delay < INT_MAX) { // Check if a valid shortest path is found
	std::cout << "Delay for Shortest Path: " << shortestPath.path.back().delay << std::endl;
        std::cout << "Shortest Path:" << std::endl;// Display the names of the gates in the shortest path
        for (const auto& node : shortestPath.path) {
            int gateIndex = node.index;
            std::cout << gates[gateIndex].name;
            if (&node != &shortestPath.path.back()) {
                std::cout << " ,";
		}
             
    }
        std::cout << " , "<<argv[3]<<"\n";
        std::cout << std::endl;
	
    } else {
        std::cout << "Delay for Shortest Path: NULL" << std::endl;
        std::cout << "Shortest Path: NOT FOUND" << std::endl;
    }


    GatesMemory(gates);
    GraphMemory(graph);
    return 0;
}

// Implemening function to print inputs and gates 
void printGate(const Gate& gate) {
    std::cout << "Gate: " << gate.name << ", NumInputs: " << gate.numInputs << std::endl;
// Iterating here  
    for (int i = 0; i < gate.numInputs; ++i) {
        std::cout << "  Input[" << i << "]: " << gate.inputs[i] << std::endl;
    }
}
// Implementing the function to free  the memory in gates
void GatesMemory(std::vector<Gate>& gates) {
    for (auto& gate : gates) {
        gate.inputs.clear();
    }
    gates.clear();
}

// Removing leading and trailing spaces from a given string.
std::string trimString(std::string str) {
    size_t start = str.find_first_not_of(" \t\n\r\f\v"); // Finding the position of  first non-whitespace character
    size_t end = str.find_last_not_of(" \t\n\r\f\v"); //Finding the position of  last non-whitespace character
    if (start != std::string::npos && end != std::string::npos) {
        return str.substr(start, end - start + 1);
    }
    return ""; // Returning an empty string
}
// Function finding the index of a gate based on its name and direction
int IndexingGates(const std::vector<Gate>& gates, const std::string& name, const std::string& direction) {
    // Trim the provided name to remove leading and trailing spaces
    std::string trimmedName = trimString(name);
    std::string Direction = direction;

    // Check the direction provided
    if (Direction == "FORWARD") {
        // Search gates in forward direction
        for (int i = 0; i < gates.size(); ++i) {
            // Compare gate names based on the provided name
            if (gates[i].name.compare(0, trimmedName.length(), trimmedName) == 0) {
                // Return the index if the gate name matches
                return i;
            }
        }
    } else if (Direction == "BACKWARD") {
        // Search gates in backward direction
        for (int i = gates.size() - 1; i >= 0; --i) {
            // Compare gate names based on the provided name
            if (gates[i].name.compare(0, trimmedName.length(), trimmedName) == 0) {
                // Return the index if the gate name matches
                return i;
            }
        }
    } else { 
        return -1;// Return -1 if an invalid direction is provided
    }
    return -1;  // Return -1 if the gate name is not found in the specified direction
}
// Computes and returns an array of fanout counts for each node in the graph.
std::vector<int> CalculatingDelay(const Graph& graph) {
    std::vector<int> fanouts(graph.numNodes, 0);
    for (int i = 1; i < graph.numNodes; ++i) {// Loop through nodes (starting at index 1) to calculate fanouts
        int fanoutCount = 0;
        for (int j = 0; j < graph.numNodes; ++j) { // Count connections (fanouts) from the current node to others
            if (graph.adjMatrix[i][j] == 1) {
                fanoutCount++;
            }
        }
        fanouts[i] = fanoutCount;// Assign calculated fanout count to the corresponding node's index
    }
    return fanouts;// Return the array with fanout counts for each node in the graph
}
// Initializes a Graph object based on the provided vector of gates.
Graph constructGraph(const std::vector<Gate>& gates) {
    Graph graph;
    graph.numNodes = gates.size();
    graph.adjMatrix.resize(graph.numNodes, std::vector<int>(graph.numNodes, 0));// Resize the adjacency matrix
    graph.delays.resize(graph.numNodes, 0);
	std::string Forward;
	Forward="FORWARD";
    // Populate adjacency matrix
    for (int i = 0; i < graph.numNodes; ++i) {
        for (int j = 0; j < gates[i].numInputs; ++j) {
            int inputIndex = IndexingGates(gates, gates[i].inputs[j],Forward);
            if (inputIndex != -1) {
                graph.adjMatrix[inputIndex][i] = 1; // There's a connection from input to output
            }
        }
    }
    // Calculate fanouts
    std::vector<int> fanouts = CalculatingDelay(graph);
    // Update delays based on fanouts
    for (int i = 0; i < graph.numNodes; ++i) {
        graph.delays[i] = fanouts[i];
    }
    return graph;
}
// Implementation of Dijkstra's algorithm to find the shortest path in a graph
Path dAlgorithm(const Graph& graph, int startIdx, int endIdx) {
    Path path;
    path.length = 0; // Initialize the path length to 0
    std::vector<int> distances(graph.numNodes, INT_MAX); // Initialize distances to all nodes as infinity
    std::vector<int> visited(graph.numNodes, 0); // Initialize visited nodes as not visited
    std::vector<PathNode> pathNodes(graph.numNodes); // Stores information about nodes in the path

    distances[startIdx] = 0; // Set the distance of the start node to 0
    for (int i = 1; i <= graph.numNodes; ++i) {
        distances[i] = INT_MAX; // Initialize all other distances to infinity
    }
    distances[startIdx] = 0; // Set the distance of the start node to 0 again (redundant)

    int iteration = 0;
    while (iteration < graph.numNodes) {
        int minDistance = INT_MAX;
        int currentIdx = -1;

        // Find the unvisited node with the smallest distance from the start
        for (int j = 0; j < graph.numNodes; ++j) {
            if (!visited[j] && distances[j] < minDistance) {
                minDistance = distances[j];
                currentIdx = j;
            }
        }

        if (currentIdx == -1) {
            break; // No unvisited nodes found or all nodes have been visited
        }
        visited[currentIdx] = 1; // Mark the current node as visited

        // Update distances for adjacent nodes based on the current node
        for (int j = 0; j < graph.numNodes; ++j) {
            if (!visited[j] && graph.adjMatrix[currentIdx][j] &&
                (distances[currentIdx] != INT_MAX &&
                 (distances[currentIdx] + graph.delays[j] < distances[j] || distances[j] == INT_MAX))) {
                // Update distance if a shorter path is found
                distances[j] = distances[currentIdx] + graph.delays[j];
                pathNodes[j].index = currentIdx; // Update path node information
                pathNodes[j].delay = distances[j];
            }
        }
        iteration++;
    }

    int currentIdx = endIdx;
    while (currentIdx != startIdx) {
        // Reconstruct the path by backtracking through the nodes with minimum distances
        path.path.push_back(pathNodes[currentIdx]);
        path.length++;
        currentIdx = pathNodes[currentIdx].index;
    }
    std::reverse(path.path.begin(), path.path.end()); // Reverse the path to get the correct order
    return path; // Return the shortest path
}



// Function to free memory allocated for the graph
void GraphMemory(Graph& graph) {
    graph.adjMatrix.clear();
    graph.delays.clear();
}


