#include <iostream>
#include <fstream>
#include <sstream>
#include <list>
#include <vector>
#include <queue>
#include <map>
#include <algorithm>
#include <memory>
#include <iterator>

using namespace std;

class djikstraMinDelay
{
public:
    class GateNode
    {
    public:
        std::string type;
        std::list<GateNode *> adjacencyList;
        int gateDelay;
        std::string name;

        GateNode(std::string type, int gateDelay, std::string name)
            : type(type), gateDelay(gateDelay), name(name) {}

        ~GateNode()
        {
            // Remove the current node from the adjacency lists of its neighbors
            for (auto neighbor : adjacencyList)
            {
                neighbor->removeNeighbor(this);
            }
        }

        // Function to add a neighbor to the adjacency list
        void addNeighbor(GateNode *neighbor)
        {
            adjacencyList.push_back(neighbor);
        }

        // Function to remove a neighbor from the adjacency list
        void removeNeighbor(GateNode *neighbor)
        {
            adjacencyList.remove(neighbor);
        }
    };

    class Pair
    {
    public:
        GateNode *gate;
        int delayWeight;

        Pair(GateNode *gate, int delayWeight) : gate(gate), delayWeight(delayWeight) {}
    };

    static std::list<std::string> getPath(std::map<std::string, std::string> &predecessors, std::string destination)
    {
        std::list<std::string> path;
        while (!destination.empty())
        {
            path.push_back(destination);
            destination = predecessors[destination];
        }
        path.reverse();
        return path;
    }

    static GateNode *findGateNodeByName(std::vector<std::unique_ptr<GateNode>> &nodes, std::string nodeName)
    {
        for (const auto &node : nodes)
        {
            if (node->name == nodeName)
            {
                return node.get();
            }
        }
        return nullptr;
    }
};

std::vector<std::string> benchFiles = {"c17.bench", "c432.bench", "c499.bench", "c880.bench", "c1355.bench",
                                       "c1908.bench", "c2670.bench", "c3540.bench", "c5315.bench", "c6288.bench", "c7552.bench"};

int main(int argc, char *argv[])
{
    if (argc != 4)
    {
        std::cout << "Incorrect number of arguments" << std::endl;
        return 1;
    }

    std::string filePath = argv[1]; // Update with the actual file path

    if (std::find(benchFiles.begin(), benchFiles.end(), filePath) == benchFiles.end())
    {
        std::cout << "Wrong File Name. File does not Exist" << std::endl;
        return 1;
    }

    std::vector<std::unique_ptr<djikstraMinDelay::GateNode>> nodes;

    std::ifstream inputFile(filePath);
    if (!inputFile.is_open())
    {
        std::cerr << "Error opening file: " << filePath << std::endl;
        return 1;
    }

    std::string line;
    while (std::getline(inputFile, line))
    {
        if (!line.empty())
        {
            //skipping the comment part of file
            if (line[0] == '#')
            {
                continue;
            }

            //processing the Input gates and storing them
            if (line.find("INPUT") != std::string::npos)
            {
                size_t startIndex = line.find('(');
                size_t endIndex = line.find(')');
                std::string inputName = line.substr(startIndex + 1, endIndex - startIndex - 1);
                auto node1 = std::unique_ptr<djikstraMinDelay::GateNode>(new djikstraMinDelay::GateNode("INPUT", 0, inputName));
                nodes.push_back(std::move(node1));
            }

            //processing the Output gates and storing them
            else if (line.find("OUTPUT") != std::string::npos)
            {
                size_t startIndex = line.find('(');
                size_t endIndex = line.find(')');
                std::string name = line.substr(startIndex + 1, endIndex - startIndex - 1);
                auto node = std::unique_ptr<djikstraMinDelay::GateNode>(new djikstraMinDelay::GateNode("OUTPUT", 0, name));
                nodes.push_back(std::move(node));
            }

            //processing the intermediate gates and storing them
            else
            {
                size_t index = line.find('=');
                std::string intermediateGateName = line.substr(0, index - 1);
                std::string inputString = line.substr(index + 2);

                djikstraMinDelay::GateNode *node;
                djikstraMinDelay::GateNode *currIntNode = djikstraMinDelay::findGateNodeByName(nodes, intermediateGateName);

                if (currIntNode == nullptr)
                {
                    //creating the current intermediate Gate Node
                    node = new djikstraMinDelay::GateNode("INTERMEDIATE", 0, intermediateGateName);
                    nodes.push_back(std::unique_ptr<djikstraMinDelay::GateNode>(node));
                }
                else
                {
                    node = currIntNode;
                }
                size_t startIndex = inputString.find('(');
                size_t endIndex = inputString.find(')');

                if (startIndex != std::string::npos && endIndex != std::string::npos && startIndex < endIndex)
                {
                    // inding the input or incoming edges gate of intermediate Node
                    std::string contentInsideBrackets = inputString.substr(startIndex + 1, endIndex - startIndex - 1);
                    std::replace(contentInsideBrackets.begin(), contentInsideBrackets.end(), ',', ' ');

                    std::istringstream iss(contentInsideBrackets);
                    std::vector<std::string> intermediateInputGates{std::istream_iterator<std::string>{iss},
                                                                    std::istream_iterator<std::string>{}};

                    // adding the current intermediate node to the adjacency list of its input or incoming edge gates
                    for (const auto &gates : intermediateInputGates)
                    {
                        djikstraMinDelay::GateNode *targetNode = djikstraMinDelay::findGateNodeByName(nodes, gates);
                        if (targetNode != nullptr)
                        {
                            djikstraMinDelay::GateNode *newNode = djikstraMinDelay::findGateNodeByName(nodes, node->name);
                            // updating adjacency list
                            targetNode->addNeighbor(newNode);
                            if (targetNode->type == "OUTPUT")
                            {
                                targetNode->gateDelay = 0;
                            }
                            else
                            {
                                targetNode->gateDelay = targetNode->adjacencyList.size();
                            }
                        }
                    }
                }
            }
        }
    }

    inputFile.close();

    std::string sourceGateNode = argv[2];
    std::string destinationGateNode = argv[3];

    djikstraMinDelay::GateNode *sourceGate = djikstraMinDelay::findGateNodeByName(nodes, sourceGateNode);
    djikstraMinDelay::GateNode *destinationGate = djikstraMinDelay::findGateNodeByName(nodes, destinationGateNode);

    // handling inputs from command Line
    if (sourceGate == nullptr)
    {
        std::cout << "Signal " << sourceGateNode << " not found in file: " << filePath << std::endl;
        return 1;
    }
    else
    {
        if (sourceGate->type != "INPUT")
        {
            std::cout << "Signal " << sourceGateNode << " is not an input pin." << std::endl;
            return 1;
        }
    }

    if (destinationGate == nullptr)
    {
        std::cout << "Signal " << destinationGateNode << " not found in file: " << filePath << std::endl;
        return 1;
    }
    else
    {
        if (destinationGate->type != "OUTPUT")
        {
            std::cout << "Signal " << destinationGateNode << " is not an output pin." << std::endl;
            return 1;
        }
    }

    // Djikstra Algorithm
    int threshold = 100;
    std::map<std::string, int> delayDistance;
    std::map<std::string, std::string> predecessors;
    for (const auto &vertex : nodes)
    {
        delayDistance[vertex->name] = std::numeric_limits<int>::max();
        predecessors[vertex->name] = "";
    }

    std::priority_queue<djikstraMinDelay::Pair, std::vector<djikstraMinDelay::Pair>, std::function<bool(djikstraMinDelay::Pair, djikstraMinDelay::Pair)>> minHeap(
        [](djikstraMinDelay::Pair p1, djikstraMinDelay::Pair p2)
        {
            return p1.delayWeight > p2.delayWeight;
        });

    djikstraMinDelay::GateNode *sourceNode = djikstraMinDelay::findGateNodeByName(nodes, sourceGateNode);

    delayDistance[sourceNode->name] = 0;
    minHeap.push(djikstraMinDelay::Pair(sourceNode, 0));

    while (!minHeap.empty())
    {
        djikstraMinDelay::Pair currentNode = minHeap.top();
        minHeap.pop();
        for (auto &neighbour : currentNode.gate->adjacencyList)
        {
            int dis = delayDistance[neighbour->name];
            int newDistance = delayDistance[currentNode.gate->name] + currentNode.gate->gateDelay;
            // Check if the new distance exceeds the threshold
            if(newDistance > threshold) {
                continue; // Skip updating distances for this neighbor
            }
            if(dis > newDistance) {
                delayDistance[neighbour->name] = newDistance;
                predecessors[neighbour->name] = currentNode.gate->name;
                minHeap.push(djikstraMinDelay::Pair(neighbour, newDistance));
            }
           
        }
    }

    // finding the path from source to destination
    std::list<std::string> path = djikstraMinDelay::getPath(predecessors, destinationGateNode);

    // Displaying Output
    if (delayDistance[destinationGateNode] == std::numeric_limits<int>::max())
    {
        std::cout << "No Path from " << sourceGateNode << " to " << destinationGateNode << " exist.";
        return 0;
    }
    std::cout << " Minimum Delay from " << sourceGateNode << " to " << destinationGateNode << " is: " << delayDistance[destinationGateNode] << " units" << std::endl;
    std::cout << " Path from " << sourceGateNode << " to " << destinationGateNode << " is: ";
    for (const auto &vertex : path)
    {
        djikstraMinDelay::GateNode *currNode = djikstraMinDelay::findGateNodeByName(nodes, vertex);
        if(currNode->gateDelay > 0) {
            std::cout << vertex << "--" << currNode->gateDelay <<"-->";
        }else{
            std::cout << vertex << " ";
        }
    }
    std::cout << std::endl;

    return 0;
}