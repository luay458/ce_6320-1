#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <ctype.h>

#define maximum_length 10000
#define maximum_inputs 10000
#define maximum_nodes  100000

typedef struct {
    char *name_of_GATE;
    char **inputs_to_GATE;
    int number_of_inputs_to_gate;
} GATE;

typedef struct {
    int index_of_node;
    int delay_of_node;
} NODE;

typedef struct {
    NODE *Path;
    int length_of_path_of_graph;
} PATH;

typedef struct {
    int number_of_nodes;
    int **adjacent_matrix;
    int *delay;
} GRAPH;

int firstindex_of_node=0;




//To calculate the number of fanouts 
int* number_of_fanouts(const GRAPH *Graph) {
    int *numfanouts = malloc(Graph->number_of_nodes * sizeof(int));
    if (numfanouts == NULL) {
        perror("Memory allocation error");
        exit(1);
    }

    for (int i = 0; i < Graph->number_of_nodes; ++i) {
        int fanoutCount = 0;
        for (int j = 0; j < Graph->number_of_nodes; ++j) {
            if (Graph->adjacent_matrix[i][j] == 1) {
                fanoutCount++;
            }
        }
        numfanouts[i] = fanoutCount;
    }

    return numfanouts;
}

//To create a graph from given benchmark circuits
GRAPH convertTograph(const GATE *total_gates, int numtotal_gates) {
    GRAPH GRAPH;
    GRAPH.number_of_nodes = numtotal_gates;
    GRAPH.adjacent_matrix = malloc(numtotal_gates * sizeof(int *));
    GRAPH.delay = malloc(numtotal_gates * sizeof(int));

    for (int i = 0; i < numtotal_gates; ++i) {
        GRAPH.adjacent_matrix[i] = calloc(numtotal_gates, sizeof(int));
        GRAPH.delay[i] = 0;
    }
    for (int i = 0; i < numtotal_gates; ++i) {
        for (int j = 0; j < total_gates[i].number_of_inputs_to_gate; ++j) {
            int inputindex_of_node = index_of_gate(total_gates, numtotal_gates, total_gates[i].inputs_to_GATE[j]);
            if (inputindex_of_node != -1) {
                GRAPH.adjacent_matrix[inputindex_of_node][i] = 1;
            }
        }
    }


    int *numfanouts = number_of_fanouts(&GRAPH);

    for (int i = 0; i < numtotal_gates; ++i) {
        GRAPH.delay[i] = numfanouts[i];
    }
    free(numfanouts);

    return GRAPH;
}

// Implementation of Dijkstra_algorithm's algorithm to find the shortest Path
PATH Dijkstra_algorithm(const GRAPH *Graph, int start, int destination) {
    PATH Path;
    Path.Path = malloc(Graph->number_of_nodes * sizeof(NODE));
    Path.length_of_path_of_graph = 0;
int *dist = malloc(Graph->number_of_nodes * sizeof(int));
if (dist == NULL) {
    perror("Memory allocation error");
    free(Path.Path);
    exit(1);
}

int *V = calloc(Graph->number_of_nodes,sizeof(int));
if (V == NULL) {
    perror("Memory allocation error");
    free(dist);
    free(Path.Path);
    exit(1);
}


dist[start] = 0;

    for (int i = 0; i < Graph->number_of_nodes; ++i) {
        dist[i] = INT_MAX;
    }

    dist[start] = 0;

    int iteration = 0;

    while (iteration < Graph->number_of_nodes) {
        int minimum_distance = INT_MAX;
        int current_index = -1;

        
        for (int j = 0; j < Graph->number_of_nodes; ++j) {
            if (!V[j] && dist[j] < minimum_distance) {
                minimum_distance = dist[j];
                current_index = j;
            }
        }

        if (current_index == -1) {
           
            break;
        }
  
    //V = visited nodes 

     V[current_index] = 1;

       
        for (int j = 0; j < Graph->number_of_nodes; ++j) {
    if (!V[j] && Graph->adjacent_matrix[current_index][j] &&
    (dist[current_index] != INT_MAX &&
     (dist[current_index] + Graph->delay[j] < dist[j] || dist[j] == INT_MAX))) {
    dist[j] = dist[current_index] + Graph->delay[j];
    Path.Path[j].index_of_node = current_index;
    Path.Path[j].delay_of_node = dist[j];

}


}

iteration++;


    }



    int current_index = destination;
    while (current_index != start) {
        Path.Path[Path.length_of_path_of_graph].index_of_node = current_index;
        Path.Path[Path.length_of_path_of_graph].delay_of_node = dist[current_index];
        Path.length_of_path_of_graph++;
        current_index = Path.Path[current_index].index_of_node;

    }

    NODE *reversedPath = malloc((Path.length_of_path_of_graph + 1) * sizeof(NODE));
    for (int i = 0; i <= Path.length_of_path_of_graph; ++i) {
        reversedPath[i] = Path.Path[Path.length_of_path_of_graph - i];
    
    Path.Path = reversedPath;

    free(dist);
    free(V);

    return Path;
}
}
//To find the shortest path between provided input and output
void find_shortest_path(PATH *Path, GATE *total_gates) {
if(Path->Path[Path->length_of_path_of_graph].delay_of_node!=2147483647){
	printf("Total Delay from input to output:%d\n",Path->Path[Path->length_of_path_of_graph].delay_of_node);
    printf("Shortest Path from input to output:\n");

    if (Path->length_of_path_of_graph == -1) {
        printf("  No Path found\n");
        return;
    }
	printf("%s --> ", total_gates[firstindex_of_node].name_of_GATE);

    for (int i = 1; i <= Path->length_of_path_of_graph; ++i) {
        int GATEindex_of_node = Path->Path[i].index_of_node;
        printf("%s", total_gates[GATEindex_of_node].name_of_GATE);

        if (i < Path->length_of_path_of_graph) {
            printf(" --> ");
        }
    }
    printf("\n");
}else{
printf("Total Delay:INFINITY\n");
    printf("Shortest Path:NOT FOUND\n");
}

}

void freeGRAPH(GRAPH Graph) {
    for (int i = 0; i < Graph.number_of_nodes; ++i) {
        free(Graph.adjacent_matrix[i]);
    }
    free(Graph.adjacent_matrix);
    free(Graph.delay);
}
//To find out the index of gate
int index_of_gate(const GATE *total_gates, int numtotal_gates, const char *name_of_GATE) {
    char trimmedname_of_GATE[maximum_length];
    int i = 0, j = strlen(name_of_GATE) - 1;
    while (isspace(name_of_GATE[i])) {
        i++;
    }
    while (j >= i && isspace(name_of_GATE[j])) {
        j--;
    }

    strncpy(trimmedname_of_GATE, name_of_GATE + i, j - i + 1);
    trimmedname_of_GATE[j - i + 1] = '\0';

    if (strstr(trimmedname_of_GATE, "INPUT") != NULL || strstr(trimmedname_of_GATE, "OUTPUT") != NULL) {
        for (int i = 0; i < numtotal_gates; ++i) {
            if (strcmp(total_gates[i].name_of_GATE, trimmedname_of_GATE) == 0) {
                return i;
            }
        }
    } else {
        for (int i = 0; i < numtotal_gates; ++i) {
            if (strncmp(total_gates[i].name_of_GATE, trimmedname_of_GATE, strlen(trimmedname_of_GATE)) == 0) {
                return i;
            }
        }
    }

    return -1;
}

int index_of_gateReverse(const GATE *total_gates, int numtotal_gates, const char *name_of_GATE) {
    char trimmedname_of_GATE[maximum_length];
    int i = 0, j = strlen(name_of_GATE) - 1;
    while (isspace(name_of_GATE[i])) {
        i++;
    }
    while (j >= i && isspace(name_of_GATE[j])) {
        j--;
    }

    strncpy(trimmedname_of_GATE, name_of_GATE + i, j - i + 1);
    trimmedname_of_GATE[j - i + 1] = '\0';
    if (strstr(trimmedname_of_GATE, "INPUT") != NULL || strstr(trimmedname_of_GATE, "OUTPUT") != NULL) {
        for (int i = numtotal_gates - 1; i >= 0; --i) {
            if (strcmp(total_gates[i].name_of_GATE, trimmedname_of_GATE) == 0) {
                return i;
            }
        }
    } else {
        for (int i = numtotal_gates - 1; i >= 0; --i) {
            if (strncmp(total_gates[i].name_of_GATE, trimmedname_of_GATE, strlen(trimmedname_of_GATE)) == 0) {
                return i;
            }
        }
    }

    return -1;
}

//MAIN FUNCTION TO EXECUTE

int main(int number_of_arguments, char *argument_vector[]) {
PATH Path;
int totaldelay_of_node;

   
    if (number_of_arguments != 4) {
        printf("Incorrect number of arguments\n");
        return 1;
    }
    FILE *file = fopen(argument_vector[1], "r");
    if (file == NULL) {
        perror("Wrong file name_of_GATE\n");
        return 1;
    }
    char line[maximum_length];
    int numtotal_gates = 0;
    GATE *total_gates = NULL;
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#') {
            continue;
        }

if (strstr(line, "=") != NULL || strstr(line, "INPUT") != NULL || strstr(line, "OUTPUT") != NULL) {
            char *openParenthesis = strchr(line, '(');
            char *equalSign = strchr(line, '=');
            if (strstr(line, "INPUT") != NULL) {
            char *inputname_of_GATE = strtok(openParenthesis + 1, ")");
                total_gates = realloc(total_gates, (numtotal_gates + 1) * sizeof(GATE));
                total_gates[numtotal_gates].name_of_GATE = strdup(inputname_of_GATE);
                total_gates[numtotal_gates].inputs_to_GATE = NULL;
                total_gates[numtotal_gates].number_of_inputs_to_gate = 0;
                numtotal_gates++;
            }
            else if (strstr(line, "OUTPUT") != NULL) {
          char *outputname_of_GATE = strtok(openParenthesis + 1, ")");
                total_gates = realloc(total_gates, (numtotal_gates + 1) * sizeof(GATE));
                total_gates[numtotal_gates].name_of_GATE = strdup(outputname_of_GATE);
                total_gates[numtotal_gates].inputs_to_GATE = NULL;
                total_gates[numtotal_gates].number_of_inputs_to_gate = 0;
                numtotal_gates++;
           }
            else if (equalSign != NULL) {
                total_gates = realloc(total_gates, (numtotal_gates + 1) * sizeof(GATE));
                if (total_gates == NULL) {
                    perror("Memory allocation error");
                    fclose(file);
                   
                    return 1;
                }
             char *GATEname_of_GATE = strtok(line, "= \t\n");
                total_gates[numtotal_gates].name_of_GATE = strdup(GATEname_of_GATE);

           
                char *inputs_to_GATEBuffer = strtok(openParenthesis + 1, ")");
                char *token = strtok(inputs_to_GATEBuffer, ",");
                total_gates[numtotal_gates].inputs_to_GATE = malloc(maximum_inputs * sizeof(char *));
                total_gates[numtotal_gates].number_of_inputs_to_gate = 0;

                while (token != NULL) {
                    total_gates[numtotal_gates].inputs_to_GATE[total_gates[numtotal_gates].number_of_inputs_to_gate] = strdup(token);
                    total_gates[numtotal_gates].number_of_inputs_to_gate++;
                    token = strtok(NULL, ",");
                }
                numtotal_gates++;
            }
        }
    }
    fclose(file);

    int start = index_of_gate(total_gates, numtotal_gates, argument_vector[2]);
    int start_index = index_of_gateReverse(total_gates, numtotal_gates, argument_vector[2]);
    firstindex_of_node = start;

    int destination = index_of_gateReverse(total_gates, numtotal_gates, argument_vector[3]);
    int destination_index = index_of_gate(total_gates, numtotal_gates, argument_vector[3]);

    if (start_index == -1) {
        printf("Signal %s not found in file %s\n", argument_vector[2], argument_vector[1]);
        return 1;
    }

    if (destination_index == -1) {
        printf("Signal %s not found in file %s\n", argument_vector[3], argument_vector[1]);
       return 1;
    }
    if (start > destination_index) {
        printf("Signal %s is not an input pin\n", argument_vector[2]);
        return 1;
    }

// Create a GRAPH from total_gates
GRAPH GRAPH = convertTograph(total_gates, numtotal_gates);

int *numfanouts = number_of_fanouts(&GRAPH);


// Apply Dijkstra_algorithm's algorithm to find shortest path
PATH shortest_path = Dijkstra_algorithm(&GRAPH, start, destination);


// Print the shortest Path
find_shortest_path(&shortest_path, total_gates);


  return 0;
}



