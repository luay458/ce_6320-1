#include <algorithm>
#include <fstream>
#include <iostream>
#include <limits>
#include <queue>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
 
using namespace std;
 
class Graph {
    unordered_map<string, vector<string>> adjList;
    unordered_map<string, int> fanOuts;
 
public:
    void addEdge(const string &from, const string &to) {
        adjList[from].push_back(to);
    }
 
    bool nodeExists(const string &node) {
        return adjList.find(node) != adjList.end();
    }
 
    void parseCircuitFile(const string &fileName) {
        ifstream file(fileName.c_str());
        if (!file.is_open()) {
            throw runtime_error("Wrong File Name: " + fileName);
        }
 
        string line;
        while (getline(file, line)) {
            if (line.empty() || line[0] == '#')
                continue;
 
            stringstream ss(line);
            string token, gate, inputGate;
            ss >> token;
 
            if (token == "INPUT" || token == "OUTPUT") {
                continue; // skip input/output lines
            } else {
                string gateName = token;
                getline(ss, line);
                size_t openParen = line.find('(');
                size_t closeParen = line.find(')');
                string inputList = line.substr(openParen + 1, closeParen - openParen - 1);
                stringstream inputSS(inputList);
 
                while (getline(inputSS, inputGate, ',')) {
                    inputGate.erase(remove(inputGate.begin(), inputGate.end(), ' '), inputGate.end());
                    addEdge(inputGate, gateName);
                }
            }
        }
        file.close();
        calculateFanOuts();
    }
 
    void calculateFanOuts() {
        for (const auto &node : adjList) {
            fanOuts[node.first] = node.second.size();
        }
    }
 
    pair<unordered_map<string, int>, unordered_map<string, string>> dijkstra(const string &source) {
        unordered_map<string, int> distances;
        unordered_map<string, string> predecessors;
 
        for (const auto &node : adjList) {
            distances[node.first] = numeric_limits<int>::max();
        }
        distances[source] = 0;
 
        auto cmp = [](const pair<string, int> &left, const pair<string, int> &right) {
            return left.second > right.second;
        };
        priority_queue<pair<string, int>, vector<pair<string, int>>, decltype(cmp)> pq(cmp);
        pq.push({source, 0});
 
        while (!pq.empty()) {
            string u = pq.top().first;
            pq.pop();
 
            if (adjList.find(u) == adjList.end())
                continue;
 
            for (const string &v : adjList.at(u)) {
                int weight = fanOuts[u];
                int distanceThroughU = distances[u] + weight;
                if (distanceThroughU < distances[v]) {
                    distances[v] = distanceThroughU;
                    predecessors[v] = u;
                    pq.push({v, distanceThroughU});
                }
            }
        }
 
        return {distances, predecessors};
    }
 
    vector<string> reconstructPath(const unordered_map<string, string> &predecessors, const string &source, const string &destination) {
        vector<string> path;
        for (string at = destination; at != source; at = predecessors.at(at)) {
            path.push_back(at);
        }
        path.push_back(source);
        reverse(path.begin(), path.end());
        return path;
    }
 
};
 
int main(int argc, char *argv[]) {
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " <file_name> <source_node> <target_node>" << endl;
        return 1;
    }
 
    string fileName = argv[1];
    string sourceNode = argv[2];
    string targetNode = argv[3];
 
    Graph graph;
 
    try {
        graph.parseCircuitFile(fileName);
 
        if (!graph.nodeExists(sourceNode)) {
            cerr << "Signal Comet " << sourceNode << " not found in file " << fileName << endl;
            return 1;
        }
 
        if (!graph.nodeExists(targetNode)) {
            cerr << "Signal Comet " << targetNode << " not found in file " << fileName << endl;
            return 1;
        }
 
        auto results = graph.dijkstra(sourceNode);
        auto distances = results.first;
        auto predecessors = results.second;
 
        if (distances.find(targetNode) == distances.end() || distances[targetNode] == numeric_limits<int>::max()) {
            cout << "No path found from " << sourceNode << " to " << targetNode << endl;
            return 1;
        } else {
            vector<string> path = graph.reconstructPath(predecessors, sourceNode, targetNode);
            cout << "Path from " << sourceNode << " to " << targetNode << ":" << endl << "  ";
            for (size_t i = 0; i < path.size(); ++i) {
                cout << path[i];
                if (i < path.size() - 1) {
                    cout << ", ";
                }
            }
            cout << endl << "Delay: " << distances[targetNode]-1<< endl;
        }
    } catch (const runtime_error &e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }
 
    return 0;
}