#include <iostream>
#include <fstream>
#include <cstdio>
#include <unordered_map>
#include <vector>
#include <queue>
#include <limits.h>
using namespace std;

//NOTE: Used the approach shown in Fig2 of image_1 to construct the graph.

unordered_map<string,int> inouts;
unordered_map<string,vector<pair<int,string>>> adj_map;

void find_shortest_path(string& input,string& output){
    unordered_map<string,int> pathlengths;
    unordered_map<string,int> visited;
    unordered_map<string,vector<string>> paths;
    priority_queue<pair<int,string>,vector<pair<int,string>>,greater<pair<int,string>>> pq;
    for(unordered_map<string, vector<pair<int,string>>>::const_iterator it = adj_map.begin();  it != adj_map.end(); ++it)
	{
	    pathlengths.insert({it->first,INT_MAX});
	    visited.insert({it->first,0});
	}
	for(unordered_map<string,int>::const_iterator it = inouts.begin();it!=inouts.end();++it){
		if(it->second)
			pathlengths.insert({it->first,INT_MAX});
	}
    string current = input;
    int currpathlength = 0;
    pathlengths[input] = 0;
    pq.push(make_pair(0,current));
    vector<string> temp;
    temp.push_back(current);
    paths.insert({current,temp});
    int pathfound = 0;
    while(1){
    	visited[current] = 1;
        currpathlength = pathlengths[current];
    	if(current == output){
        	pathfound = 1;
        	break;
        }
        pq.pop();
        int n = adj_map[current].size();
        for(int i = 0;i < n;i++){
            string node = adj_map[current][i].second;
            int weight = adj_map[current][i].first;
            if((currpathlength + weight < pathlengths[node]) && visited[node] == 0){
                pathlengths[node] = currpathlength + weight;
                pq.push(make_pair(pathlengths[node],node));
                temp = paths[current];
                temp.push_back(node);
                if(paths.find(node) != paths.end())
                	paths[node] = temp;
               	else
               		paths.insert({node,temp});
            }
        }
        if(pq.empty())
            break;
        current = pq.top().second;
    }
    if(!pathfound){
    	cout << "No path found between " << input << " and " << output << endl;
    }
    else {
    	vector<string>::iterator it = paths[output].begin();
    	cout << *it;
    	it++;
    	while(it!=paths[output].end()){
    		cout << " -> " << *it;
    		it++;
    	}
    	cout << " = " << pathlengths[output] << endl;  
    }

}

void add_edge(string& lhs, string& insignal){
	vector<pair<int,string>> temp;
	int i;
	if(adj_map.find(insignal)!=adj_map.end()){
    	int n = adj_map[insignal].size();
    	int fanout;
    	for(i=0;i<n;i++){
    		adj_map[insignal][i].first++;
    		fanout = adj_map[insignal][i].first;
    	}
    	adj_map[insignal].push_back(make_pair(fanout,lhs));
    }
    else{
        temp.push_back(make_pair(1,lhs));
        adj_map.insert({insignal,temp});
    }
}

string trim(string& line)
{	
	string trim_char = " \t";
    string::size_type first = line.find_first_not_of(trim_char);
    if (first == std::string::npos)
        return "";

    string::size_type last = line.find_last_not_of(trim_char);
    string::size_type str_length = last - first + 1;

    return line.substr(first, str_length);
}

void extract(string& line) {
	string::size_type equals = line.find_first_of("=");
	string lhs = line.substr(0,equals);
	lhs = trim(lhs);
	string rhs = line.substr(equals+1,line.size()-2);
	rhs = trim(rhs);
	//eliminate brackets
	int pos = 0;
	pos = rhs.find("(");
	int end = rhs.find(")");
	rhs = rhs.substr(pos+1,end-(pos+1));
    string s = rhs;
    while(pos < rhs.size()-1){
        pos = s.find(",");
        if(pos == string::npos)
        	break;
        string insignal = s.substr(0,pos);
        insignal = trim(insignal);
        add_edge(lhs,insignal);
	    s = s.substr(pos+1,s.size()-(pos));
    }
    s = trim(s);
    add_edge(lhs,s);
}

int main(int argc,char** argv){
	
	ifstream inputfile;
	
	if (argc != 4) {
        printf("Incorrect number of arguments\n");
        return -1;
    }

    string in_filename;
    string line;
    in_filename = argv[1];
    inputfile.open(argv[1]);
    if(!inputfile.is_open()){
    	printf("Wrong file name");
    	return -1;
    }
    while(getline(inputfile,line)){
    	string line_trimmed = trim(line);
    	string::iterator start = line_trimmed.begin();
    	if(*start != '#' && !line_trimmed.empty()) { //ignore comments and empty lines
    		string str1 = line_trimmed.substr(0,5); //size of the string "INPUT"
    		if(str1 == "INPUT"){
    			int pos = line_trimmed.find("(");
				int end = line_trimmed.find(")");
    			string inputname = line_trimmed.substr(pos+1,end-(pos+1));
    			inouts.insert({inputname,0});
    		}
    		else {
	    		str1 = line_trimmed.substr(0,6); //size of the string "OUTPUT"
	    		if(str1 == "OUTPUT"){
	    			int pos = line_trimmed.find("(");
					int end = line_trimmed.find(")");
    				string outputname = line_trimmed.substr(pos+1,end-(pos+1));
	    			inouts.insert({outputname,1});
	    		}
	    		else{
	    			extract(line_trimmed);
		    	}
    		}
    	}
    }

    
    string input(argv[2]);
    string output(argv[3]);

    if(inouts.find(input) == inouts.end()){
    	printf("Signal %s not found in file %s\n",argv[2],argv[1]);
    	return -1;
    }
    else
    	if(inouts[input]!=0){
    		printf("Signal %s is not an input pin\n",argv[2]);
    		return -1;
    	}
    if(inouts.find(output) == inouts.end()){
    	printf("Signal %s not found in file %s\n",argv[3],argv[1]);
    	return -1;
    }
    else
    	if(inouts[output]!=1){
    		printf("Signal %s is not an output pin\n",argv[3]);
    		return -1;
    	}

    find_shortest_path(input,output);
    
    return 0;
}