//This program takes in an input and output gate and an input file as strings, populates a graph based on the file data, and runs Djikstra's algorithm weith the input gate as the source node to find the minimum delay from the input to output gate.
//The file data is assumed to be in the format provided on the ISCAS’85 benchmark list, beginning with comments and input/output declaration, with the gate declaration following after an empty line.
//The output is the input and output gate names, the shortest path distance from the input gate to the output gate, and the nodes in that path in order.

using namespace std;
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <list>
#include <functional>
#include <iostream>
#include <queue>
#include <vector>
 

class Node;
class Edge;

class Node {
    public:
    int distance; //Distance from input gate
    vector<Edge*> directEdges; //List of edges from the node
    string name;
    int fanouts;
    bool input, output, visited;
    Node* prevNode = nullptr; //Previous node in shortest path tree

    Node(string n){
        name = n;
        fanouts = 0;
        distance = INT32_MAX; //INF is defined to be the maximum 32 bit integer
        input = false;
        output = false;
        visited = false;
    }
    void increaseFanouts(){
        fanouts++;
    }
    void addEdge(Edge *e);
};

class Edge {
    public:
    Node *fromNode;
    Node *toNode;
    int delay;
    Edge(Node *from, Node *to){
        fromNode = from;
        toNode = to;
        delay = to->fanouts;
    }
    void updateDelay(){
        if (toNode->fanouts == 0) delay = 1; //Add 1 delay to output gates
        else delay = toNode->fanouts;
    }
};

void Node::addEdge(Edge *e){
        directEdges.emplace_back(e);
}

class Compare {
    public:
       bool operator() (Node* a, Node* b){//Compare by distance from source
           return a->distance > b->distance;
      }
};

/*
vector<string> tokenizeString(const string &input) {//Regex version of tokenizer-- Doesn't work on NoMachine because compiler is too old
    vector<std::string> tokens;

    regex pattern("G[0-9]+gat"); // Regular expression to match gates

    smatch match;
    string::const_iterator searchStart(input.cbegin());

    while (regex_search(searchStart, input.cend(), match, pattern)) {
        tokens.push_back(match.str());
        searchStart = match.suffix().first; 
    }

    return tokens;
}


*/

vector<string> tokenizeString(const string &input) {//Finds gate strings in line
    vector<std::string> tokens;

    for (size_t i = 0; i < input.size(); ++i) {
        if (input[i] == 'G') {
            size_t j = i + 1;
            while (j < input.size() && isdigit(input[j])) {// Check if G is followed by digits and then gat
                ++j;
            }

            if (j < input.size() && input.substr(j, 3) == "gat") {
                tokens.push_back(input.substr(i, j - i + 3));
                i = j + 2; // Move index to the end of the current gate token
            }
        }
    }

    return tokens;
}



void djik(Node* fromGate){ //Find shortest delay path from fromGate to other gates
    priority_queue <Node*, vector<Node*>, Compare> pq; //min heap of nodes compared by distance from input
    (*fromGate).distance = 0; //Distance to self is zero
    pq.push(fromGate);
    while (!pq.empty()){
        Node* fromNode = pq.top();
        pq.pop();
        if (fromNode->visited)continue; //If already in shortest path tree, ignore
        fromNode->visited = true;
        for (Edge* edgePtr:fromNode->directEdges){//Check adjacent edges for shortest paths to vertices
            int weight = edgePtr->delay;
            int fromNodePathDist = fromNode->distance + weight;//Distance when taking path through fromNode to toNode 
            if (edgePtr->toNode->distance > fromNodePathDist){//If path is shorter through fromNode, update distance. Update toNode's fromNode to the new shortest path to it. Add toNode to pq.
                edgePtr->toNode->distance = fromNodePathDist;
                edgePtr->toNode->prevNode = fromNode;
                pq.push(edgePtr->toNode);
            }
        }
    }

}


int main(int argc, char* argv[]) {
    map<string, Node> nodeMap; //Contains all nodes, mapped by their string name
    vector<Edge*> edges; //Contains all edges

    string gate1, gate2, fileName;
    if (argc != 4){
        cout << "Incorrect number of arguments" << endl;
        return 1;
    }
    gate1 = argv[2];
    gate2 = argv[3];
    fileName = argv[1];

    ifstream file;
    file.open(fileName);
    if (!file.is_open()){
        cout <<"Wrong file name" << endl;
        return 1;
    }

    string text;
    while (getline (file, text)) {//Set inputs and outputs
        if (text[0] == '#') continue; // Skip comments
        if (text[0] != 'I' && text[0] != 'O') break; //Done reading inputs & outputs
         for (string token : tokenizeString(text)){
            nodeMap.emplace(token, Node(token)); 
            if (text[0] == 'I'){
                nodeMap.find(token)->second.input = true;
            }
            if (text[0] == 'O'){
                nodeMap.find(token)->second.output = true;
            }
         }
    }


    vector<string> tokens;
    map<string, Node>::iterator it;
    bool toNode;
    while (getline (file, text)) {//Read second section of file
        tokens = tokenizeString(text);
        toNode = 1;
        Node *toNodePtr = nullptr;
        for (const string &token : tokens) {//Iterate through gates
            it = nodeMap.find(token);
            if (it == nodeMap.end()) { //If not already in map, insert node
                nodeMap.emplace(token, Node(token)); 
            }

            if (toNode == 0){//ignore for result node
                Node *fromNodePtr = &nodeMap.find(token)->second;
                (*fromNodePtr).increaseFanouts();//add 1 to fanouts
                Edge *edgeAdd = new Edge(fromNodePtr, toNodePtr);//create edge to toNode
                fromNodePtr->addEdge(edgeAdd);//add edge to node directEdges
                edges.push_back(edgeAdd);//add edge to edges
            }

            else {
                toNodePtr = &nodeMap.find(token)->second;
                toNode = 0;
            }
            
            //cout << toNode << endl;
        }
    }
    // Close the file
    file.close();

    for(Edge *edge:edges){//update delays after all nodes are parsed
        edge->updateDelay();
        //cout << "From Node: " << edge->fromNode->name << " To Node: " << edge->toNode->name << " Delay: " << edge->delay << endl; //Prints out edges info to console for debugging
    }

    if (nodeMap.find(gate1) == nodeMap.end()){
        cout << "Signal " << gate1 << " not found in file " << fileName << endl;
        return 1;
    }
    else if (nodeMap.find(gate2) == nodeMap.end()){
        cout << "Signal " << gate2 << " not found in file " << fileName << endl;
        return 1;
    }

    if (nodeMap.find(gate1)->second.input != true){//If gate 1 is not an input or gate 2 is not an output, exit with respective message
        cout << "Signal " << gate1 << " is not an input pin" << endl;
        return 1;
    }
    else if (nodeMap.find(gate2)->second.output != true){
        cout << "Signal " << gate2 << " is not an output pin" << endl;
        return 1;
    }

    Node* startNode = &nodeMap.find(gate1)->second;
    Node* endNode = &nodeMap.find(gate2)->second;


    djik(startNode);

    cout << "Gate 1: " << gate1 << endl;
    cout << "Gate 2: " << gate2 << endl;
    if (endNode->distance == INT32_MAX){
        cout << "Distance from gate 1 to gate 2: INF" << endl;
    }

    else {
        cout << "Distance from gate 1 to gate 2: " << endNode->distance << endl;
        // print out path
        Node* currNode = &nodeMap.find(gate2)->second; //start at endNode
        cout << currNode->name;
        while (currNode->prevNode != nullptr){
            cout << " <-- " << currNode->prevNode->name;
            currNode = currNode->prevNode;
        }   
        cout << endl;
    }

/*   //Prints out nodemap info to console for debugging
     it = nodeMap.begin();

    while (it != nodeMap.end())
    {
        cout << "Key: " << it->first << endl;
        cout << "Fanouts: " << it->second.fanouts << endl;
        for (auto v : it->second.directEdges)
            cout << v->toNode->name << "    " << v->delay << "\n";
        ++it;
    }
   
*/

    //Deallocate memory
    for(Edge* ptr: edges){
        delete(ptr);
    }

}
