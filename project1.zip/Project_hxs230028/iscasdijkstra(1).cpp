#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <limits>

using namespace std;

const int INF = numeric_limits<int>::max();

struct Gate {
    string type;
    vector<string> inputs;
    int delay;
};

unordered_map<string, Gate> circuit;

void readCircuit(const string& filename) {
    ifstream file(filename);
    if (!file) {
        cerr << "Wrong file name" << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    while (getline(file, line)) {
        istringstream iss(line);
        string token;
        iss >> token;

        if (token == "INPUT") {
            string input;
            iss >> input;
            circuit[input] = {"INPUT", {}, 0};
        } else if (token == "OUTPUT") {
            string output;
            iss >> output;
            circuit[output] = {"OUTPUT", {}, 0};
        } else if (token == "AND" || token == "OR" || token == "NOT" || token == "NOR" || token == "BUF") {
            string output, in1, in2;
            iss >> output >> in1 >> in2;

            int fanout = circuit[output].inputs.size(); // Assume integer multiple of fan-out
            circuit[output] = {token, {in1, in2}, fanout};
        }
    }

    file.close();
}

int calculateDelay(const string& start, const string& end) {
    unordered_map<string, int> distance;
    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;

    for (const auto& entry : circuit) {
        distance[entry.first] = INF;
    }

    distance[start] = 0;
    pq.push({0, start});

    while (!pq.empty()) {
        string current = pq.top().second;
        pq.pop();

        for (const string& neighbor : circuit[current].inputs) {
            int weight = circuit[neighbor].delay;
            if (distance[current] + weight < distance[neighbor]) {
                distance[neighbor] = distance[current] + weight;
                pq.push({distance[neighbor], neighbor});
            }
        }
    }

    return distance[end];
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cerr << "Usage: ./iscas <filename> <input_gate> <output_gate>" << endl;
        return EXIT_FAILURE;
    }

    const string filename = argv[1];
    const string startGate = argv[2];
    const string endGate = argv[3];

    readCircuit(filename);

    if (circuit.find(startGate) == circuit.end() || circuit.find(endGate) == circuit.end()) {
        cerr << "Signal not found in file " << filename << endl;
        return EXIT_FAILURE;
    }

    int delay = calculateDelay(startGate, endGate);

    if (delay >= INF) {
        cout << "No valid path found between " << startGate << " and " << endGate << endl;
    } else {
        cout << "Shortest path delay between " << startGate << " and " << endGate << " is " << delay << " units" << endl;
    }

    return EXIT_SUCCESS;
}
