#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <limits>

using namespace std;

const int INF = std::numeric_limits<int>::max();

void dijkstra(const map<string, vector<pair<string, int>>>& graph, const string& startNode, const string& endNode) {
    map<string, int> distance;
    set<pair<int, string>> pq;

    for (const auto& node : graph) {
        distance[node.first] = INF;
        pq.insert({INF, node.first});
    }

    distance[startNode] = 0;
    pq.insert({0, startNode});

    while (!pq.empty()) {
        string currentNode = pq.begin()->second;
        pq.erase(pq.begin());

        if (graph.find(currentNode) == graph.end()) continue;

        for (const auto& neighbor : graph.at(currentNode)) {
            string neighborNode = neighbor.first;
            int weight = neighbor.second;

            if (distance[currentNode] + weight < distance[neighborNode]) {
                pq.erase({distance[neighborNode], neighborNode});
                distance[neighborNode] = distance[currentNode] + weight;
                pq.insert({distance[neighborNode], neighborNode});
            }
        }
    }

    cout << "Shortest distance from " << startNode << " to " << endNode << ": ";
    if (distance[endNode] == INF) {
        cout << "No path exists.\n";
    } else {
        cout << distance[endNode] << "\n";
    }
}

int main(int argc, char** argv) {
    if (argc != 4) {
        cerr << "Usage: ./iscas <file.bench> <startNode> <endNode>\n";
        return 1;
    }

    string filename = argv[1];
    string startNode = argv[2];
    string endNode = argv[3];

    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Wrong file name" << filename << endl;
        return 1;
    }

    string line;
    map<string, vector<pair<string, int>>> graph;
    bool startFound = false, endFound = false;

    while (getline(file, line)) {
        if (line[0] == '#') continue; // Skipping comments

        istringstream iss(line);
        string node, type, connections;

        if (line.find("INPUT") != string::npos || line.find("OUTPUT") != string::npos) {
            if (line.find(startNode) != string::npos) startFound = true;
            if (line.find(endNode) != string::npos) endFound = true;
            continue;
        }

        if (!(iss >> node >> type >> connections)) continue;

        istringstream connectionsStream(connections);
        string connection;
        while (getline(connectionsStream, connection, ',')) {
            graph[node].push_back(make_pair(connection, 1));
        }
    }

    file.close();

    if (!startFound || !endFound) {
        cerr << "Signal not found in " << filename << endl;
        return 1;
    }

    dijkstra(graph, startNode, endNode);

    return 0;
}

