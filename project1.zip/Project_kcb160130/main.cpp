#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <climits>
#include <algorithm>
#include <regex>
#include <sstream>
#include <set>
using namespace std;

// I used the original formula for calculating the fan out as specified in the inital rubric at the /
// beginning of the semester

// gate data stucture
struct Gate {
    string name;
    string type;
    vector<string> inputs;
};

// node structure for shortest path
struct Path {
    string node;
    int weight;
    string path;
};

// shortest path function
string djisktra(const map<string, vector<string>>& adjacencyList,map<string, map<string, int>>adjacencyMatrix, const map<string, int>& edgeWeights, const string& start, const string& end)
{
    // Pqueue to store vertices and their distances
    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;

    // Map to store distances from a given start node
    map<string, int> distances;

    // Map to store previous node in the shortest path
    map<string, string> previous;

    for (const auto& entry : adjacencyList) {
        const string& node = entry.first;
        distances[node] = (node == start) ? 0 : INT_MAX;
        previous[node] = "";
    }

    distances[start] = 0;
    pq.push({0, start});

    while (!pq.empty()) {
        string current = pq.top().second;
        int currentDistance = pq.top().first;
        pq.pop();

        // If the current distance is greater than the stored distance, skip
        if (currentDistance > distances[current]) {
            continue;
        }

        // Debugging output
       // cout << "Processing node: " << current << " (Distance: " << currentDistance << ")" << endl;

        // Iterate through neighbors of the current node using the adjacencyMatrix
        for (const auto& neighborEntry : adjacencyMatrix[current]) {
            const string& neighbor = neighborEntry.first;
            // Calculate the new distance
            int weight = edgeWeights.at(current + " -> " + neighbor);
            int newDistance = distances[current] + weight;

            // If shorter path is found, update current distance and previous node
            if (newDistance < distances[neighbor]) {
                distances[neighbor] = newDistance;
                previous[neighbor] = current;
                pq.push({newDistance, neighbor});

                // Debugging output
                //cout << "   Edge: " << current << " -> " << neighbor << " (Weight: " << weight << ")" << endl;
            }
        }
    }

    // Reconstruct the path
    string path;
    string current = end;

    while (!previous[current].empty()) {
        path = " -> " + current + path;
        current = previous[current];
    }

    path = current + path;

    // Debugging output
    //cout << "Distances:" << endl;
    //for (const auto& entry : distances) {
       // cout << entry.first << ": " << entry.second << endl;
   // }

    //cout << "Previous nodes:" << endl;
   // for (const auto& entry : previous) {
       // cout << entry.first << ": " << entry.second << endl;
   // }

    return path;
}

// function to parse bench files into matrices and maps
tuple<map<string, vector<string>>, map<string, int>, map<string, Gate>, map<string, map<string, int>>> parseCircuit(const string& fileName) {
    ifstream file(fileName);
    if (!file.is_open()) {
        cerr << "Error opening file: " << fileName << endl;
        exit(1);
    }

    string line;
    map<string, vector<string>> adjacencyList;
    map<string, int> edgeWeights;
    map<string, Gate> gates;
    map<string, map<string, int>> adjacencyMatrix;
    map<string, int> fanoutCount; // Map to count the fanout of each gate
    map<string, string> gateTypes; // Map to store the type of each gate
    set<string> outputGates; // Set to store the names of output gates

    while (getline(file, line)) {
        // Skip empty lines and comments
        if (line.empty() || line[0] == '#') {
            continue;
        }

        // Find the position of '=' character
        size_t equalPos = line.find('=');

        if (equalPos != string::npos) {
            // Extract gate name, specified output gate, and inputs
            string currentGate = line.substr(0, equalPos - 1);
            string outputGate = line.substr(equalPos + 2);
            size_t openParenPos = outputGate.find('(');
            size_t closeParenPos = outputGate.find(')');
            string gateType = outputGate.substr(0, openParenPos);
            string inputs = outputGate.substr(openParenPos + 1, closeParenPos - openParenPos - 1);
            

            // Print extracted information for debugging
            //cout << "Gate: " << currentGate << ", Type: " << gateType << ", Inputs: " << inputs << endl;

            // Skip gates with empty names
            if (currentGate.empty()) {
                //cout << "Skipping gate with empty name." << endl;
                continue;
            }

            if (gateTypes.find(currentGate) == gateTypes.end()) {
                gateTypes[currentGate] = outputGates.count(currentGate) > 0 ? "OUTPUT" : gateType;
            }

            // Check if the gate is an OUTPUT gate based on its appearance in the OUTPUT section
            if (outputGates.count(currentGate) > 0)  {
                gateTypes[currentGate] = outputGates.count(currentGate) > 0 ? "OUTPUT" : gateType;
                //cout << "Gate " << currentGate << " is identified as OUTPUT gate." << endl;
            }

            // Only add the gate if there are inputs
            if (!inputs.empty()) {
                // Split inputs into a vector
                vector<string> inputVector;
                size_t start = 0;
                size_t commaPos = inputs.find(", ");
                while (commaPos != string::npos) {
                    inputVector.push_back(inputs.substr(start, commaPos - start));
                    start = commaPos + 2; // Skip the comma and space
                    commaPos = inputs.find(", ", start);
                }
                inputVector.push_back(inputs.substr(start)); // Last input

                // Update adjacency list, gates map, and adjacency matrix
                //cout << "Adding gate: " << currentGate << endl;
                adjacencyList[currentGate] = inputVector;

                // Initialize Gate structure
                Gate currentGateInfo;
                currentGateInfo.name = currentGate;
                currentGateInfo.type = gateTypes[currentGate];
                currentGateInfo.inputs = inputVector;
                gates[currentGate] = currentGateInfo;
                
                // Increment fanout count for each input gate
                for (const string& input : inputVector) {
                    fanoutCount[input]++;
                    //cout << "Incrementing fanout for gate " << input << ": " << fanoutCount[input] << endl;

                    // Add INPUT gates to the gates map with an empty vector of input signals
                    if (gateTypes.find(input) == gateTypes.end()) {
                        gateTypes[input] = "INPUT";
                        gates[input] = {input, "INPUT", {}};
                    }
                }
            }
        } else if (line.find("OUTPUT") != string::npos) {
                    size_t openParenPos = line.find('(');
                    size_t closeParenPos = line.find(')');
                    string outputGate = line.substr(openParenPos + 1, closeParenPos - openParenPos - 1);
                    //cout << "Found OUTPUT gate: " << outputGate << endl;
                    outputGates.insert(outputGate);
        }
    }

    // Initialize edge weights to 1 for all gates' output connections
    for (const auto& pair : adjacencyList) {
        const string& outputGate = pair.first;
        for (const auto& inputGate : pair.second) {
            string edgeKey = inputGate + " -> " + outputGate;
            edgeWeights[edgeKey] = 1;
        }
    }

    // Initialize adjacency matrix with default weights
    for (const auto& pair : adjacencyList) {
        const string& currentGate = pair.first;
        for (const string& input : pair.second) {
            adjacencyMatrix[input][currentGate] = 1; // Set default weight to 1
        }
    }

    // Assign fanout-based weights to the edges
    for (const auto& pair : fanoutCount) {
        string outputGate = pair.first;
        int fanout = pair.second;

        for (const auto& inputGate : adjacencyList[outputGate]) {
            string edgeKey = inputGate + " -> " + outputGate;
            edgeWeights[edgeKey] = fanout;
        }
    }

    // Update adjacency matrix based on fanout count
    for (const auto& pair : fanoutCount) {
        string outputGate = pair.first;
        int fanout = pair.second;

        if (gates[outputGate].type != "OUTPUT") {
            // For non-OUTPUT gates, use the fanout count
            for (const auto& inputGate : adjacencyList[outputGate]) {
                adjacencyMatrix[inputGate][outputGate] = fanout;
            }
        }
    }

    return make_tuple(adjacencyList, edgeWeights, gates, adjacencyMatrix);
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        cout << "Usage: " << argv[0] << " <circuit_file.bench> <input_gate> <output_gate>" << endl;
        return 1;
    }

    // take input for bench file, and input/output nodes from terminal
    string fileName = argv[1];
    string inputSignal = argv[2];
    string outputSignal = argv[3];

    auto result = parseCircuit(fileName);
    map<string, vector<string>> adjacencyList;
    map<string, int> edgeWeights;
    map<string, Gate> gates;
    map<string, map<string, int>> adjacencyMatrix;

    tie(adjacencyList, edgeWeights, gates, adjacencyMatrix) = result;
    
 // Print adjacency matrix
cout << "Adjacency Matrix:" << endl;
for (const auto& pair : adjacencyMatrix) {
    const string& source = pair.first;
    const map<string, int>& targets = pair.second;

    for (const auto& target : targets) {
        const string& destination = target.first;
        int weight = target.second;

        cout << source << " -> " << destination << " (Weight: " << weight << ")" << endl;
    }
}

// Print edge weights
cout << "Edge Weights:" << endl;
for (const auto& entry : edgeWeights) {
    const string& edge = entry.first;
    int weight = entry.second;
    cout << edge << " -> " << weight << endl;
}


// Print contents of the gates map
//cout << "Contents of the gates map:" << endl;
//for (const auto& entry : gates) {
    //const string& gateName = entry.first;
    //const Gate& gate = entry.second;
    //cout << "Gate Name: " << gate.name << endl;
    //cout << "Gate Type: " << gate.type << endl;
    //cout << "Input Signals:";
   // for (const string& input : gate.inputs) {
      //  cout << " " << input;
    //}
    //cout << endl;
//}
 
    // making sure all inputs and ouputs specified actually exist
    if (gates.find(inputSignal) == gates.end()) {
        cout << "Signal " << inputSignal << " not found in file " << fileName << endl;
        return 1;
    }

    if (gates.find(outputSignal) == gates.end()) {
        cout << "Signal " << outputSignal << " not found in file " << fileName << endl;
        return 1;
    }

    // Check if the input and output are correctly located
    if (gates[inputSignal].type != "INPUT") {
        cout << "Signal " << inputSignal << " is not an input pin" << endl;
        return 1;
    }

    if (gates[outputSignal].type != "OUTPUT") {
        cout << "Signal " << outputSignal << " is not an output pin" << endl;
        return 1;
    }

    string path = djisktra(adjacencyList, adjacencyMatrix,edgeWeights, inputSignal, outputSignal);

    // making sure that no paths being found is output correctly
    if (path.empty() || path == outputSignal) {
        cout << "No path found between " << inputSignal << " and " << outputSignal << endl;
    } else {
        cout << "Shortest path from " << inputSignal << " to " << outputSignal << ": " << path << endl;
    }

    return 0;
}
