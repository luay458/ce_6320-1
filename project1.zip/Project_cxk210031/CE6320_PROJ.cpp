#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <limits>
#include <algorithm>
#include <sstream>

const int INFINITY_VAL = 99999;//All nodes are assigned a tentative distance value, initially set to infinity, except for the start node, which is set to zero.

struct my_node //Creating node parameters
{
    std::string label;
    int delay;
    std::vector<std::pair<my_node*, int>> my_edge;
    std::map<std::string, int> fan_out_delays;
};

std::vector<std::string> calculation_dijkstra(const std::map<std::string, my_node>& my_nodes, const std::string& source_node, const std::string& destination_node) //Dijkstra Algorithm Calculation[Parsing bench file value]
{
    std::map<std::string, int> weight;
    std::map<std::string, std::string> visited_node;
    std::set<std::string> unvisited_node;

    for (const auto& my_node : my_nodes) //my_nodes is container (perhaps a map or a list) where nodes are stored.
    {
        const std::string& my_nodelabel = my_node.first;
        if (my_nodelabel != source_node) 
        {
            weight[my_nodelabel] = INFINITY_VAL;
            visited_node[my_nodelabel] = " ";
        }
        unvisited_node.insert(my_nodelabel);
    }

    weight[source_node] = 1;

    while (!unvisited_node.empty()) //The loop will iterate through the unvisited nodes, selecting the one with the minimum distance.
    {
        std::string current;//Current should contain the node with the minimum distance among the unvisited nodes.
        int min_dist = INFINITY_VAL;//Valid distance found during the iteration will be smaller.

        for (const auto& my_node : unvisited_node) 
        {
            if (weight[my_node] < min_dist) 
            {
                min_dist = weight[my_node];
                current = my_node;
            }
        }

        unvisited_node.erase(current);

        if (current.empty() || my_nodes.find(current) == my_nodes.end()) //Is a safety check to handle unexpected situations, such as if the graph data is corrupted or if an invalid node is encountered.
        {
            break;
        }

        if (current == destination_node) //Block checks if the current node is the destination node. If it is, the loop is broken, indicating that the shortest path to the destination has been found.
        {
            break;
        }

        for (const auto& edge : my_nodes.at(current).my_edge) //This part of the code is skipping edges that lead to nodes not present in the graph. 
        {
            if (my_nodes.find(edge.first->label) == my_nodes.end()) 
            {
                continue;
            }

            int total_weight = my_nodes.at(current).my_edge.size();
            int buffer = total_weight;//Total weight is stored.

            if (buffer < weight[edge.first->label]) 
            {
                weight[edge.first->label] = buffer;//Part of the code calculates a total weight based on the number of edges from the current node 
                visited_node[edge.first->label] = current;//Updates the weight and visited node information for each neighboring node if a shorter path is found.
            }
        }
    }

    if (visited_node[destination_node].empty()) 
    {
        return std::vector<std::string>();
    }

    std::vector<std::string> dijkstra_path;//Calculating the Shortest Value using Dijkstra
    for (std::string my_node = destination_node; !my_node.empty(); my_node = visited_node[my_node]) 
    {
        dijkstra_path.push_back(my_node);
    }
    std::reverse(dijkstra_path.begin(), dijkstra_path.end());

    return dijkstra_path;
}

void bench_file_parcing(const std::string& filelabel, std::map<std::string, my_node>& my_nodes) //Parsing Bench Files
{
    std::ifstream file(filelabel);
    std::string my_line;
    std::string gatelabel;
    std::string intermediate_input;

    while (std::getline(file, my_line)) //This code snippet appears to read lines from bench files and process lines containing the keyword INPUT
    {
        if (my_line.find("INPUT") != std::string::npos) //file parsing logic 
        {
            size_t location = my_line.find('(');
            std::string my_nodelabel = my_line.substr(location + 1, my_line.find(')') - location - 1);
            my_nodes[my_nodelabel] = {my_nodelabel, 0, {}};
        } 
        else if (my_line.find("OUTPUT") != std::string::npos) // This code is part of a file parsing logic that identifies lines containing the "OUTPUT" 
        {
            size_t location = my_line.find('(');
            std::string my_nodelabel = my_line.substr(location + 1, my_line.find(')') - location - 1);
            my_nodes[my_nodelabel] = {my_nodelabel, 1, {}};
        } 
        else 
        {
            if ((my_line.find("=") != std::string::npos && my_line.find("(") != std::string::npos)) 
            {
                size_t location = my_line.find('=');
                std::string gatelabel = my_line.substr(0, location - 1);

                if (my_nodes.find(gatelabel) == my_nodes.end() || my_nodes[gatelabel].delay != 1) 
                {
                    my_nodes[gatelabel] = {gatelabel, INFINITY_VAL, {}};
                }

                size_t inputlocation = my_line.find('(');
                size_t endlocation;
                std::vector<std::string> inputs;

                while ((endlocation = my_line.find(')', inputlocation)) != std::string::npos) // It iterates until there are no more closing parentheses.
                {
                    std::string inputlabel = my_line.substr(inputlocation + 1, endlocation - inputlocation - 1);//This line extracts the input label substring from between the opening and closing parentheses.

                    std::istringstream ss(inputlabel);
                    while (std::getline(ss, intermediate_input, ',')) //It iterates through each label and trims any leading or trailing whitespaces.
                    {
                        size_t start_location = intermediate_input.find_first_not_of(" ");
                        size_t end_location = intermediate_input.find_last_not_of(" ");
                        if (start_location != std::string::npos && end_location != std::string::npos) 
                        {
                            intermediate_input = intermediate_input.substr(start_location, end_location - start_location + 1);
                        }

                        my_nodes[intermediate_input].my_edge.push_back({&my_nodes[gatelabel], 1});//Each input node is represented by intermediate_input, and the edge has a weight of 1.
                    }

                    inputlocation = my_line.find('(', endlocation);
                }
            }
        }
    }

    for (const auto& my_node : my_nodes) 
    {
        const std::string& my_nodelabel = my_node.first;
        int total_weight = my_nodes[my_nodelabel].my_edge.size();//This line calculates the total weight (fan-out) for the current node. 
        my_nodes[my_nodelabel].fan_out_delays[my_nodelabel] = total_weight;//The key for the delay is set to the current node's label 
    }
}

int main(int argc, char* argv[]) //Testing the given testcases
{
    if (argc != 4) 
    {
        std::cout << "Incorrect number of arguments" << std::endl;
        return 1;
    }

    std::ifstream file(argv[1]);
    if (!file) 
    {
        std::cout << "Wrong file label" << std::endl;
        return 1;
    }

    std::string filelabel = argv[1];
    std::string source_node = argv[2];
    std::string destination_node = argv[3];

    std::map<std::string, my_node> my_nodes;
    bench_file_parcing(filelabel, my_nodes);

    if (my_nodes.find(source_node) == my_nodes.end() || my_nodes.find(destination_node) == my_nodes.end()) 
    {
        if (my_nodes.find(source_node) == my_nodes.end() && my_nodes.find(destination_node) == my_nodes.end()) 
        {
            std::cerr << "Signal " << source_node << " and " << destination_node << " not found in the " << filelabel << std::endl;
        } 
        else if (my_nodes.find(source_node) == my_nodes.end()) 
        {
            std::cerr << "Signal " << source_node << " not found in the " << filelabel << std::endl;
        } 
        else 
        {
            std::cerr << "Signal " << destination_node << " not found in the " << filelabel << std::endl;
        }
        return 1;
    }

    if (my_nodes[source_node].delay == 1) 
    {
        std::cout << "Start node " << source_node << " is not an input pin." << std::endl;
        return 1;
    }

    if (my_nodes[destination_node].delay == 0) 
    {
        std::cout << "End node " << destination_node << " is not an output pin." << std::endl;
        return 1;
    }

    std::vector<std::string> shortest_dijkstra_path = calculation_dijkstra(my_nodes, source_node, destination_node);

    if (shortest_dijkstra_path.empty() || shortest_dijkstra_path.front() != source_node || shortest_dijkstra_path.back() != destination_node) 
    {
        std::cout << std::endl;
        std::cerr << "No path found between " << source_node << " and " << destination_node << std::endl;
        std::cout << std::endl;
    } 
    else 
    {
        int my_node_total_weight = 0;

        std::cout << std::endl;
        for (size_t i = 0; i < shortest_dijkstra_path.size(); ++i) 
        {
            for (const auto& entry : my_nodes.at(shortest_dijkstra_path[i]).fan_out_delays) 
            {
                my_node_total_weight += entry.second;
            }
        }
        std::cout << "Total weight for the given node: " << my_node_total_weight << std::endl;
       // std::cout << std::endl;
        std::cout << "Shortest path using Dijkstra Algo is:" << std::endl;
        for (size_t i = 0; i < shortest_dijkstra_path.size(); ++i) 
        {
            std::cout << shortest_dijkstra_path[i];
            if (i < shortest_dijkstra_path.size() - 1) 
            {
                std::cout << " , ";
            }
        }
        std::cout << std::endl;

        
    }
    return 0;
}
