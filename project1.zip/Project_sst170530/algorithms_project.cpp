#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <cstdlib>
#include <queue>
#include <limits>
#include <set>
#include <algorithm>
			   

using namespace std;


//all print statements 
void print_adjacency_list(const std::unordered_map<std::string, std::vector<std::pair<std::string, int>>>& adjList) {
    for (const auto& entry : adjList) {
        std::cout << entry.first << " -> ";
        for (const auto& connection_1 : entry.second) {
            std::cout << "[" << connection_1.first << "," << connection_1.second << "] ";
        }
        std::cout << std::endl;
    }
}

//all functions below this 
int checkSignal(const std::string& signal, const std::vector<std::string>& names, const std::string& typeName, const std::string& filename) {
    auto it = std::find(names.begin(), names.end(), signal);

    if (it != names.end()) {
        std::cout << "Name found in " << typeName << " vector: " << *it << std::endl;
        return 0; // Signal found
    } else {
        std::cerr << "Signal not found in file " << filename << ": " << signal << std::endl;
        return 1; // Signal not found
    }
}


using WeightedAdjList = unordered_map<string, vector<pair<string, int>>>;

void dijkstraAlgorithm(const WeightedAdjList& graph, const string& start_node, const string& end_node) {
    unordered_map<string, int> distances;
    unordered_map<string, string> previous_node;
    set<string> visited_nodes;  // Set to keep track of visited nodes
    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;

    const int max_iterations = 100;  // Set maximum iteration limit
    int iterations = 0;

    // Initialize distances and add start node to the priority queue
    for (const auto& entry : graph) {
        distances[entry.first] = numeric_limits<int>::max();
        previous_node[entry.first] = "";
    }

    distances[start_node] = 0;
    pq.push({0, start_node});

    // Dijkstra's algorithm
    while (!pq.empty() && iterations < max_iterations) {
        string current = pq.top().second;
        int current_distance = pq.top().first;
        pq.pop();

        // Check for cycles
        if (visited_nodes.count(current) > 0) {
            continue; // Skip already visited nodes
        }

        visited_nodes.insert(current);  // Mark the current node as visited

        if (current_distance > distances[current]) {
            continue; // Skip outdated entries in the priority queue
        }

        for (const auto& neighbor : graph.at(current)) {
            string next_node = neighbor.first;
            int weight = neighbor.second;
            int new_distance = distances[current] + weight;

            // Check for cycles
            if (visited_nodes.count(next_node) > 0) {
                continue; // Skip paths leading back to visited nodes (break the cycle)
            }

            if (new_distance < distances[next_node]) {
                distances[next_node] = new_distance;
                previous_node[next_node] = current;
                pq.push({new_distance, next_node});
                //cout << "Node visited " << current << " Next " << next_node << endl;
            }
        }

        iterations++;
    }
    cout << "====================================================================" << endl;
    cout << "Dijkstras Algorithm Output : " << endl;
    cout << "==========================" << endl;
    // Print the shortest path
    if (distances[end_node] == numeric_limits<int>::max()) {
        cout << "No path from " << start_node << " to " << end_node << " exists." << endl;
        cout << "========================End of Output==============================="<< endl;
    } else {
        cout << "Shortest path from " << start_node << " to " << end_node << ":" << endl;
        string current_node = end_node;
        vector<string> path;

        while (!current_node.empty()) {
            path.push_back(current_node);
            current_node = previous_node[current_node];
        }

        reverse(path.begin(), path.end());

        for (size_t i = 0; i < path.size() - 1; ++i) {
            cout << path[i] << " -> ";
        }

        cout << path.back() << endl;
        //Uncomment this for checking node weights
        //cout << "Weights:" << endl;
        //for (size_t i = 0; i < path.size() - 1; ++i) {
        //    string source = path[i];
        //    string target = path[i + 1];

        //    for (const auto& neighbor : graph.at(source)) {
        //        if (neighbor.first == target) {
        //            cout << source << " -> " << target << ", Weight: " << neighbor.second << endl;
        //            break;
				 
        //        }
        //    }
        //}
		   
        cout << "====================================================================" << endl;
        cout << "Sum of Distances: " << distances[end_node] << endl;
        cout << "================" << endl;
        cout << "========================End of Output===============================" << endl;
    }
}

void addEdge(std::unordered_map<std::string, std::vector<std::pair<std::string, int>>>& adjList, const std::string& u, const std::string& v, int weight) {
    adjList[u].push_back({v, weight});
}

// Function to extract the signal name from a line
std::string extractSignalName(const std::string& line) {
    size_t start = line.find("(");
    size_t end = line.find(")");

    if (start != std::string::npos && end != std::string::npos && end > start) {
        return line.substr(start + 1, end - start - 1);
    }

    // Return an empty string if the format is not as expected
    return "";
}

void parseFile(const std::string& file_path, std::vector<std::string>& inputnames, std::vector<std::string>& outputnames, std::unordered_map<std::string, std::vector<std::pair<std::string, int>>>& connections,
    std::set<std::string>& allgatenames) {
    // Open a file for reading
    std::ifstream input_file(file_path);
    // Check if the file is open
    if (!input_file.is_open()) {
        cerr << "Wrong file name." << endl;
        exit(EXIT_FAILURE);
    }

    // Read the file line by line
    std::string line;
    while (std::getline(input_file, line)) {
        // Check for "INPUT" gates
        if (line.find("INPUT") != std::string::npos) {
            std::string signal_name = extractSignalName(line);
            if (!signal_name.empty()) {
                inputnames.push_back(signal_name);
                allgatenames.insert(signal_name);
            }
        }

        // Check For "OUTPUT" gates
        if (line.find("OUTPUT") != std::string::npos) {
            std::string signal_name = extractSignalName(line);
            if (!signal_name.empty()) {
                outputnames.push_back(signal_name);
                allgatenames.insert(signal_name);
            }
        }

        // Check for other gates
        size_t equal_position = line.find("=");
        size_t first_non_white_space = line.find_first_not_of(" \t");

        if (equal_position != std::string::npos && first_non_white_space != std::string::npos && line[first_non_white_space] == 'G') {
            std::string gate_line = line;
            // Find the positions of '=' and brackets
            size_t equal_position = line.find('=');
            size_t opening_bracket_pos = line.find('(');
            size_t closing_bracket_pos  = line.find(')');

            // Extract the gate names using substr
            std::string output_gate = line.substr(0, equal_position - 1);
            std::string input_expression = line.substr(opening_bracket_pos + 1, closing_bracket_pos  - opening_bracket_pos - 1);

            // Use stringstream to extract individual input gates
            std::istringstream inputExpressionStream(input_expression);
            std::string input_gate;
			//cout << "Output Gate: " << output_gate << endl;														  
            while (std::getline(inputExpressionStream, input_gate, ',')) {
                // Remove leading and trailing whitespaces
                size_t first = input_gate.find_first_not_of(" \t");
                size_t last = input_gate.find_last_not_of(" \t");
                input_gate = input_gate.substr(first, (last - first + 1));
                // Add edges to the adjacency list
                allgatenames.insert(input_gate);
                allgatenames.insert(output_gate);
                addEdge(connections, input_gate, output_gate, 0);
				//cout << "Input Gate: " << input_gate << endl;
                //printAdjacencyList(adjacencyList);
																		
													
            }
        }
    }

    // Check for errors during reading
    if (input_file.bad()) {
        cerr << "Error reading the file." << endl;
        exit(EXIT_FAILURE);
    }

    // Close the file
    input_file.close();
}

			  
int main(int argc, char* argv[]) {
    if (argc !=4){
        cout << "=======Algorithms Project : Dijkstras Shortest Path Algorithm=======" << endl;
        cout << "       =======Suraag Sunil Tellakula (sst170530)======= " << endl;
        cout << "Incorrect number of arguments " << endl;
        cout << "Command to use : " << argv[0] << " <folder_path>/<filename>  <input gate> <output gate>" << endl;
        return 1;
    }
    cout << "====================================================================" << endl;
    cout << "=======Algorithms Project : Dijkstras Shortest Path Algorithm=======" << endl;
    cout << "       =======Suraag Sunil Tellakula (sst170530)======= " << endl;
    std::string ingate = argv[2];
    std::string outgate = argv[3];
    std::string filename = argv[1];

    // Vectors to store extracted signal names and gate lines
    std::vector<std::string> inputnames;
    std::vector<std::string> outputnames;
    std::set<std::string> allgatenames;
    std::unordered_map<std::string, std::vector<std::pair<std::string, int>>> connections;
																			  

    parseFile(filename, inputnames, outputnames, connections, allgatenames);

    // Print the set of strings
    //cout << "Elements of the set: ";
    //for (const std::string& str : allgatenames) {
    //    cout << str << " ";
    //}
    //cout << endl;

    // Check if ingate is in the set
    auto it1 = allgatenames.find(ingate);
    if (it1 == allgatenames.end()) {
        cerr << "Signal " << ingate << " not found in file " << filename << endl;
        return 1;
														
    }

    // Check if outgate is in the set
    auto it2 = allgatenames.find(outgate);
    if (it2 == allgatenames.end()) {
        cerr << "Signal " << outgate << " not found in file " << filename << endl;
        return 1;
														 
    }

    // Check if ingate is in inputnames
    if (checkSignal(ingate, inputnames, "input", filename) != 0) {
        cerr << "Signal " << ingate << " is not an input pin in file " << filename << endl;
        return 1;
    }

    // Check if outgate is in outputnames
    if (checkSignal(outgate, outputnames, "output", filename) != 0) {
        cerr << "Signal " << outgate << " is not an output pin in file " << filename << endl;
        return 1;
    }

     // Print extracted input signal names
    //cout << "Extracted Input Signal Names:" << endl;
    //for (const auto& inputName : inputnames) {
    //    cout << "INPUTGATE" << inputName << "END" << endl;
    //} 

    // Print extracted output signal names
    //cout << "\nExtracted Output Signal Names:" << endl;
    //for (const auto& outputName : outputnames) {
    //    cout << "OUTPUT GATE" << outputName << "END" << endl;
    //} 

    //print_adjacency_list(connections);
    // Update weights based on the length of the edge list
    for (auto& entry : connections) {
        // Update the weight for each edge based on the length of the list
        for (auto& edge : entry.second) {
            edge.second = entry.second.size();
        }
    }
    //print_adjacency_list(connections);

    for (const auto& outputName : outputnames) {
        connections[outputName] = {{}};
        //cout << outputName << endl;
    }
    //print_adjacency_list(connections);
    
   dijkstraAlgorithm(connections, ingate, outgate);

    return 0;
}