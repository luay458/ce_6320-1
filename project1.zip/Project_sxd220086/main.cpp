# include <iostream>
# include <cstdlib>
# include <string>
# include <vector>
# include <climits>
# include <fstream>
# include <sstream>
# include <cstring>

using namespace std;


// class Node{
// private:
//     // int weight = 1;
//     int currLengthSrc = 0, currLengthSnk = 0;
//     int numSink = 0, numSrc = 0;
//     string* Source = new string[currLengthSrc];
//     string* Sink = new string[currLengthSnk];
// public:
//     Node(string Src, string Snk){
//         bool srcFlg = false;
//         bool snkFlg = false; 
//         for (int i = 0; i < currLengthSrc; i++){
//             if (Src == Source[i]){
//                 srcFlg = true;
//                 break;
//             }
//         }
//         string* tempSrc = new string[currLengthSrc];
//         if (srcFlg == false){
//             for(int i = 0; i < currLengthSrc; i++){
//                 tempSrc[i] = Source[i];
//             }
//             delete[] Source;
//             currLengthSrc++;
//             Source = new string[currLengthSrc];
//             for (int i = 0; i < currLengthSrc - 1; i++){
//                 Source[i] = tempSrc[i];
//             }
//             Source[currLengthSrc - 1] = Src;
//         }
//         delete[] tempSrc;

//         for (int i = 0; i < currLengthSnk; i++){
//             if (Snk == Sink[i]){
//                 snkFlg = true;
//                 break;
//             }
//         }
//         string* tempSnk = new string[currLengthSnk];
//         if (snkFlg == false){
//             for(int i = 0; i < currLengthSrc; i++){
//                 tempSnk[i] = Sink[i];
//             }
//             delete[] Sink;
//             currLengthSnk++;
//             Sink = new string[currLengthSnk];
//             for (int i = 0; i < currLengthSnk - 1; i++){
//                 Sink[i] = tempSnk[i];
//             }
//             Sink[currLengthSnk - 1] = Snk;
//         }
//         delete[] tempSnk;

//     }
//     ~Node(){
//         delete[] Source;
//         delete[] Sink;
//     }

//     void PrintInfo(){
//         cout << "Source:\t";
//         for (int i = 0; i < currLengthSrc; i++){
//             cout << Source[i] << ", ";
//         }
//         cout << endl;

//         cout << "Sink:\t";
//         for (int i = 0; i < currLengthSnk; i++){
//             cout << Sink[i] << ", ";
//         }
//         cout << endl;
//     }
//     void addSrc (string Src){
//         bool srcFlg = false;
//         for (int i = 0; i < currLengthSrc; i++){
//             if (Src == Source[i]){
//                 srcFlg = true;
//                 break;
//             }
//         }
//         string* tempSrc = new string[currLengthSrc];
//         if (srcFlg == false){
//             for(int i = 0; i < currLengthSrc; i++){
//                 tempSrc[i] = Source[i];
//             }
//             delete[] Source;
//             currLengthSrc++;
//             Source = new string[currLengthSrc];
//             for (int i = 0; i < currLengthSrc - 1; i++){
//                 Source[i] = tempSrc[i];
//             }
//             Source[currLengthSrc - 1] = Src;
//         }
//         delete[] tempSrc;
//     }

//     void addSnk(string Snk){
//         bool snkFlg = false; 
//         for (int i = 0; i < currLengthSnk; i++){
//             if (Snk == Sink[i]){
//                 snkFlg = true;
//                 break;
//             }
//         }
//         string* tempSnk = new string[currLengthSnk];
//         if (snkFlg == false){
//             for(int i = 0; i < currLengthSrc; i++){
//                 tempSnk[i] = Sink[i];
//             }
//             delete[] Sink;
//             currLengthSnk++;
//             Sink = new string[currLengthSnk];
//             for (int i = 0; i < currLengthSnk - 1; i++){
//                 Sink[i] = tempSnk[i];
//             }
//             Sink[currLengthSnk - 1] = Snk;
//         }
//         delete[] tempSnk;
//     }

// };
// void printM(int* M, int Msize){
//     for (size_t i = 0; i < Msize; i++){
//         for (size_t j = 0; j < Msize; j++){
//             cout<< M[i][j] << " ";
//         }
//         cout << endl;
//     }
// }

string parseTxt(char* fileName){
    ifstream parser(fileName, ifstream::in);
    string line;
    ostringstream output_stream;

    // remove comments
    while (getline(parser, line))
    {
        if(line[0] != '#' && line != ""){
            output_stream << line << endl;
        }
    }
    
    string output_str;
    output_str = output_stream.str();
    // return output string without comments
    return output_str;
}

bool NodeFound(string Txt, string Nodetype, char* nodeName){
    string line;
    istringstream strmParsTxt(Txt);
    bool found = false;
    stringstream ss;
    string inputsLst;

    int inputNo = 0;
    while (getline(strmParsTxt, line)){
        if (line.find(Nodetype) == 0 ){
            line = line.substr( line.find('(') + 1, line.find(')') - line.find('(') - 1);

            inputsLst = inputNo > 0? inputsLst + " " + line : line;
            inputNo++;
        }
    }

    ss << inputsLst;
    string* inLst = new string[inputNo];

    int i = 0;
    while (ss){
        ss >> inLst[i];
        i++;
    }

    for (int i = 0; i < inputNo; i++){
        if (nodeName == inLst[i]){
            found = true;
            break;
        }
    }

    return found;
}

string rmvCommas(string str1){       
    string str2;
    int len = str1.length();
    for (int i = 0; i < len; i++){
        if(str1[i] != ',')
        str2.push_back(str1[i]);
    }
    return str2;
}



vector <string> getNodes(string parsedTxt){
    string line, outs;
    istringstream StreamTxt(parsedTxt);
    stringstream ss;
    string temp;
    vector <string> nodeVec;
    bool chkFlg;

    while (getline(StreamTxt, line)){    

        if(line.find("INPUT") == string::npos && line.find("OUTPUT") == string::npos){
            ss.clear();
            ss << line;
            ss >> outs; 
            chkFlg = false;
            for (unsigned int i = 0; i < nodeVec.size(); i++){
                if (nodeVec[i] == outs){
                    chkFlg = true;
                    break;
                }
            }
            if(chkFlg == false) nodeVec.push_back(outs);
            
            line = line.substr( line.find('(') + 1, line.find(')') - line.find('(') - 1);
            line = rmvCommas(line);
            ss.clear();
            ss.str("");

            ss << line;
            while (ss >> temp){
                chkFlg = false;
                for (unsigned int i = 0; i < nodeVec.size(); i++){
                    if(temp == nodeVec[i]){
                        chkFlg = true;
                        break;
                    }
                }
                if (chkFlg == false) nodeVec.push_back(temp);
            }
        }

    }
    return nodeVec;
}

int getIndex(vector <string> nodeVec, string nodeName){
    int Ind;
    for (unsigned int i = 0; i < nodeVec.size(); i++){
        if (nodeName ==  nodeVec[i]){
            Ind = i;
        }  
    }
    return Ind;
}



// void printPath(int currentVertex, vector<int> parents, vector <string> NodeVec)
// {

// 	// Base case : Source node has
// 	// been processed
// 	if (currentVertex == NO_PARENT) {
// 		return;
// 	}
// 	printPath(parents[currentVertex], parents, NodeVec);
// 	cout << NodeVec[currentVertex] << " ";
// }


// void printSolution(int startVertex, vector<int> distances,
// 				vector<int> parents, vector<string> NodeVec)
// {
// 	int nVertices = distances.size();
// 	cout << "Vertex\t Distance\tPath";

// 	for (int vertexIndex = 0; vertexIndex < nVertices;
// 		vertexIndex++) {
// 		if (vertexIndex != startVertex) {
// 			cout << "\n" << NodeVec[startVertex] << " -> ";
// 			cout << NodeVec[vertexIndex] << " \t\t ";
// 			cout << distances[vertexIndex] << "\t\t";
// 			printPath(vertexIndex, parents, NodeVec);
// 		}
// 	}
// }



void Dijkstra(string parsTxt, vector <string> NodeVec, string src, string dest){
    istringstream parsedTxtStrm(parsTxt);
    string line;

    stringstream ss;
    string out, temp;

    int m,n;

    int AdjMatrix[NodeVec.size()][NodeVec.size()];
    memset(AdjMatrix,0,sizeof(AdjMatrix));

    while (getline(parsedTxtStrm, line)){
        ss.clear();
        if (line.find('=') != string::npos){
            ss << line;
            ss >> out;

            m = getIndex(NodeVec, out);

            line = line.substr( line.find('(') + 1, line.find(')') - line.find('(') - 1);
            line = rmvCommas(line);
            ss.clear();
            ss.str("");
            ss << line;
            while (ss >> temp){
                n = getIndex(NodeVec, temp);
                AdjMatrix[n][m] = 1;
            }

        }
    }

    // for (size_t i = 0; i < NodeVec.size(); i++){
    //     for (size_t j = 0; j < NodeVec.size(); j++){
    //         cout<< AdjMatrix[i][j] << " ";
    //     }
    //     cout << endl;
    // }

    int weightMatrix[NodeVec.size()][NodeVec.size()];
    memset(weightMatrix,0,sizeof(weightMatrix));
    int weight;
    for (unsigned int i = 0; i < NodeVec.size(); i++){
        weight = 0;
        for (unsigned int j = 0; j < NodeVec.size(); j++){
            if (AdjMatrix[i][j] == 1) weight++;
        }
        for (unsigned int j = 0; j < NodeVec.size(); j++){
            if (AdjMatrix[i][j] == 1) weightMatrix[i][j] = weight;
        }
    }

    // for (size_t i = 0; i < NodeVec.size(); i++){
    //     for (size_t j = 0; j < NodeVec.size(); j++){
    //         cout << weightMatrix[i][j] << " ";
    //     }
    //     cout << endl;
    // }

    // int nVertices = NodeVec.size();
    // vector <int> shortestDistances(nVertices);
    // bool added[nVertices];

    // for (int vertexIndex = 0; vertexIndex < nVertices;
	// 	vertexIndex++) {
	// 	shortestDistances[vertexIndex] = INT_num;
	// 	added[vertexIndex] = false;
	// }
    // int startVertex = getIndex(NodeVec, src);
    // shortestDistances[startVertex] = 0;
    // vector<int> parents(nVertices);
    // parents[startVertex] = NO_PARENT;

    // for (int i = 1; i < nVertices; i++) {    
    //     int nearestVertex = -1;
	// 	int shortestDistance = INT_num;
	// 	for (int vertexIndex = 0; vertexIndex < nVertices;
	// 		vertexIndex++) {
	// 		if (!added[vertexIndex]
	// 			&& shortestDistances[vertexIndex]
	// 				< shortestDistance) {
	// 			nearestVertex = vertexIndex;
	// 			shortestDistance
	// 				= shortestDistances[vertexIndex];
	// 		}
	// 	}

    //     added[nearestVertex] = true;
    //     for (int vertexIndex = 0; vertexIndex < nVertices;
	// 		vertexIndex++) {
	// 		int edgeDistance
	// 			= weightMatrix[nearestVertex]
	// 							[vertexIndex];

	// 		if (edgeDistance > 0
	// 			&& ((shortestDistance + edgeDistance)
	// 				< shortestDistances[vertexIndex])) {
	// 			parents[vertexIndex] = nearestVertex;
	// 			shortestDistances[vertexIndex]
	// 				= shortestDistance + edgeDistance;
	// 		}
	// 	}
    // }

    // printSolution(startVertex, shortestDistances, parents, NodeVec);
    // cout << endl;

    int V = NodeVec.size();
    int dist[V];
    bool checked[V];
    int pred[V];
    

    for (int i = 0; i < V; i++)
		dist[i] = INT_MAX, checked[i] = false, pred[i]= getIndex(NodeVec, src);

    dist[getIndex(NodeVec, src)] = 0;
    // int DestInd = getIndex(NodeVec, dest);
    // vector <int> path[V];
    for (int count = 0; count < V - 1; count++) {
        int min = INT_MAX, min_index;

	    for (int v = 0; v < V; v++)
		    if (checked[v] == false && dist[v] <= min)
			    min = dist[v], min_index = v;
        int u = min_index;
        checked[u] = true;
        for (int v = 0; v < V; v++){
            if (!checked[v] && weightMatrix[u][v] && dist[u] != INT_MAX && dist[u] + weightMatrix[u][v] < dist[v]){
                    dist[v] = dist[u] + weightMatrix[u][v];
                    pred[v] = u;
                    }                  
            
        }
        
    }
    for(int i=0;i<V;i++)
        if(i!=getIndex(NodeVec, src) && i==getIndex(NodeVec, dest)) {
            if(dist[i]==INT_MAX) {cout<<"Path from "<<NodeVec[getIndex(NodeVec, src)]<<" to "<< NodeVec[getIndex(NodeVec, dest)]<<" does not exist."<<endl;exit(EXIT_SUCCESS);}
      cout<<"Shortest distance from "<<NodeVec[getIndex(NodeVec, src)]<<" to "<< NodeVec[getIndex(NodeVec, dest)]<<" = "<<dist[i];
      cout<<"\nPath = "<<NodeVec[i];
      int j=i;
      do {
         j=pred[j];
         cout<<"<-"<<NodeVec[j];
      }while(j!=getIndex(NodeVec, src));}
      cout<<endl;
}

int main(int argc, char** argv){
    if (argc!=4) {cout<< "Incorect number of arguments!!"<<endl;exit(EXIT_SUCCESS);}

    string s;
    vector <string> fileVec;
    fileVec.push_back("c17.bench");
    fileVec.push_back("c432.bench");
    fileVec.push_back("c499.bench");
    fileVec.push_back("c880.bench");
    fileVec.push_back("c1355.bench");
    fileVec.push_back("c1908.bench");
    fileVec.push_back("c2670.bench");
    fileVec.push_back("c3540.bench");
    fileVec.push_back("c5315.bench");
    fileVec.push_back("c6288.bench");
    fileVec.push_back("c7552.bench");
    bool fileFlag = false;
    int n = fileVec.size();
    for (int i = 0; i < n; i++)
    {
        if (fileVec[i]==argv[1]) {
            fileFlag=true;
            break;
            }
    }
    // cout<<fileFlag<<argv[1];
    if (fileFlag==false) {cout<< "Wrong file name"<<endl;exit(EXIT_SUCCESS);}
    vector <string> nodeList;
    s = parseTxt(argv[1]);
    nodeList = getNodes(s);

    bool inFlg, outFlg;

    inFlg = NodeFound(s, "INPUT", argv[2]);
    outFlg = NodeFound(s, "OUTPUT", argv[3]);

    bool InExistFlg = false;
    bool OutExistFlg = false;
    for (unsigned int i = 0; i < nodeList.size(); i++){
        if (nodeList[i]==argv[2]){InExistFlg=true;break;}
    }
    for (unsigned int i = 0; i < nodeList.size(); i++){
        if (nodeList[i]==argv[3]){OutExistFlg=true;break;}
    }
    if (!inFlg && InExistFlg) {cout << "Signal " << argv[2] << " is not an input pin " <<endl;exit(EXIT_SUCCESS);}
    if (!outFlg && OutExistFlg) {cout << "Signal " << argv[3] << " is not an output pin " <<endl;exit(EXIT_SUCCESS);}
    // cout << endl;
    // if (!inChk && !outChk) {cout << "Signal " << argv[2] << " and "<< argv[3] << " not found in the file " << argv[1] << endl;exit(EXIT_SUCCESS);}
    if (!inFlg) {cout << "Signal " << argv[2] << " not found in file " << argv[1] << endl;exit(EXIT_SUCCESS);}
    else if (!outFlg) {cout << "Signal " << argv[3] << " not found in file " << argv[1] << endl;exit(EXIT_SUCCESS);}
    // else cout << "Input and Output Signals found" << endl;
    string source(argv[2]);
    string dest(argv[3]);
    Dijkstra(s, nodeList, source, dest);
    return 0;
}
