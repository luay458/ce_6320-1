#include <algorithm>
#include <climits>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std;

// Function to check if a signal exists in the bench file
bool signalExists(const string &signal, const vector<string> &signals) {
  return find(signals.begin(), signals.end(), signal) != signals.end();
}
// Alias for a map that associates gate names with their input/output
// connections
using Connections = vector<string>;
using Circuits = map<string, Connections>;

// Function to check if a signal is an intermediate node
bool isIntermediateNode(const string &signal, const set<string> &inputSignals,
                        const Circuits &circuit) {
  return (inputSignals.find(signal) == inputSignals.end()) &&
         (circuit.find(signal) != circuit.end());
}

using Circuits = map<string, Connections>;

// Function to extract input and output signals from a line in the benchmark
// file
void extractInputOutput(const string &line, set<string> &inputSignals,
                        Circuits &circuit) {
  stringstream ss(line);
  string checker;
  ss >> checker;

  if (checker == "INPUT" || checker == "OUTPUT") {
    string signalName;
    ss.ignore(1); // Ignore the opening bracket
    getline(ss, signalName, ')');

    // Add to inputSignals set if it's an INPUT
    if (checker == "INPUT") {
      inputSignals.insert(signalName);
    }

    // Initialize the signal in the circuit
    circuit[signalName];
  }
}

// Function to extract connections between gates from a line in the benchmark
// file
void extractConnections(const string &line, Circuits &circuit) {
  string gateName;
  stringstream ss(line);
  ss >> gateName;

  // Read the rest of the line into a temporary string
  string fineRestline;
  getline(ss, fineRestline);

  size_t firstParenthesis = fineRestline.find('(');
  size_t endParenthesis = fineRestline.find(')');

  if (firstParenthesis != string::npos && endParenthesis != string::npos) {
    string inputList = fineRestline.substr(
        firstParenthesis + 1, endParenthesis - firstParenthesis - 1);
    stringstream inputSS(inputList);
    string inputSignal;

    // Iterate over input signals and add connections to the circuit
    while (getline(inputSS, inputSignal, ',')) {
      inputSignal.erase(remove(inputSignal.begin(), inputSignal.end(), ' '),
                        inputSignal.end());
      circuit[inputSignal].push_back(gateName);
    }
  }
}

// Function to read the benchmark file and populate the circuit and inputSignals
void readBenchmaFile(const string &benchmaName, Circuits &circuit,
                     set<string> &inputSignals) {
  ifstream file(benchmaName);
  if (!file.is_open()) {
    throw runtime_error("Cannot open file: " + benchmaName);
  }

  string line;
  while (getline(file, line)) {
    if (line.empty() || line[0] == '#')
      continue;

    extractInputOutput(line, inputSignals, circuit);
    extractConnections(line, circuit);
  }

  file.close();
}

// Function to perform depth-first search to find the shortest path
void dfs(const Circuits &circuit, const set<string> &inputSignals,
         const string &current, const string &goal, map<string, bool> &visited,
         map<string, string> &previous, vector<string> &path) {
  if (current == goal) {
    path.push_back(current);
    return;
  }

  visited[current] = true;

  // Check if the key exists in the map
  if (circuit.find(current) == circuit.end()) {
    return;
  }

  for (const auto &neighbor : circuit.at(current)) {
    if (inputSignals.find(neighbor) != inputSignals.end() &&
        neighbor != current && neighbor != goal) {
      continue;
    }

    if (!visited[neighbor]) {
      previous[neighbor] = current;
      dfs(circuit, inputSignals, neighbor, goal, visited, previous, path);
      if (!path.empty()) {
        path.push_back(current);
        return;
      }
    }
  }
}

// Function to find the shortest path between two gates
vector<string> findShortestPath(const Circuits &circuit,
                                const set<string> &inputSignals,
                                const string &start, const string &goal) {
  map<string, bool> visited;
  map<string, string> previous;
  vector<string> path;

  if (circuit.find(start) == circuit.end()) {
    return {};
  }

  dfs(circuit, inputSignals, start, goal, visited, previous, path);

  reverse(path.begin(), path.end());
  return path;
}

int main(int firstArgument, char *secondArgument[]) {
  // Check if the number of arguments is valid
  while (firstArgument != 4) {
    cout << "No of arguments are not valid. Please try again! " << endl;
    return 1;
  }

  // Create data structures to store circuit information
  Circuits circuit;
  set<string> inputSignals;

  // Extract input arguments
  string finalGate = secondArgument[3];
  string benchmaName = secondArgument[1];
  string initialGate = secondArgument[2];

  // Check if the benchmark file can be opened
  ifstream file(benchmaName);
  if (!file.is_open()) {
    cout << "The file " << benchmaName << " is invalid" << endl;
    return 1;
  }
  file.close();
  vector<string> allSignals;

  try {
    // Read the benchmark file to populate the circuit and inputSignals
    readBenchmaFile(benchmaName, circuit, inputSignals);

    // Find the shortest path between initialGate and finalGate
    vector<string> path =
        findShortestPath(circuit, inputSignals, initialGate, finalGate);

    // Print the result
    if (path.empty()) {
      string line;
      while (getline(file, line)) {
        // Extract signal names from INPUT and OUTPUT lines
        if (line.find("INPUT") != string::npos ||
            line.find("OUTPUT") != string::npos) {
          istringstream iss(line);
          string keyword, signalName;
          iss >> keyword >> signalName;
          allSignals.push_back(signalName);
        }
      }

      // Check if the source signal is not an input or the destination signal is
      // not an output
      if (inputSignals.find(initialGate) == inputSignals.end() ||
          inputSignals.find(finalGate) == inputSignals.end()) {
        cout << "Error: Signal " << initialGate << " is not an input pin or "
             << "Signal " << finalGate << " is not an output pin" << endl;
        return 1;
      }

      // Check if the source signal is an intermediate node
      else if (isIntermediateNode(initialGate, inputSignals, circuit)) {
        cout << "Error: Signal " << initialGate
             << " is an intermediate node and not an input/output node at the "
                "correct location in file "
             << benchmaName << endl;
        return 1;
      }

      // Check if the destination signal is an intermediate node
      else if (isIntermediateNode(finalGate, inputSignals, circuit)) {
        cout << "Error: Signal " << finalGate
             << " is an intermediate node and not an input/output node at the "
                "correct location in file "
             << benchmaName << endl;
        return 1;
      }

    } else {
      cout << "Path from " << initialGate << " to " << finalGate << ": ";
      for (const auto &signal : path) {
        cout << " --> " << signal << " ";
      }
      cout << endl;
    }
  } catch (const runtime_error &e) {
    cout << e.what() << endl;
    return 1;
  }

  return 0;
}
