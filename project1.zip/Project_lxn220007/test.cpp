#include <algorithm>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std;

using Edge = pair<string, int>; // Pair representing an edge and its weight
using Edges = vector<Edge>;
using Graph = map<string, Edges>;

vector<string> dijkstra(const Graph &graph, const set<string> &inputNodes,
                        const string &source, const string &target) {
  set<pair<int, string>> pq; // Set ordered by distance
  map<string, int> distance;
  map<string, string> previous;

  for (const auto &node : graph) {
    distance[node.first] = numeric_limits<int>::max();
    previous[node.first] = "";
  }

  distance[source] = 0;
  pq.insert({0, source});

  while (!pq.empty()) {
    string current = pq.begin()->second;
    pq.erase(pq.begin());

    for (const auto &neighbor : graph.at(current)) {
      string nextNode = neighbor.first;
      int weight = neighbor.second;
      int newDistance = distance[current] + weight;

      if (newDistance < distance[nextNode]) {
        pq.erase({distance[nextNode], nextNode}); // Remove old entry
        distance[nextNode] = newDistance;
        previous[nextNode] = current;
        pq.insert({newDistance, nextNode}); // Insert updated entry
      }
    }
  }

  // Reconstruct the path
  vector<string> path;
  string current = target;
  while (!current.empty()) {
    path.push_back(current);
    current = previous[current];
  }

  reverse(path.begin(), path.end());

  return path;
}

void parseCircuitFile(const string &fileName, Graph &graph,
                      set<string> &inputNodes) {
  ifstream file(fileName);
  if (!file.is_open()) {
    throw runtime_error("Wrong file name");
  }

  string line;
  while (getline(file, line)) {
    if (line.empty() || line[0] == '#')
      continue;

    stringstream ss(line);
    string token;
    ss >> token;

    if (token == "INPUT" || token == "OUTPUT") {
      string nodeName;
      ss.ignore(1); // Ignore the opening bracket
      getline(ss, nodeName, ')');

      // Add to inputNodes set if it's an INPUT
      if (token == "INPUT") {
        inputNodes.insert(nodeName);
      }

      // Initialize the node in the graph
      graph[nodeName];
    } else {
      string gateName = token;
      getline(ss, line);

      size_t openParen = line.find('(');
      size_t closeParen = line.find(')');

      if (openParen != string::npos && closeParen != string::npos) {
        string inputList =
            line.substr(openParen + 1, closeParen - openParen - 1);
        stringstream inputSS(inputList);
        string inputGate;

        // Modify the loop to read both gate names and edge weights
        while (getline(inputSS, inputGate, ',')) {
          inputGate.erase(remove(inputGate.begin(), inputGate.end(), ' '),
                          inputGate.end());

          // Check if there is an edge weight provided
          size_t weightStart = inputGate.find('(');
          if (weightStart != string::npos) {
            size_t weightEnd = inputGate.find(')', weightStart);
            if (weightEnd != string::npos) {
              // Extract the edge weight
              string weightStr = inputGate.substr(weightStart + 1,
                                                  weightEnd - weightStart - 1);
              int edgeWeight = stoi(weightStr);
              inputGate.erase(weightStart, weightEnd - weightStart + 1);
              graph[inputGate].push_back({gateName, edgeWeight});
            }
          } else {
            // If no edge weight provided, default to 1
            graph[inputGate].push_back({gateName, 1});
          }
        }
      }
    }
  }

  file.close();
}

int main(int argc, char *argv[]) {
  if (argc != 4) {
    cout << "Incorrect number of arguments" << endl;
    return 1;
  }

  string fileName = argv[1];
  string sourceNode = argv[2];
  string targetNode = argv[3];

  Graph graph;
  set<string> inputNodes;

  try {
    parseCircuitFile(fileName, graph, inputNodes);

    // Check if sourceNode and targetNode are in the graph
    if (graph.find(sourceNode) == graph.end() ||
        graph.find(targetNode) == graph.end()) {
      cout << "Signal "
           << (graph.find(sourceNode) == graph.end() ? sourceNode : targetNode)
           << " not found in file " << fileName << endl;
      return 1;
    }

    vector<string> path = dijkstra(graph, inputNodes, sourceNode, targetNode);

    if (path.empty()) {
      cout << "No path found from " << sourceNode << " to " << targetNode
           << endl;
    } else {
      cout << "Path from " << sourceNode << " to " << targetNode << ": ";
      for (const auto &node : path) {
        cout << node << " ";
      }
      cout << endl;
    }
  } catch (const exception &e) {
    cout << e.what() << endl;
    return 1;
  }

  return 0;
}
