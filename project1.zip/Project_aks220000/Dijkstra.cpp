#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <queue>
#include <climits>
#include <set> 
#include <string> 
#include <list>
#include <map>
#include <limits>


// Define a structure to represent gates
struct Gate {
    std::string name;
    std::vector<std::string> inputs;
    std:: string type;
    std:: string nodeName;
    int delay;
};

std::list<Gate> nodes;  // List to store nodes or gate names
std::list<Gate> inputGates;  // List to store input gates
std::list<Gate> outputGates;  // List to store output gates

class Graph {
public:
    std::unordered_map<std::string, std::vector<std::string>> adjList;

    void addEdge(const std::string &from, const std::string &to) {
        adjList[from].push_back(to);
    }

    void printGraph() const {
        for (const auto &entry : adjList) {
            std::cout << entry.first << " -> ";
            for (const auto &neighbor : entry.second) {
                std::cout << neighbor << " ";
            }
            std::cout << std::endl;
        }
    }

    std::unordered_map<std::string, int> dijkstra(const std::string &source, const std::unordered_map<std::string, int> &fanoutCounts,
                                                  std::unordered_map<std::string, std::string> &previous) const {
        std::unordered_map<std::string, int> dist;
        std::priority_queue<std::pair<int, std::string>, std::vector<std::pair<int, std::string>>, std::greater<std::pair<int, std::string>>> pq;


        // Initialize distances
        for (const auto &entry : adjList) {
            const std::string &gate = entry.first;
            dist[gate] = INT_MAX;
            previous[gate] = "";  // Initialize previous for path reconstruction
        }

        dist[source] = 0;
        pq.push({0, source});

        while (!pq.empty()) {
            std::string u = pq.top().second;
            pq.pop();

            for (const auto &v : adjList.at(u)) {
                int weight = fanoutCounts.at(v);
                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.push({dist[v], v});
                    previous[v] = u;  // Update previous for path reconstruction
                }
            }
        }

        return dist;
    }

    // Function to reconstruct the shortest path from source to destination
    std::vector<std::string> reconstructPath(const std::string &source, const std::string &destination,
                                             const std::unordered_map<std::string, std::string> &previous) const {
        std::vector<std::string> path;
        std::string current = destination;
        int flag = 0;

        // Backtrack from destination to source

        while (current != source) {
            path.push_back(current);
            if(previous.at(current) == ""){
                flag = 1;
                break;
            }

            current = previous.at(current);
        }

        if(flag == 0){

            // Add the source gate to the path
            path.push_back(source);

            // Reverse the path to get it in the correct order
            std::reverse(path.begin(), path.end());
        
            return path;
        }
        else{
            path = {};
            return path;
        }
    }
};



Graph parseBenchFile(const std::string &filename) {
    Graph graph; // Create an instance of the Graph class
    try{
    std::ifstream file(filename); // Open the file specified by the filename parameter
    std::string line; // Variable to store each line read from the file

    // Check if the file was successfully opened
    if (!file.is_open()) {
        std::cerr << "Wrong File Name: " << filename << std::endl;
        exit(EXIT_FAILURE);
    }

    // Variable to store the output gate encountered

    // Loop through each line in the file
    while (std::getline(file, line)) {
        // Skip comments, empty lines, and lines with "INPUT"
        if (line.empty() || line[0] == '#' || line.find("INPUT") != std::string::npos)
            continue;

        // Check if "OUTPUT" is present in the line
        size_t outputPos = line.find("OUTPUT");
        std::string outputGate;
        if (outputPos != std::string::npos) {

            // Extract the output gate and remove parentheses
            outputGate = line.substr(outputPos + 6); // Assuming "OUTPUT" is followed by a space
            outputGate.erase(std::remove(outputGate.begin(), outputGate.end(), '('), outputGate.end());
            outputGate.erase(std::remove(outputGate.begin(), outputGate.end(), ')'), outputGate.end());
            
            graph.adjList[outputGate] = {}; // Add an empty vector for the output gate

            continue; // Skip the rest of the processing for this line
        }

        // Use istringstream to tokenize the line
        std::istringstream iss(line);
        std::string token, gate;
        std::vector<std::string> tokens;

        // Tokenize the line using '(' as the delimiter
        while (std::getline(iss, token, '(')) {
            tokens.push_back(token);
        }

        // Check if there are at least two tokens
        if (tokens.size() >= 2) {

            // Process the first token to extract gate information
            std::istringstream inputs(tokens[1]);
            gate = tokens[0].substr(0, tokens[0].find('=') - 1);
            
            // Tokenize the inputs using ',' as the delimiter
            while (std::getline(inputs, token, ',')) {

                // Clean up the token by removing ')' and spaces
                token.erase(std::remove(token.begin(), token.end(), ')'), token.end());
                token.erase(std::remove(token.begin(), token.end(), ' '), token.end());
                
                // Add an edge to the graph connecting the input token to the gate
                graph.addEdge(token, gate);
            }
        }
    }

     // Close the file after processing
     file.close();
     } catch (const std::exception &e) {
        std::cerr << "Error while parsing file: " << filename << std::endl;
        exit(EXIT_FAILURE);
    }
    // Return the constructed graph
    return graph;
}
// Function to calculate fanout for each gate
std::unordered_map<std::string, int> calculateFanout(const Graph& graph) {
    std::unordered_map<std::string, int> fanoutCount;

    for (const auto& entry : graph.adjList) {
        const std::string& gate = entry.first;
        const std::vector<std::string>& connections = entry.second;
        fanoutCount[gate] = connections.size();
    }

    return fanoutCount;
}


int main(int argc, char *argv[]) {
    
    // Check if the correct number of command line arguments are provided
    if (argc != 4) {
        std::cerr << "Incorrect number of arguments" << std::endl;
        return 1; // Return error code
    }
      
    else {
        std::string fileName = argv[1];
        std::string inputGate = argv[2];
        std::string outputGate = argv[3];
        std::string sourceGate = inputGate;
        std::string destinationGate = outputGate;


     Graph graph;
      
      try {
          graph = parseBenchFile(fileName);
       } catch (const std::exception &e) {
          std::cerr << "Wrong file name " << fileName << std::endl;
         exit(EXIT_FAILURE);
        }

    // Check if input and output gates exist and are of the correct type
        bool inputFound = graph.adjList.find(inputGate) != graph.adjList.end();
        bool outputFound = graph.adjList.find(outputGate) != graph.adjList.end();

        if (!inputFound) {
            std::cout << "Signal " << inputGate << " not found in file " << fileName << std::endl;
        }

        if (!outputFound) {
            std::cout << "Signal " << outputGate << " not found in file " << fileName << std::endl;
        }

        if (inputFound && outputFound) {
            // Calculate fanout for each gate
            std::unordered_map<std::string, int> fanoutCounts = calculateFanout(graph);

            // To store the previous nodes for path reconstruction
            std::unordered_map<std::string, std::string> previous;

            // Perform Dijkstra's algorithm to find the shortest path
            std::unordered_map<std::string, int> shortestDistances = graph.dijkstra(sourceGate, fanoutCounts, previous);

            // Reconstruct and print the shortest path from source to destination
            std::vector<std::string> shortestPath = graph.reconstructPath(sourceGate, destinationGate, previous);

            std::cout << "\nShortest Path from " << sourceGate << " to " << destinationGate << ":\n";

            if (shortestPath.empty()) {
                std::cout << "Path does not exist!! Please change your input and output gates." << std::endl;
            } else {
                for (const auto &gate : shortestPath) {
                    std::cout << gate << " ";
                }
                std::cout << std::endl;
            }
        }
    }
    return 0;
}