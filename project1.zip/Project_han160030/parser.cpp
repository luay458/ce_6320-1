#include <string>
#include <cctype>
#include <sstream>
#include <vector>
#include "parser.h"

using std::string;
using std::stringstream;
using std::vector;

int parse_first_int(string line) {
    int acc = 0; //Accumulator; Stores int being read in
    bool isPrevCharDigit = false; //If current char is a digit but prev was, the current int is complete

    //Iterate through every char in the line
    for (uint i = 0; i < line.size(); i++) {
        if (isdigit(line.at(i))) {
            acc *= 10; //Shift current digits 1 to the left, base 10
            acc += line.at(i)-48; //Add latest digit
            isPrevCharDigit = true;
        }

        //If the current char is not a digit but the previous was, the int is complete
        else if (!isdigit(line.at(i)) && isPrevCharDigit) {
            break;
        }

    }

    return acc;
}

vector<int> parse_all_ints(std::string line) {
    vector<int> rv; //return value, vector of ints found in the line
    int acc = 0; //Accumulator, stores int being read in
    bool isPrevCharDigit = false; //If current char is a digit but prev was, the current int is complete

    for (uint i = 0; i < line.size(); i++) {
        if (isdigit(line.at(i))) {
            acc *= 10; //Shift current digits 1 to the left, base 10
            acc += line.at(i)-48; //Add latest digit
            isPrevCharDigit = true;
        }
        //If the current char is not a digit but the previous was, the int is complete
        else if (!isdigit(line.at(i)) && isPrevCharDigit) {
            rv.push_back(acc);
            acc = 0;
            isPrevCharDigit = false;
        }
    }

    return rv;
}