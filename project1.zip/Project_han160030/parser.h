#ifndef PARSER_H
#define PARSER_H

#include <string>
#include <vector>

/* Library to assist with parsing the benchmark text file */

//Returns the first integer in a string
int parse_first_int(std::string line);

//Returns a vector with all the ints found in a line
std::vector<int> parse_all_ints(std::string line);

#endif