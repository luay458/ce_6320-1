//CE 6320 Project
//Hamzah Nawfer

#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "graph.h"
#include "parser.h"
#include "path.h"

using std::cout;
using std::endl;
using std::ifstream;
using std::vector;

int main(int argc, char **argv) {

	// int gin, gout;
	vector<int> path;

	//Verify 3 command line inputs
	if (argc != 4) {
		cout << "Incorrect number of arguments" << endl;
		cout << "Format: ./iscas cX.bench inputGate outputGate" << endl;
		exit(1);
	}

#if 0
	//Debug: Output cmd line args
	cout << "File Name   = " << argv[1] << endl;
	cout << "Input Gate  = " << argv[2] << endl;
	cout << "Output Gate = " << argv[3] << endl << endl;
#endif

	Graph graph(argv[1]);

	// gin = parse_first_int(argv[2]);
	// gout = parse_first_int(argv[3]);

	path = shortest_path(&graph, argv[1], argv[2], argv[3]);
	printPath(path);
	//Path found without error
	// if (path >= 0 && path < INF) {
	// 	cout << "Shortest path from " << argv[2] << " to " << argv[3] << " = " << path << endl;
	// }
	// else if (path == INF) {
	// 	cout << "No path exists from " << argv[2] << " to " << argv[3] << endl;
	// }
	// else if (path == -2) {
	// 	cout << "Djikstra's Algorithm iterated " <<  MAX_DJ_IT << "times, exiting." << endl;
	// }

	return 0;
}