#include <iostream>
#include <fstream>
#include <string>
#include "circuit.h"
#include "graph.h"

using std::cout;
using std::endl;
using std::string;
// using std::vector;

//Constructor: Parse file and populate the matrix accordingly
Graph::Graph(char * fname) {
#if 0
    std::cout << "Graph Init\tINF=" << INF << std::endl;
#endif
    
    //Extract information from the text file and store it into an object
    Circuit circuit(fname);
    nodecount = circuit.getNodeCount();
    // vector<int> inputs;
    // vector<Circuit.NodeInputs> nodeinputs;
    vector<NodeInputs> nodeinputs;

    //Allocate mem for an NxN matrix
    // cout << "Allocating " << nodecount << "x" << nodecount << " matrix" << endl;
    matrix = new int * [nodecount];
    for (int i = 0; i < nodecount; i++) {
        // cout << "Allocating matrix[" << i << "]" << endl;
        matrix[i] = new int[nodecount];
    }

    //Fill matrix with initial values of INF
    for (int i = 0; i < nodecount; i++) {
        for (int k = 0; k < nodecount; k++) {
            matrix[i][k] = INF;
        }
    }

    //Retrieve the inputs and nodeinputs vectors
    inputs = circuit.getInputs();
    outputs = circuit.getOutputs();
    nodeinputs = circuit.getNodeInputs();

    //Populate the nodeidx map; Go thru vector inputs then vector nodeInputs
    for (uint i = 0; i < inputs.size(); i++) {
        nodeidx[inputs.at(i)] = i;
    }
    for (uint i = 0; i < nodeinputs.size(); i++) {
        nodeidx[nodeinputs.at(i).id] = i + inputs.size();
    }

#if 0
    //Debug: Print map
    std::map<int,int>::iterator it;
    int max = 0; //Tracks largest idx, to verify it is nodecount-1
    cout << endl << "map nodeidx: " << endl;
    for (it = nodeidx.begin(); it != nodeidx.end(); it++) {
        cout << "Gate " << it->first << " = idx " << it->second << endl;
        if (it->second > max)
            max = it->second;
    }
    cout << "Highest idx = " << max << endl;
#endif

    //Populate the matrix with weights based on circuit object
    std::map<int,int>::iterator it;
    NodeInputs currnode; 
    int d1, d2; //current idx when loading matrix
    // for (it = nodeidx.begin(); it != nodeidx.end(); it++) {
    for (uint i = 0; i < nodeinputs.size(); i++) {

        //Convert gate values to matrix idx values
        currnode = nodeinputs.at(i);
        currnode.id = nodeidx.at(currnode.id);
        for (uint j = 0; j < currnode.inputgates.size(); j++) {
            currnode.inputgates.at(j) = nodeidx.at(currnode.inputgates.at(j));
        }

#if 0
        //Debug: Print new node
        cout << "idx " << currnode.id << "(";
        for (uint k = 0; k < currnode.inputgates.size(); k++) {
            cout << "i" << currnode.inputgates.at(k) << ", ";
        }
        cout << ")" << endl;
#endif

        //Use input node as 1st dimension and currnode id as 2nd dimension
        for (uint l = 0; l < currnode.inputgates.size(); l++) {
            d1 = currnode.inputgates.at(l);
            d2 = currnode.id;
            //TODO account for weights
            matrix[d1][d2] = 1; //For now, ignore weights
            update_weights(matrix[d1], nodecount);
#if 0
            //Debug output: indicate what edge added
            cout << "Added edge (i" << d1 << ",i" << d2 << ")" << endl;
#endif
        }

    }

#if 0
    //Debug: Print all edges in matrix
    //Iterate thru matrix and show all edges
    for (int i = 0; i < nodecount; i++) {
        for (int j = 0; j < nodecount; j++) {
            if (matrix[i][j] != INF) {
                cout << "(i" << i << ",i" << j << ")" << " = " << matrix[i][j] << endl;
            }
        }
        cout << endl;
    }
#endif
}

Graph::~Graph(void) {
    // cout << endl << "Graph De-Init: " << nodecount << "x" << nodecount << " matrix" << endl;

    // for (int i = nodecount-1; i > 0; i--) {
    for (int i = 0; i < nodecount; i++) {
        // cout << "Deallocating matrix[" << i << "]" << endl;
        delete matrix[i];
    }
        // cout << "Deallocating matrix" << endl;
    delete matrix;
    
}

void Graph::update_weights(int * array, int len) {

    vector<int> finitevals; //Stores indices of finite values in the array

    for (int i = 0; i < len; i++) {
        if (array[i] != INF) {
            finitevals.push_back(i);
        }
    }

    //If fanout of node in this row is 1, nothing to update
    if (finitevals.size() == 1) {
        return;
    }

    for (uint i = 0; i < finitevals.size(); i++) {
        array[finitevals.at(i)] = finitevals.size();
    }

}
int Graph::getNodeCount(void) {
    return nodecount;
}

std::vector<int> Graph::getAllInputs(void) {
    return inputs;
}

std::vector<int> Graph::getAllOutputs(void) {
    return outputs;
}

vector<int> Graph::getNodeIds(void) {
    vector<int> rv;
    std::map<int,int>::iterator it = nodeidx.begin();

    for (; it != nodeidx.end(); it++) {
        rv.push_back(it->first);
    } 

    return rv;
}

vector<int> Graph::getNodeOutputs(int node) {
    vector<int> nodeOutputs; //List of node IDs the curr node outputs to
    int idx = nodeidx[node]; //Get node index from node ID
    // vector<int> nodeOutputsIdx; //List of node IDXs, will convert to node IDs before returning

    //Iterate thru currnode's row in matrix
    for (int i = 0; i < nodecount; i++) {
        if (matrix[idx][i] != INF) {
            nodeOutputs.push_back(idxToId(i));
        }
    }

    return nodeOutputs;
}

int Graph::idxToId(int idx) {
    //Iterate thru map until idx found in value, then return key

    std::map<int,int>::iterator it = nodeidx.begin();

    for (; it != nodeidx.end(); it++) {
        if (it->second == idx) {
            return it->first;
        }
    } 

    return -1; //idx not in map
}