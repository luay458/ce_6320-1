#ifndef PATH_H
#define PATH_H

#include <vector>
#include "graph.h"

const int MAX_DJ_IT = 2000;

//Uses Djikstra's to find shortest path from gin to gout in the given graph
//Params: Graph, input gate, output gate
//Returns: Shortest path in the graph from Gin to Gout, < 0 = err
std::vector<int> shortest_path(Graph * graph, char * fname, char * cGin, char * cGout);

//Pass in vector from shortest_path, and get the values printed
void printPath(std::vector<int> path);

#endif