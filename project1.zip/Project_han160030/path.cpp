#include <iostream>
#include <iomanip>
#include <vector>
#include <limits>
#include "parser.h"
// #include "graph.h"
#include "path.h"

using std::cout;
using std::endl;
using std::vector;

/************************** Private Structs ******************************/
typedef struct {
    int vertex; //ID of current node
    bool visited; //T/F, if this node has been visited yet
    int distance; //Shortest distance from the starting vertex
    int prev; //ID of previous node
} TableEntry;


/*********************** Private Local Variables *************************/
static TableEntry * table;
static int nodecount = 0;


/********************** Private Function Headers *************************/
//Initialize table based on the given graph
static void initTable(Graph * graph, int gin);

//Deinit table, deallocate memory
static void deinitTable(void);

//Debug function to see table of vertices
//static void printTable(void);

//Determines if the given input and output nodes are valid
//rv 0 = no error, nodes valid; rv 1 = invalid node
static int verifyNodes(Graph * graph, char * fname, char * cGin, char * cGout);

//Run 1 iteration of Djikstra's algorithm
//Pass in current node being visited, returns next node to visit
static int djikstra(Graph * graph, int currnode);

//Pass in node id, returns pointer to it's table entry
static TableEntry* getTableEntry(int nodeid);

//Returns vector with the path in reverse order
// vector = {dist, gout, path_n, path_n-1, ..., path_0, gin}
static vector<int> getOutput(int gin, int gout);

/****************** Private Function Implementation **********************/
static void initTable(Graph * graph, int gin) {
    vector<int> nodeids;

    nodecount = graph->getNodeCount();
    // table = (TableEntry *)malloc(nodecount * sizeof(TableEntry));
    table = new TableEntry [nodecount];

#if 0
    cout << "sizeof(int) = " << sizeof(int) << endl;
    cout << "sizeof(TableEntry) = " << sizeof(TableEntry) << endl;
    cout << "sizeof(table) = " << sizeof(table) << endl;
#endif

    //Retrieve list of node IDs
    nodeids = graph->getNodeIds();

    //Iterate through each TableEntry and fill in it's values
    for (int i = 0; i < nodecount; i++) {
        (table+i)->vertex = nodeids.at(i);
        (table+i)->visited = false;

        if (nodeids.at(i) == gin) {
            (table+i)->distance = 0;
        } else {
            (table+i)->distance = INF;
        }

        (table+i)->prev = -1;
    }

}

static void deinitTable(void) {
    // cout << "deinitTable()" << endl;
    // free(table);
    delete table;
}

/*
static void printTable(void) {

    int currdist;

    //Print header
    cout << endl << "Vertex|Visited|Distance|Previous" << endl;
    cout <<         "------|-------|--------|--------" << endl;

    for (int i = 0; i < nodecount; i++) {
        currdist = (table+i)->distance;

        cout << std::left;
        cout << " " << std::setw(5) << (table+i)->vertex << "|";
        cout << "  " << std::setw(5) << (((table+i)->visited) ? "T" : "F") << "|";
        cout << "  " << std::setw(6);// << ((currdist == INF) ? "INF" : currdist) << "|";
        if (currdist == INF) cout << "INF" << "|";
        else cout << currdist << "|";
        cout << "  " << std::setw(6);// << (table+i)->prev << endl;
        if ((table+i)->prev == -1) cout << "NULL" << endl; 
        else cout << (table+i)->prev << endl;
    }
    cout << "------|-------|--------|--------" << endl;
} 
*/

static int verifyNodes(Graph * graph, char * fname, char * cGin, char * cGout) {
    int gin = parse_first_int(cGin);
    int gout = parse_first_int(cGout);
    vector<int> inputs = graph->getAllInputs();
    vector<int> outputs = graph->getAllOutputs();
    bool gin_foundinput = false, gout_foundinput = false; //Bool - if gates found in input list
    bool gin_foundoutput = false, gout_foundoutput = false; //Bool - if gates found in output list

#if 0
    for (uint i = 0; i < outputs.size(); i++) {
        cout << "OUTPUT(G" << outputs.at(i) << ")" << endl;
    }
#endif

    //Check list of inputs for gin and gout; Iterate thru list until list complete or both gin and gout found
    for (uint i = 0; i < inputs.size() && (!gin_foundinput || !gout_foundinput); i++) {
        if (inputs.at(i) == gin) {
            gin_foundinput = true;
        }
        if (inputs.at(i) == gout) {
            gout_foundinput = true;
        }
    }

    //if Gin not found in input list
    // if (!gin_foundinput) {
    //     cout << "Signal " << cGin << " not found in file " << fname << endl;
    //     return 1;
    // }
    // //If Gout found in input list
    // else if (gout_foundinput) {
    //     cout << "Signal " << cGout << "is not an output pin" << endl;
    //     return 1;
    // }

    for (uint i = 0; i < outputs.size() && (!gin_foundoutput || !gout_foundoutput); i++) { 
        if (outputs.at(i) == gin) {
            gin_foundoutput = true;
        }
        if (outputs.at(i) == gout) {
            gout_foundoutput = true;
        }
    }

    //If Gin found in output list and not input list (prevents edge case of lone gate, both input and output)
    if (gin_foundoutput && !gin_foundinput) {
        cout << "Signal " << cGin << " is not an input pin" << endl;
        return -1;
    }
    //If Gout found in input list and not output list (prevents edge case of lone gate, both input and output)
    else if (gout_foundinput && !gout_foundoutput) {
        cout << "Signal " << cGout << " is not an output pin" << endl;
        return -1;
    }
    else if (!gin_foundinput) {
        cout << "Signal " << cGin << " not found in file " << fname << endl;
        return -1;
    }
    //If Gout not found in output list
    else if (!gout_foundoutput) {
        cout << "Signal " << cGout << " not found in file " << fname << endl;
        return -1;
    }

    return 0; //No error, nodes verified
}

static int djikstra(Graph * graph, int currnode) {
    vector<int> neighbors; //List of all nodes the curr node is outputting to
    vector<int> newneighbors; //List of all UNVISITED nodes the curr node is outputting to
    TableEntry * t_ptr; //Pointer to curr node entry in table
    TableEntry * tn_ptr; //Pointer to neighbor vertex in table being analyzed
    int weight;
    int nextnode; //ID of next node to visit
    // cout << endl << "Visiting " << currnode << endl;

    //Find all neighbors of currnode
    neighbors = graph->getNodeOutputs(currnode);

    //Filter neighbors list to only the unvisited neighbors
    for (uint i = 0; i < newneighbors.size(); i++) {
        t_ptr = getTableEntry(newneighbors.at(i));
        if (t_ptr->visited == false) {
            newneighbors.push_back(neighbors.at(i)); //If neighbor is unvisited, add it to list of new neighbors
        }
    }
    weight = neighbors.size();
    // cout << "Weight = " << weight << endl;

    //Get current table entry and mark it as visited if there are no other unvisited inputs to the node (that input could be a shorter path!)
    t_ptr = getTableEntry(currnode);
    t_ptr->visited = true;

    //For each vertex in neighbors list:
    //  Get pointer to TableEntry for that vertex
    //  If weight < current distance:
    //     Update distance and prev node
    for (uint i = 0; i < neighbors.size(); i++) {
        tn_ptr = getTableEntry(neighbors.at(i));
        // cout << "if(" << weight + t_ptr->distance << " < " << tn_ptr->distance << ") {";
        if ((weight + t_ptr->distance) < (tn_ptr->distance)) {
            // cout << "TRUE" << endl;
            tn_ptr->distance = weight + t_ptr->distance;
            tn_ptr->prev = currnode;
            tn_ptr->visited = false; //
        }
    }
    
    //Determine next node to visit
    //If node has unvisited neighbors, visit the first one
    if (newneighbors.size() != 0) {
        nextnode = newneighbors.at(0);
    }
    //If no unvisited neighbors, find the first unvisited node with finite distance
    else {
        // cout << "Node " << currnode << " has no neighbors, checking for unvisited nodes with finite distance" << endl;
        nextnode = -1; //no unvisited nodes with finite distance, Djikstra's complete
        for (int i = 0; i < nodecount; i++) {
            t_ptr = (table+i);
            // cout << "v" << t_ptr->vertex << ", dist " << t_ptr->distance << ", visited " << t_ptr->visited << endl;
            if ((t_ptr->distance != INF) && (t_ptr->visited == false)) {
                nextnode = t_ptr->vertex;
                // cout << "next node = " << nextnode << endl;
                break;
            }
        }
    }
    // cout << "returning " << nextnode << endl;
    return nextnode;

    //All output edges will have the same weight so choose the first neighbor in the list as next to visit
    // return (neighbors.size() == 0 ? -1 : neighbors.at(0));
    // return neighbors.at(0); 
}

static TableEntry* getTableEntry(int nodeid) {
    TableEntry * t_it; //table iterator

    for (int i = 0; i < nodecount; i++) {
        t_it = table+i;
        if (t_it->vertex == nodeid) {
            return t_it;
        }
    }

    cout << "ERROR: Node ID " << nodeid << " not found in table" << endl;
    return table; //Failsafe return, this should never run
}

static vector<int> getOutput(int gin, int gout) {
    vector<int> path;
    TableEntry * t_ptr;

    //Start with table entry for gout
    t_ptr = getTableEntry(gout);
    path.push_back(t_ptr->distance);
    path.push_back(t_ptr->vertex);

    while (t_ptr->prev != -1) {
        t_ptr = getTableEntry(t_ptr->prev);
        path.push_back(t_ptr->vertex);
    }

    //Handles edge case of no path from gin to gout
    if (path.back() != gin) {
        path.push_back(gin);
    }

    return path;

}
/******************** Exposed Function Implementation ********************/
vector<int> shortest_path(Graph * graph, char * fname, char * cGin, char * cGout) {
    vector<int> rv; //Store shortest path length here
    int gin = parse_first_int(cGin);
    int gout = parse_first_int(cGout);
    int d_it = 0; //iterations of djikstra's run so far, exit once threshold reached; prevents infinite loops
    int currnode = gin; //Current node being visited by Djikstra's algo

#if 0 
    cout << "gin = " << gin << "\tgout = " << gout << endl;
#endif

    //Init table
    initTable(graph, gin);
#if 0
    printTable();
#endif

    //If nodes invalid, ret err code
    if(verifyNodes(graph, fname, cGin, cGout) != 0) {
        deinitTable();
        rv.push_back(-1);
        return rv;
    }

    //Run djikstra's until currnode = -1 (stop) or currnode = gout (run 1 more time)
    while ((currnode != -1) /*&& (currnode != gout)*/ && (d_it < MAX_DJ_IT)) {
        currnode = djikstra(graph, currnode);
        d_it++;
        // printTable();
    }

    // if (currnode == gout) {
    //     djikstra(graph, currnode);
    //     printTable();
    // }
    if (d_it >= MAX_DJ_IT) {
        rv.push_back(-2);
        return rv;
    }

    //Get distance to gout, push it onto rv;
    rv = getOutput(gin, gout);
    // rv.push_back(getTableEntry(gout)->distance);

    // for (uint i = 0; i < rv.size(); i++) {
    //     cout << "rv[" << i << "] = " << rv.at(i) << endl;
    // }

    // printTable(); //Print final table
    deinitTable();
    return rv;
}

void printPath(vector<int> path) {

    //Handle edge cases
    switch(path.front()) {
        //No path from gin to gout
        case INF: 
            cout << "G" << path.back() << "->G" << path.at(1) << ": shortest path is INF" << endl;
            return;
        //Node validation failed, error output handled by verifyNodes();
        case -1:
            return; 
        case -2:
            cout << "Djikstra's Algorithm iterated " <<  MAX_DJ_IT << " times, exiting." << endl;
            return;
    }

    //Print path, iterate thru path vector backwards
    cout << "G" << path.back() << "->G" << path.at(1) << ": shortest path is G" << path.back();
    for (uint i = path.size()-2; i > 0; i--) {
        cout << "->G" << path.at(i);
    }
    cout << " = " << path.front() << endl;

}
