#ifndef CIRCUIT_H
#define CIRCUIT_H

#include <vector>

using std::vector;

typedef struct {
    int id; //Gate Num
    vector<int> inputgates; //IDs of gates going into this gate
} NodeInputs;


class Circuit {
    public:
        vector<int> getInputs(void);
        vector<int> getOutputs(void);
        vector<NodeInputs> getNodeInputs(void);
        int getNodeCount(void);

        //Constructor; Pass in filename, object values are populated
        Circuit(char * fname);


    private:
        vector<int> inputs; //List of input gate numbers
        vector<int> outputs; //List of output gate numbers
        std::vector<NodeInputs> nodeinputs; //List of intermediate and output gates, because input gates have no inputs!
        int nodecount; //Total number of nodes in the graph/gates in the circuit


};

#endif