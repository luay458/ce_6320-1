#ifndef GRAPH_H
#define GRAPH_H

#include <limits>
#include <map>
#include <vector>

const int INF = std::numeric_limits<int>::max();//infinity(); //INF = no connection between nodes
// const int INF = std::numeric_limits<int>::

class Graph {
    private:
        static void update_weights(int * array, int len); //All non-inf values in the matrix row will = number of non-inf values
        std::vector<int> inputs; //Vector of input node IDs
        std::vector<int> outputs; //Vector of output node IDs
        int nodecount = 0; //Number of Nodes in the graph, defines size of matrix
        int ** matrix; //Adjacency matrix, dynamically allocated during class constructor
        std::map<int,int> nodeidx; //map[x] = a -> gateX = idx A in matrix
        int idxToId(int idx); //Pass in index from matrix, returns node ID

    public:

        Graph(char * fname);
        ~ Graph(void);

        std::vector<int> getNodeIds(void); //Returns list of all node IDs
        std::vector<int> getAllInputs(void); //Get list of input node IDs
        std::vector<int> getAllOutputs(void); //Get list of output node IDs
        std::vector<int> getNodeOutputs(int node); //Get list of node IDs that the current node outputs to; edge weight = size of list
        int getNodeCount(void); 
};

#endif