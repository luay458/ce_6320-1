#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "parser.h"
#include "circuit.h"

using std::cout;
using std::endl;
using std::string;
using std::vector;

Circuit::Circuit(char * fname) {
#if 1
    // cout << "Circuit Init" << endl << endl;
#endif

    std::ifstream file;
    string currline;
    // size_t input = string::npos, output = string::npos;
    int inputline = 0, outputline = 0; //Tracks whether the current line has an INPUT or OUTPUT gate, -1 = false
    int currgatenum; 
    vector<int> gatelist;
    NodeInputs newnode;


    //Open file; If fails, exit program
    file.open(fname);
    if (!file.is_open()) {
        cout << "Wrong file name" << endl;
        exit(1);
    }

    //Skip down until I hit a line with "INPUT" or "OUTPUT"
    while ((currline.find("INPUT(") == string::npos) && (currline.find("OUTPUT(") == string::npos)) {
        getline(file, currline);
    }

    //Iterate through all lines with "INPUT" or "OUTPUT"
    while ((inputline != -1) || (outputline != -1)) {
        currgatenum = parse_first_int(currline);

        // cout << currline << endl;
        if (inputline > -1) {
            inputs.push_back(currgatenum);
            // cout << "INPUT(G" << currgatenum << ")" << endl;
        } else {
            outputs.push_back(currgatenum);
            // cout << "OUTPUT(G" << currgatenum << ")" << endl;
        }
        // cout << endl;

        getline(file, currline);
        inputline = currline.find("INPUT");
        outputline = currline.find("OUTPUT");
    }

#if 0
    //DEBUG: Print input and output lines
    for (uint i = 0; i < inputs.size(); i++) {
        cout << "inputs[" << i << "] = " << inputs.at(i) << endl;
    }
    cout << endl;
    for (uint i = 0; i < outputs.size(); i++) {
        cout << "outputs[" << i << "] = " << outputs.at(i) << endl;
    }
    cout << endl;
#endif

    //Go through Gx = gate(G1, G2, ..., Gn), populating vector nodes
    while (getline(file, currline)) {
        gatelist = parse_all_ints(currline);
        newnode.id = gatelist.at(0);
        newnode.inputgates.clear(); //Clear previous input list

        //Iterate thru gatelist starting at idx 1, add
        for (uint i = 1; i < gatelist.size(); i++) {
            newnode.inputgates.push_back(gatelist.at(i));
        }

        nodeinputs.push_back(newnode);

#if 0
        //Debug output
        cout << currline << endl;
        cout << " " << nodes.back().id << endl;
        for (uint i = 0; i < nodes.back().inputs.size(); i++) {
            cout << nodes.back().inputs.at(i) << " ";
        }
        cout << endl << endl;
#endif

    }
    
    nodecount = inputs.size() + nodeinputs.size(); //input nodes + (inner nodes + outer nodes)
#if 0
    cout << "Node Count = " << nodecount << endl;
#endif

    file.close();

}


int Circuit::getNodeCount(void) {
    return nodecount;
}

vector<int> Circuit::getInputs(void) {
    return inputs;
}

vector<int> Circuit::getOutputs(void) {
    return outputs;
}

vector<NodeInputs> Circuit::getNodeInputs(void) {
    return nodeinputs;
}