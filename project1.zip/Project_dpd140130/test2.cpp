#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <sstream>
#include <list> 
#include <set> 
#include <map> 
#include <stack> 

#define INF 9999 // Define a constant for representing infinity in the graph

enum Type  // Enum to represent different types of nodes in the circuit
{
    InputNode = 0,
    OutputNode,
    MidNode,
    MaximumNodes
};

typedef struct  // Structure to represent an edge in the graph
{
    int destination;    // Destination node of the edge
    int Delay;  // Delay associated with the edge
} NODE;

class Graph // Class representing a graph
{
    std::list<NODE>* Adj_List;   // Adjacency list for each node
    int size;   // Number of nodes in the graph

public:
    Graph(int size) // Constructor to initialize the graph with a given size
    {
        this->Adj_List = new std::list<NODE>[size];
        this->size = size;  
    }
    // Function to add an edge to the graph
    void add_edge(int source, int destination, int delay);
    // Function to print the adjacency list representation of the graph
    void print_list(std::map<std::string, int>& InputOutputMap);
    // Function to calculate distance for delay values in the graph
    void calculate_distance(); 
    
    // Friend function for Dijkstra's algorithm, allowing access to private members
    friend int DijkstraShortestPath(Graph CIRCUIT, int start, int destination, std::map<std::string, int>& InputOutputMap); 
};

// Function to parse the circuit data from a file
void ParseBenchFile(std::ifstream& CircuitData, std::map<std::string, int>& InputOutputMap, std::map<std::string, int>& InputOutputTypeMap, Graph& CIRCUIT);
// Function to check if a character is whitespace
bool isWhitespace(unsigned char c);
// Function to calculate the size of the circuit based on input from a file
int CalculateSize(std::ifstream& CircuitData);
// Function to check if a character is not a number
bool isCharIsNotNumber(unsigned char c);
// Function to find the key in a map based on its value
std::string Find_Key_In_Map(const std::map<std::string, int>& myMap, int valueToFind);

// DijkstraShortestPath's algorithm for finding the shortest path in a graph
int DijkstraShortestPath(Graph CIRCUIT, int start, int destination, std::map<std::string, int>& InputOutputMap) 
{
    // Allocate memory for distance and shortestPath arrays
    int Gate_Size = CIRCUIT.size;
    int* dist = new int[Gate_Size];
    int* shortestPath = new int[Gate_Size];
    
    // Initialize distance and shortestPath arrays
    for (int node = 0; node < Gate_Size; node++) 
    {
        dist[node] = INF;
        shortestPath[node] = -1; 
    }
    
    // Set the distance of the start node to 0
    dist[start] = 0;     
    // Initialize Node_Queue and nodeS data structures
    std::list<int> Node_Queue;
    std::set<int> nodeS;
    
    // Fill Node_Queue with all nodes in the graph
    for (int node = 0; node < Gate_Size; node++) 
    {
        Node_Queue.push_back(node); 
    }

    // Main loop of DijkstraShortestPath's algorithm
    while (!Node_Queue.empty()) 
    {
        // Find the node with the minimum distance in Node_Queue
        std::list<int>::iterator MinNodeOfQ = std::min_element(Node_Queue.begin(), Node_Queue.end());
        int MinEleOfQ = *MinNodeOfQ; 
        Node_Queue.erase(MinNodeOfQ);
        nodeS.insert(MinEleOfQ);
        
        // Update distances and shortest paths for neighboring nodes
        std::list<NODE>::iterator it;
        for (it = CIRCUIT.Adj_List[MinEleOfQ].begin(); it != CIRCUIT.Adj_List[MinEleOfQ].end(); it++) 
        {
            if (nodeS.find(it->destination) == nodeS.end()) 
            {
                if ((dist[MinEleOfQ] + (it->Delay)) < dist[it->destination]) 
                { 
                    dist[it->destination] = (dist[MinEleOfQ] + (it->Delay));
                    shortestPath[it->destination] = MinEleOfQ;
                }
            }
        }
    }
    
    // Check if a path exists between start and destination nodes
    if(INF == dist[destination])
    {
        std::cout << "No path found between " << Find_Key_In_Map(InputOutputMap, start) << " and " << Find_Key_In_Map(InputOutputMap, destination) << std::endl;
        delete[] dist;
        delete[] shortestPath;
        return dist[destination];
    }      
    std::cout << std::endl;
    std::cout << "Shortest path between " << Find_Key_In_Map(InputOutputMap, start) << " and " << Find_Key_In_Map(InputOutputMap, destination) << " is: ";
    std::cout << std::endl;
    // Print the shortest path
    int current = destination;
    std::stack<int> path;

    while (current != start) {
        path.push(current);
        current = shortestPath[current];
    }
    path.push(start);

    while (!path.empty()) {
        std::cout << " , " << Find_Key_In_Map(InputOutputMap, path.top());
        path.pop();
    }
    std::cout << std::endl;

    // Deallocate memory
    delete[] dist;
    delete[] shortestPath;

    return dist[destination]; 
}

// Function to find a key in a map based on its value
std::string Find_Key_In_Map(const std::map<std::string, int>& myMap, int valueToFind) 
{
    for (const auto& pair : myMap) 
    {
        if (pair.second == valueToFind) 
        {
            return pair.first;
        }
    }
    return ""; 
}

// Function to add an edge to the graph
void Graph::add_edge(int source, int destination, int delay)
{
    NODE newNode;
    newNode.destination = destination;
    newNode.Delay = delay;

    Adj_List[source].push_back(newNode);
}

// Function to print the adjacency list representation of the graph
void Graph::print_list(std::map<std::string, int>& InputOutputMap)
{
    for(int Idx=0; Idx<size; Idx++)
    {
        std::cout << Find_Key_In_Map(InputOutputMap, Idx);
        for (std::list<NODE>::iterator it = Adj_List[Idx].begin(); it != Adj_List[Idx].end(); it++)
        {
            std::cout << "--> " << Find_Key_In_Map(InputOutputMap, it->destination)  << "|" << it->Delay;
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

// Function to calculate distance for delay values in the graph
void Graph::calculate_distance() 
{
    int delay = INF;
    for(int Idx=0; Idx<size; Idx++)
    {
        std::list<NODE>::iterator it = Adj_List[Idx].begin();
        delay =  Adj_List[Idx].size();
        for(; it != Adj_List[Idx].end(); it++)
        {
            if(INF == it->Delay)
                it->Delay = delay;
        }
    }
}

// Function to calculate the size of the circuit based on input from a file
int CalculateSize(std::ifstream& CircuitData)
{
    std::string line;
    int cnt = 0;
    int InputgateCount = 0, OutputgateCount = 0, InterirorgateCount = 0;
    
    // Read each line from the file
    while(getline(CircuitData, line))
    {
        // Remove whitespaces from the line
        line.erase(remove_if(line.begin(), line.end(), isWhitespace), line.end()); 
        
        // Check if the line contains information about input gates
        if(-1 != line.find("inputgates"))
        {
            line.erase(remove_if(line.begin(), line.end(), isCharIsNotNumber), line.end());
            InputgateCount = stoi(line);
            cnt++;
        }
        // Check if the line contains information about output gates
        if(-1 != line.find("outputgates"))
        {
            line.erase(remove_if(line.begin(), line.end(), isCharIsNotNumber), line.end());
            OutputgateCount = stoi(line);
            cnt++;
        }
        // Check if the line contains information about interior gates
        if(-1 != line.find("interiorgateoutputs"))
        {
            line.erase(remove_if(line.begin(), line.end(), isCharIsNotNumber), line.end());
            InterirorgateCount = stoi(line);
            cnt++;
        }
        // Break the loop when information about all gate types is collected
        if (3 == cnt)
            break;
    }
    // Calculate and return the total size of the circuit
    return (InputgateCount + OutputgateCount + InterirorgateCount);
}

// Function to parse the circuit data from a file
void ParseBenchFile(std::ifstream& CircuitData, std::map<std::string, int>& InputOutputMap, std::map<std::string, int>& InputOutputTypeMap, Graph& CIRCUIT)
{
    std::string line;
    std::string result;
    int NodeIndex = 0;
    int GIdx;
    std::set<std::string> OUTPUT;
    std::set<std::string> INPUT;
        
    while(getline(CircuitData, line))
    {
        // Check if the line contains information about input gates
        if(-1 != line.find("INPUT"))
        {
            size_t startPos = line.find("(");
            size_t lengthToRemove = startPos + 1;
            result = line.substr(lengthToRemove, line.length() - lengthToRemove - 1);
            
            // Insert the input signal into the map and set its type
            InputOutputMap.insert({result, NodeIndex});
            InputOutputTypeMap.insert({result, InputNode});
            INPUT.insert(result);
            NodeIndex++;
        }

        // Check if the line contains information about output gates         
        if(-1 != line.find("OUTPUT"))
        {
            // Extract the output signal name from the line
            size_t startPos = line.find("(");
            size_t lengthToRemove = startPos + 1;
            result = line.substr(lengthToRemove, line.length() - lengthToRemove - 1);
            // Insert the output signal into the set
            OUTPUT.insert(result);
        }
        // Check if the line contains information about intermediate gates
        if((-1 != line.find("=")) && (-1 == line.find("#")))
        {
            std::string midgate;
            std::string midGateInput;
            line.erase(remove_if(line.begin(), line.end(), isWhitespace), line.end()); 
            size_t equalIdx = line.find("=");
            midgate = line.substr(0, equalIdx);
            // Check if the intermediate gate is not an input or output
            if(INPUT.end() == INPUT.find(midgate) && (OUTPUT.end() == OUTPUT.find(midgate)))
            {
                InputOutputMap.insert({midgate, NodeIndex});
                InputOutputTypeMap.insert({midgate, MidNode});
                NodeIndex++;
            }
            else if(OUTPUT.end() != OUTPUT.find(midgate))
            {
                // Insert the output gate into the map and set its type
                InputOutputMap.insert({midgate, NodeIndex});
                InputOutputTypeMap.insert({midgate, OutputNode});
                NodeIndex++;
            }
            // Extract the input signals connected to the intermediate gate
            size_t startPos = line.find("(");
            size_t lengthToRemove = startPos + 1;
            result = line.substr(lengthToRemove, line.length() - lengthToRemove - 1);
                   
            std::stringstream midGateInputsStr(result);
            while (getline(midGateInputsStr, midGateInput, ','))
            {
                // Add edges between the input signals and the intermediate gate in the graph
                CIRCUIT.add_edge(InputOutputMap[midGateInput], InputOutputMap[midgate], INF);
            }
        }
    }
        
    CIRCUIT.calculate_distance();
}

bool isWhitespace(unsigned char c) 
{
    if (c == ' ' || c == '\t' || c == '\n' ||
        c == '\r' || c == '\f' || c == '\v') 
    {
        return true;
    } 
    else 
    {
        return false;
    }
}

bool isCharIsNotNumber(unsigned char c) 
{
    if (c >= '0' && c <= '9') 
    {
        return false;
    } 
    else 
    {
        return true;
    }
}

int main(int argc, char **argv)
{
    if(4 != argc)
    {
        std::cout << "Incorrect number of arguments" << std::endl;
        return 0;
    }       
    std::ifstream CircuitData;
         
    try
    {
        CircuitData.open(argv[1]);
        if(!(CircuitData.is_open()))
            throw (std::string)argv[1];
    }
    catch (std::string filename)
    {
        std::cout << "Wrong file name" << std::endl;
        return 1;
    }
         
    std::map<std::string, int> InputOutputMap;
    std::map<std::string, int> InputOutputTypeMap;
    Graph CIRCUIT(CalculateSize(CircuitData));
    std::string error = "";
    ParseBenchFile(CircuitData, InputOutputMap, InputOutputTypeMap, CIRCUIT);
        
        
    try
    {
        //check for all the error conditions
        if(InputOutputTypeMap.end() == InputOutputTypeMap.find(argv[2])){
            throw "Signal " + (std::string)argv[2] +" not found in file " + (std::string)argv[1];
            return 1;
        }
        if(InputOutputTypeMap.end() == InputOutputTypeMap.find(argv[3])){
            throw "Signal " + (std::string)argv[3] +" not found in file " + (std::string)argv[1];
            return 1;
        }
        else if(InputNode != InputOutputTypeMap[argv[2]]){
            throw "Signal " + (std::string)argv[2] +" is not an input pin";
            return 1;
        }
        else if(OutputNode != InputOutputTypeMap[argv[3]]){
            throw "Signal " + (std::string)argv[3] +" is not an output pin";
            return 1;
        }
    }
    catch (std::string error)
    {
        std::cout << error << std::endl;
        return 0;
    }
    std::string input = (std::string)argv[2];
    std::string output = (std::string)argv[3];
    int ShortestDistance = DijkstraShortestPath(CIRCUIT, InputOutputMap[input], InputOutputMap[output], InputOutputMap);
    std::cout << "Total fan-out delay between "<< input << " and "<< output << " is : ";
    if(INF != ShortestDistance){
        std::cout << ShortestDistance << std::endl;
    }
    else{
        std::cout << "not available" << std::endl;
    }
    std::cout << std::endl;
}
