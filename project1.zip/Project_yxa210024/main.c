#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <ctype.h>


#define MAX_LINE_LENGTH 2000000L
#define MAX_INPUTS 10000000L
#define MAX_NODES 10000000L

//struct declarations
typedef struct {
    char *name;
    char **inputs;
    int numInputs;
} Gate;

typedef struct {
    long index;
    long delay;
} PathNode;


typedef struct {
    PathNode *path;
    int length;
} Path;

typedef struct {
    long numNodes;
    long **adjMatrix;
    long *delays;
} Graph;

int firstIndex=0;
// Function declarations
void freeGates(Gate *gates, int numGates);
char *strtrim(char *str);
long findGateIndexByName(const Gate *gates, int numGates, const char *name);
long findGateIndexByNameReverse(const Gate *gates, int numGates, const char *name);
Graph createGraph(const Gate *gates, long numGates);
void freeGraph(Graph graph);
long *calculateFanouts(const Graph *graph);
Path dijkstra(const Graph *graph, long startIdx, long endIdx);  
void printShortestPath(Path *path, Gate *gates);


// paraphrasing
char *strtrim(char *str) {
    char *end;
    while (isspace((unsigned char)*str)) {
        str++;
    }
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) {
        end--;
    }
    *(end + 1) = '\0';

    return str;
}

// free the memory allocated for gates
void freeGates(Gate *gates, int numGates) {
    for (int i = 0; i < numGates; ++i) {
        free(gates[i].name);
        for (int j = 0; j < gates[i].numInputs; ++j) {
            free(gates[i].inputs[j]);
        }
        free(gates[i].inputs);
    }
    free(gates);
}

// finding the index of a gate by name
long findGateIndexByName(const Gate *gates, int numGates, const char *name) {
    char trimmedName[MAX_LINE_LENGTH];
    int i = 0, j = strlen(name) - 1;
    while (isspace(name[i])) {
        i++;
    }
    while (j >= i && isspace(name[j])) {
        j--;
    }
    strncpy(trimmedName, name + i, j - i + 1);
    trimmedName[j - i + 1] = '\0';
    if (strstr(trimmedName, "INPUT") != NULL || strstr(trimmedName, "OUTPUT") != NULL) {
        for (int i = 0; i < numGates; ++i) {
            if (strcmp(gates[i].name, trimmedName) == 0) {
                return i;
            }
        }
    } else {
        for (int i = 0; i < numGates; ++i) {
            if (strncmp(gates[i].name, trimmedName, strlen(trimmedName)) == 0) {
                return i;
            }
        }
    }
    return -1;
}

// finding the index of a gate by name in reverse order
long findGateIndexByNameReverse(const Gate *gates, int numGates, const char *name) {
    char trimmedName[MAX_LINE_LENGTH];
    int i = 0, j = strlen(name) - 1;
    while (isspace(name[i])) {
        i++;
    }
    while (j >= i && isspace(name[j])) {
        j--;
    }
    strncpy(trimmedName, name + i, j - i + 1);
    trimmedName[j - i + 1] = '\0';
    if (strstr(trimmedName, "INPUT") != NULL || strstr(trimmedName, "OUTPUT") != NULL) {
        for (int i = numGates - 1; i >= 0; --i) {
            if (strcmp(gates[i].name, trimmedName) == 0) {
                return i;
            }
        }
    } else {
        for (int i = numGates - 1; i >= 0; --i) {
            if (strncmp(gates[i].name, trimmedName, strlen(trimmedName)) == 0) {
                return i;
            }
        }
    }
    return -1;
}

//to calculate the Fanouts of the gates
long *calculateFanouts(const Graph *graph) {
    long *fanouts = malloc(graph->numNodes * sizeof(long));
    if (fanouts == NULL) {
        perror("Memory allocation error");
        exit(1);
    }
    for (long i = 0; i < graph->numNodes; ++i) {
        long fanoutCount = 0;
        for (long j = 0; j < graph->numNodes; ++j) {
            if (graph->adjMatrix[i][j] == 1) {
                fanoutCount++;
            }
        }
        fanouts[i] = fanoutCount;
    }
    return fanouts;
}


//to create the graph and adjancency matrix
Graph createGraph(const Gate *gates, long numGates) {
    Graph graph;
    graph.numNodes = numGates;
    graph.adjMatrix = malloc(numGates * sizeof(long *));
    graph.delays = malloc(numGates * sizeof(long));

    for (long i = 0; i < numGates; ++i) {
        graph.adjMatrix[i] = calloc(numGates, sizeof(long));
        graph.delays[i] = 0; 
    }
    for (int i = 0; i < numGates; ++i) {
        for (int j = 0; j < gates[i].numInputs; ++j) {
            int inputIndex = findGateIndexByName(gates, numGates, gates[i].inputs[j]);
            if (inputIndex != -1) {
                graph.adjMatrix[inputIndex][i] = 1;
            } 
        }
    }
    long *fanouts = calculateFanouts(&graph);
    for (int i = 0; i < numGates; ++i) {
        graph.delays[i] = fanouts[i];
    }
    free(fanouts);
    return graph;
}

// Dijkstra algorithm
Path dijkstra(const Graph *graph, long startIdx, long endIdx) {
    Path path;
    path.path = malloc(graph->numNodes * sizeof(PathNode));
    path.length = 0;
    long *distances = malloc(graph->numNodes * sizeof(long));
    if (distances == NULL) {
        perror("Memory allocation error");
        free(path.path);
        exit(1);
    }
    long *visited = calloc(graph->numNodes, sizeof(long));
    if (visited == NULL) {
        perror("Memory allocation error");
        free(distances);
        free(path.path);
        exit(1);
    }
    distances[startIdx] = 0;
    for (int i = 0; i < graph->numNodes; ++i) {
        distances[i] = INT_MAX;
    }
    distances[startIdx] = 0;
    long iteration = 0;

    while (iteration < graph->numNodes) {
        int minDistance = INT_MAX;
        int currentIdx = -1;

        for (int j = 0; j < graph->numNodes; ++j) {
            if (!visited[j] && distances[j] < minDistance) {
                minDistance = distances[j];
                currentIdx = j;
            }
        }

        if (currentIdx == -1) {
            break;
        }

        visited[currentIdx] = 1;

        for (int j = 0; j < graph->numNodes; ++j) {
            if (!visited[j] && graph->adjMatrix[currentIdx][j] &&
                (distances[currentIdx] != INT_MAX &&
                 (distances[currentIdx] + graph->delays[j] < distances[j] || distances[j] == INT_MAX))) {
                distances[j] = distances[currentIdx] + graph->delays[j];
                path.path[j].index = currentIdx;
                path.path[j].delay = distances[j];
            }
        }

        iteration++;

        if (iteration >= 300) {
		if(currentIdx!=endIdx){
			endIdx=currentIdx;
		}
            break;
        }
    }

    int currentIdx = endIdx;

    while (currentIdx != startIdx) {
        path.path[path.length].index = currentIdx;
        path.path[path.length].delay = distances[currentIdx];
        path.length++;
        currentIdx = path.path[currentIdx].index;
    }

    PathNode *reversedPath = malloc((path.length + 1) * sizeof(PathNode));

    for (int i = 0; i <= path.length; ++i) {
        reversedPath[i] = path.path[path.length - i];
    }
    path.path = reversedPath;
    free(distances);
    free(visited);
    iteration = 0;
    return path;
}


void printShortestPath(Path *path, Gate *gates) {
if(path->path[path->length].delay!=2147483647){
	printf("Total delay:%d\n",path->path[path->length].delay);
    printf("Shortest Path:\n");
    if (path->length == -1) {
        printf("  No path found\n");
        return;
    }
	printf("%s --> ", gates[firstIndex].name);
    for (int i = 1; i <= path->length; ++i) {
        int gateIndex = path->path[i].index;
        printf("%s", gates[gateIndex].name);

        if (i < path->length) {
            printf(" --> ");
        }
    }
    printf("\n");
}else{
printf("Total delay:INFINITY\n");
    printf("Shortest Path:NOT FOUND\n");
}	
}

//free the memory allocated to the graph
void freeGraph(Graph graph) {
    for (int i = 0; i < graph.numNodes; ++i) {
        free(graph.adjMatrix[i]);
    }
    free(graph.adjMatrix);
    free(graph.delays);
}

//main
int main(int argc, char *argv[]) {
Path path;
    if (argc != 4) {
        printf("Incorrect number of arguments\n");
        return 1;
    }
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Wrong file name\n");
        return 1;
    }
    char line[MAX_LINE_LENGTH];
    int numGates = 0;
	int iGates=0;
	int oGates=0;
    	Gate *gates = NULL;
	Gate *Igates=NULL;
	Gate *Ogates=NULL;
	Gate *IOgates = NULL;
	int numIOGates = 0;
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#') {
            continue;
        }
        if (strstr(line, "=") != NULL || strstr(line, "INPUT") != NULL || strstr(line, "OUTPUT") != NULL) {
            char *openParenthesis = strchr(line, '(');
            char *equalSign = strchr(line, '=');
            if (strstr(line, "INPUT") != NULL) {
                char *inputName = strtok(openParenthesis + 1, ")");
                gates = realloc(gates, (numGates + 1) * sizeof(Gate));
		Igates = realloc(Igates, (iGates + 1) * sizeof(Gate));
		IOgates = realloc(IOgates, (numIOGates + 1) * sizeof(Gate));
                gates[numGates].name = strdup(inputName);
                gates[numGates].inputs = NULL;
                gates[numGates].numInputs = 0;
                numGates++;
		Igates[iGates].name = strdup(inputName);
		Igates[iGates].inputs = NULL;
                Igates[iGates].numInputs = 0;
                iGates++;
		IOgates[numIOGates].name = strdup(inputName);
            	IOgates[numIOGates].inputs = NULL;
            	IOgates[numIOGates].numInputs = 0;
            	numIOGates++;		
            }
            else if (strstr(line, "OUTPUT") != NULL) {
                char *outputName = strtok(openParenthesis + 1, ")");
		Ogates = realloc(Ogates, (oGates + 1) * sizeof(Gate));
                gates = realloc(gates, (numGates + 1) * sizeof(Gate));
		IOgates = realloc(IOgates, (numIOGates + 1) * sizeof(Gate));
                gates[numGates].name = strdup(outputName);
                gates[numGates].inputs = NULL;
                gates[numGates].numInputs = 0;
                numGates++;
		Ogates[oGates].name = strdup(outputName);
                Ogates[oGates].inputs = NULL;
                Ogates[oGates].numInputs = 0;
                oGates++;
		IOgates[numIOGates].name = strdup(outputName);
            	IOgates[numIOGates].inputs = NULL;
            	IOgates[numIOGates].numInputs = 0;
            	numIOGates++;
            }
            else if (equalSign != NULL) {
                gates = realloc(gates, (numGates + 1) * sizeof(Gate));
                if (gates == NULL) {
                    perror("Memory allocation error");
                    fclose(file);
                    freeGates(gates, numGates);
                    return 1;
                }
                char *gateName = strtok(line, "= \t\n");
                gates[numGates].name = strdup(gateName);
                char *inputsBuffer = strtok(openParenthesis + 1, ")");
                char *token = strtok(inputsBuffer, ",");
                gates[numGates].inputs = malloc(MAX_INPUTS * sizeof(char *));
                gates[numGates].numInputs = 0;
                while (token != NULL) {
                    gates[numGates].inputs[gates[numGates].numInputs] = strdup(token);
                    gates[numGates].numInputs++;
                    token = strtok(NULL, ",");
                }
                numGates++;
            }
        }
    }
    fclose(file);
    long startIdx = findGateIndexByName(gates, numGates, argv[2]);
    firstIndex = startIdx;
    long endIdx = findGateIndexByNameReverse(gates, numGates, argv[3]);
	long IstartIdx = findGateIndexByName(Igates, iGates, argv[2]);
	long OendIdx = findGateIndexByName(Ogates, oGates, argv[3]);
	long IOgatesIdxI = findGateIndexByName(IOgates, numIOGates, argv[2]);
	long IOgatesIdxO= findGateIndexByName(IOgates, numIOGates, argv[3]);
	if (startIdx == -1) {
    		printf("Signal %s not found in file %s\n", argv[2],argv[1]);
    		return 1;
	}else if(endIdx== -1){
		printf("Signal %s not found in file %s\n", argv[3],argv[1]);
    		return 1;
	}else{
		if(IOgatesIdxI==-1){
		printf("Signal %s not found in file %s\n", argv[2],argv[1]);
    		return 1;
		}else if(IOgatesIdxO ==-1){
		printf("Signal %s not found in file %s\n", argv[3],argv[1]);
    		return 1;
		}else{
			if (IstartIdx == -1) {
    			printf("Signal %s not an INPUT in file %s\n", argv[2],argv[1]);
    			return 1;
			}
			if (OendIdx == -1) {
    			printf("Signal %s not an OUTPUT in file %s\n", argv[3],argv[1]);
    			return 1;
			}
		}
	}
Graph graph = createGraph(gates, numGates);
Path shortestPath = dijkstra(&graph, startIdx, endIdx);
printShortestPath(&shortestPath, gates);
freeGates(gates, numGates);
freeGraph(graph);
free(shortestPath.path);
freeGates(Igates, iGates);
freeGates(Ogates, oGates);
freeGates(IOgates, numIOGates);
return 0;
}


