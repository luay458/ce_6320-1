#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <unordered_map>
#include <list>
#include <utility>
#include <vector>
#include <unordered_set>
#include <queue>



void checkFile(std::string & filename,std::string & input,std::string & output) //checks the filepath for file and additonally checks if the input signal and the output signals are present
{
    try{
        std::ifstream file(filename.c_str());

        if (!file.is_open())
        {
            throw std::runtime_error("Wrong file name /n");
            throw std::runtime_error("Unable to open the file please provide the correct path to file or parse valid .bench file"); // The file is not in the given path
        }
        else if (file.is_open()) 
        {
            std::string line;
            bool isinputfound =false;
            bool isoutputfound =false;
        while (std::getline(file, line)) 
        {
            //std::cout << line << std::endl;
            if (line.find("INPUT") != std::string::npos) 
            {
                if(line.find(input) != std::string::npos ) 
                {
                    std::cout << "The input is found in the file"<< std::endl; // input found in the file
                    isinputfound = true;
                }
            }
            else if (line.find("OUTPUT") != std::string::npos) 
            {
                if(line.find(output) != std::string::npos ) 
                {
                std::cout << "The output is found in the file"<< std::endl; // output found in the file
                isoutputfound =true;
                }
            }
        }
        file.close();
        //if (!isinputfound && !isoutputfound)
        // { 
        //     throw std::runtime_error("The signal is not found in the file"); //signal not found

        // }

        // else if (!isinputfound)
        // {
        //     throw std::runtime_error("The input is not found in the file"); //input not found
        // }

        // else if (!isoutputfound)
        // {
        //     throw std::runtime_error("The output is not found in the file"); //output not found
        // }

    }
    }
    catch (const std::exception& e) 
    {
        std::cout << "Exception occurred: " << e.what() << std::endl;
    }
}

std::string extractsignal(const std::string& input) {
    size_t i = input.find('(');
    size_t j = input.find(')');
    std::string signal= input.substr(i+1,j-i-1);
    return signal;
    
}

std::string extractintersignal(const std::string& input) {
    size_t i = 0;
    size_t j = input.find("=");
    std::string signal= input.substr(i,j-i-1);
    return signal;
    
}

std::vector<std::string> resolveip(const std::string& input) {
    std::vector<std::string> signals;
    std::istringstream strst(input);
    std::string tmp;
    char del;
    del =',';

    while (std::getline(strst ,tmp, del)) {
        signals.push_back(tmp);
    }

    return signals;
}



class Graphstructure {
private:
    std::unordered_map<std::string, std::list<std::pair<std::string, int>>> adjlist;

public:
    void addnode(const std::string & node)
    {
        adjlist[node];
    }

    void addedge( const std::string & prev,const std::string& next,int weight)
    {
        adjlist[prev].push_back(std::make_pair(next, weight));
    }
    void printGraph() {
        for (const auto& entry : adjlist) {
            std::cout << "Outgoing edges from vertex " << entry.first << " ---> ";
            for (const auto& neighbor : entry.second) {
                std::cout << neighbor.first << " with edge wieght of " << neighbor.second << " ---> ";
            }
            std::cout << std::endl;
        }
    }
    void checkcycle(std::string & source,std::string & sink) {
        bool containscycle;
        std::unordered_set<std::string> vistnode;
        std::unordered_set<std::string> rstack;
        containscycle = iscycle(source,sink,vistnode,rstack);
        if (containscycle)
        {
            //std::cout<< "no path or path contains cycle" << std::endl;
        }

    }
    bool iscycle( std::string & cnode,std::string & sink, std::unordered_set<std::string>& vistnode, std::unordered_set<std::string>& rstack) 
    {
        vistnode.insert(cnode);
        rstack.insert(cnode);
        for ( auto& neighborpr : adjlist[cnode]) {
            std::string& neighbor = neighborpr.first;
            //std::cout<<neighbor<<std::endl;
            if (neighbor == sink) {
                return true; 
                //std::cout<<"here"<<std::endl;
            }

            if (!vistnode.count(neighbor) && iscycle(neighbor, sink, vistnode,rstack)) {
                return true;
                //std::cout<<"here"<<std::endl;
            } else if (rstack.count(neighbor)) {
                return true; 
                //std::cout<<"here"<<std::endl;
            }
        }
        rstack.erase(cnode); 
        return false;

    }

    void popwieghts()
    {   
        for (auto& entry : adjlist) {
            size_t len = entry.second.size();
            // std::cout << "Wieght of "<<entry.first << ":" << len << std::endl;
            for ( auto& neighbor: entry.second) 
            {
                neighbor.second = len;
                //std::cout << neighbor.second << std::endl;
            }
            
        }
    }

    std::pair<int, std::vector<std::string>> dijkstra(const std::string& source, const std::string& sink, std::unordered_map<std::string, std::string>& path) {
        std::unordered_map<std::string, int> dist;
        std::priority_queue<std::pair<int, std::string>, std::vector<std::pair<int, std::string>>, std::greater<std::pair<int, std::string>>> pque;

        for (const auto& entry : adjlist) {
            const std::string& node = entry.first;
            dist[node] = (node == source) ? 0 : std::numeric_limits<int>::max();
            path[node] = "";
            pque.push({dist[node], node});
        }

        while (!pque.empty()) {
            std::string u = pque.top().second;
            int udist = pque.top().first;
            pque.pop();

            if (u == sink) {
                break;
            }

            for (const auto& neighbor : adjlist[u]) {
                std::string v = neighbor.first;
                int weight = neighbor.second;

                int alt = udist + weight;
                if (alt < dist[v]) {
                    dist[v] = alt;
                    path[v] = u;
                    pque.push({alt, v});
                }
            }
        }
        std::vector<std::string> opath;
        std::string currentnode = sink;
        while (currentnode != "") {
            opath.push_back(currentnode);
            currentnode = path[currentnode];
        }
        std::reverse(opath.begin(), opath.end());
        return {dist[sink], opath};
    }

};

std::unordered_map<std::string, std::list<std::string>> getipop (std::string & filename)
{
    std::unordered_map<std::string, std::list<std::string>> ipop;
    std::ifstream file(filename.c_str());
    if(file.is_open())
    {
        for (std::string line; std::getline(file, line); )
        {
            // std::cout << line << std::endl;
            if(line.find("#") != 0)
            {
                if (line.find("INPUT") == 0){
                    std::string ip;
                    ip=extractsignal(line);
                    ipop["ip"].push_back(ip);
                    }
                else if (line.find("OUTPUT") == 0){
                    std::string op;
                    op=extractsignal(line);
                    ipop["op"].push_back(op);
                    }
            }
        }
    }
    return ipop;
}

Graphstructure parseFile(std::string & filename)
{
    Graphstructure graph;
    std::ifstream file(filename.c_str());
    if(file.is_open())
    {
        for (std::string line; std::getline(file, line); )
        {
            // std::cout << line << std::endl;
            if(line.find("#") != 0)
            {
                if (line.find("INPUT") == 0){
                    std::string ip;
                    ip=extractsignal(line);
                    std::cout << "input signals:" << ip << std::endl;
                    graph.addnode(ip);
                    }
                else if (line.find("OUTPUT") == 0){
                    std::string op;
                    op=extractsignal(line);
                    graph.addnode(op);
                    std::cout << "output signals:"<< op << std::endl;

                    }
                else if (line.find("G")==0)
                {
                    std::string gate_ip;
                    std::string gate_op;
                    std::vector<std::string> io;
                    gate_ip =extractsignal(line);
                    gate_op =extractintersignal(line);
                    io = resolveip(gate_ip);
                    for (std::string& substring : io )
                    {
                        substring.erase(remove_if(substring.begin(), substring.end(), isspace), substring.end());
                        // std::cout << "Substring:" << substring << std::endl;
                        graph.addnode(substring);
                        graph.addedge(substring,gate_op,0);
                    }



                    

                } 
                    
                }
            }

        }

        
        return graph;
    }





int main(int argc, char* argv[])
{
    
    Graphstructure wdag;
    std::unordered_map<std::string, std::list<std::string>> ipop;
    if (argc<4 || argc>4) 
    {
        std::cout << "Incorrect number of arguments \n"<<"Suggested Usage: " << argv[0] << " <folder_path>/<filename>  <input gates> <output gates>" << std::endl;
        return 1;
    }
    
    std::string filename = argv[1];
    std::string ip = argv[2];
    std::string op = argv[3];
    checkFile(filename,ip,op);
    ipop = getipop(filename);
    bool ipflag = false;
    bool opflag = false;
    for (const auto& element : ipop["ip"]) {
        if (element == ip)
        {
            ipflag = true;
        }
        else if (element == op)
        {
            std::cout << "Signal " << ip << " not an input pin" << std::endl;
            exit(1);
        }
    }
     for (const auto& element : ipop["op"]) {
        if (element == op)
        {
            opflag = true;
        }
        else if (element == ip)
        {
            std::cout << "Signal " << ip << " not an output pin" << std::endl;
            exit(1);
        }
    }
    if(!ipflag){
        std::cout <<"signal " << ip << " not found in " << filename<<std::endl;
        exit(1);
    }
    if(!opflag){
        std::cout <<"signal " << op << " not found in " << filename<<std::endl;
        exit(1);
    }
    wdag = parseFile(filename);
    
    //wdag.printGraph();
    wdag.popwieghts();
    wdag.printGraph();
    wdag.checkcycle(ip,op);
    std::unordered_map<std::string, std::string> paths;
    auto result = wdag.dijkstra(ip, op, paths);

    std::cout << "\n Dijkstras Shortest Path and Distance from input " << ip << " to output " << op << ":\n";

    if (result.first > 0){
        std::cout << "Shortest Path: ";
        for (const auto& node : result.second) {
            std::cout << node << "--> ";
        }
        std::cout << "Shortest Distance: " << result.first << "\n";
        std::cout << std::endl;
    }
    else{
        std::cout << "No path exist" << std::endl;
    }
    

}