#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <limits>
#include <algorithm>
#include<bits/stdc++.h>

using namespace std;

const int max_limit = INT_MAX;

struct Gate 
{
    string type;
    vector<string> inputs;
    int delay;
};

unordered_map<string, Gate> circuit;
void dfs(const string& node, unordered_map<string, int>& distance);

void readCircuit(const string& filename) 
{
    ifstream file(filename);
    if (!file) 
    {
        cerr << "Given wrong file name " << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    while (getline(file, line)) 
    {
        istringstream my_stream(line);
        string token;
        my_stream >> token;

        if (token == "INPUT")
        {
            string input_value;
            my_stream >> input_value;
            circuit[input_value] = {"INPUT", {}, 0};
        } 
        else if (token == "OUTPUT")
        {
            string output_value;
            my_stream >> output_value;
            circuit[output_value] = {"OUTPUT", {}, 0};
        } 
        else if (token == "AND" || token == "OR" || token == "NOT" || token == "NOR" || token == "BUF") 
        {
            string output, in1, in2;
            my_stream >> output >> in1 >> in2;

            int fanout = circuit[output].inputs.size();
            circuit[output] = {token, {in1, in2}, fanout};
        }
    }

    file.close();
}

int calculateDelay(const string& start, const string& end) 
{
    unordered_map<string, int> distance;

    for (const auto& entry : circuit) 
    {
        distance[entry.first] = max_limit;
    }

    dfs(start, distance);

    return distance[end];
}

void dfs(const string& node, unordered_map<string, int>& distance) 
{
    for (const string& neighbor : circuit[node].inputs) 
    {
        int weight = circuit[neighbor].delay;
        if (distance[node] + weight < distance[neighbor]) 
        {
            distance[neighbor] = distance[node] + weight;
            dfs(neighbor, distance);
        }
    }
}

int main(int argc, char* argv[]) 
{
    if (argc != 4) 
    {
        cerr << "Usage: ./iscas <filename> <input_gate> <output_gate>" << endl;
        return EXIT_FAILURE;
    }

    string filename = argv[1];
    string startGate = argv[2];
    string endGate = argv[3];
    
    
    
    readCircuit(filename);

    if (circuit.find(startGate) == circuit.end() || circuit.find(endGate) == circuit.end()) 
    {
        cerr << "Signal not found in the current file " << filename << endl;
        return EXIT_FAILURE;
    }

    int delay = calculateDelay(startGate, endGate);

    if (delay >= max_limit) 
    {
        cout << "No valid path found between " << startGate << " and " << endGate << endl;
    } 
    else 
    {
        cout << "Shortest path delay between " << startGate << " and " << endGate << " is " << delay << " units" << endl;
    }

    return EXIT_SUCCESS;
}