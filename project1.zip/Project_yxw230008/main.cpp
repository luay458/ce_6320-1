// The below code is done by the updated method according to Email on November 13, 2023

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <queue>
#include <map>
#include <limits>
#include <stack>

using namespace std;

// Function to check whether the file exists
bool fileExists(const std::string &filename) {
    std::ifstream file(filename.c_str());
    return file.good();
}

// Function to check whether Input nodes or Output nodes exist in this files
bool checkInputOutput(const std::vector<std::string> &vec, const std::string &value) {
    for (std::vector<std::string>::const_iterator it = vec.begin(); it != vec.end(); ++it) {
        if (*it == value) {
            return true;
        }
    }
    return false;
}

// Structure to represent an edge in the graph
struct Edge {
    string start;
    string end;
    int weight;
};

vector<Edge> edges;

// Function implementing Dijkstra's algorithm to find the shortest path in a graph
map<string, pair<int, stack<string> > > dijkstra(const vector<Edge>& edges, const string& startNode, const string& endNode) {
    // Create a map to store the shortest distances and paths from the start node
    map<string, pair<int, stack<string > > > result;

    // Create a priority queue to store nodes and their distances
    priority_queue<pair<int, string>, vector<pair<int, string> >, greater<pair<int, string> > > pq;

    // Initialize all distances to infinity and paths to empty stacks
    for (std::vector<Edge>::const_iterator it = edges.begin(); it != edges.end(); ++it) {
	const Edge& edge = *it;
        result[edge.start].first = numeric_limits<int>::max();
        result[edge.end].first = numeric_limits<int>::max();
        result[edge.start].second = stack<string>();
        result[edge.end].second = stack<string>();
    }

    // Set the distance of the start node to 0
    result[startNode].first = 0;
    result[startNode].second.push(startNode);

    // Push the start node and its distance into the priority queue
    pq.push(std::make_pair(0, startNode));


    // Dijkstra's algorithm
    while (!pq.empty()) {
        string currentNode = pq.top().second;
        int currentDistance = pq.top().first;
        pq.pop();

        if(currentNode == endNode) {
            break;
        }

        // Iterate through the edges
        for (std::vector<Edge>::const_iterator it = edges.begin(); it != edges.end(); ++it) {
	    const Edge& edge = *it;
            if (edge.start == currentNode) {
                // Calculate the new distance
                int newDistance = currentDistance + edge.weight;

                // Update the distance and path if it is shorter
                if (newDistance < result[edge.end].first) {
                    result[edge.end].first = newDistance;
                    result[edge.end].second = result[edge.start].second;
                    result[edge.end].second.push(edge.end);
                    pq.push(std::make_pair(newDistance, edge.end));
                }
            }
        }
    }

    return result;
}


int main(int argc, char *argv[]) {
    // Check the command line argument
    if (argc != 4) {
        std::cout << "Incorrect number of arguments" << std::endl;
        return 1;
    }
    
    // Extract command line arguments
    std::string BenchmarkFile = argv[1];
    std::string input = argv[2];
    std::string output = argv[3];
    
    // check if benchmark file exists
    if (!fileExists(BenchmarkFile)) {
        std::cout << "Wrong File name" << std::endl;
        return 1;
    }
    
    
    std::ifstream inputfile(BenchmarkFile.c_str());
    // Read input file and extract data
    std::string line;
    std::vector<std::string> inputData;
    std::vector<std::string> outputData;
    std::map<std::string, std::vector<std::string> > dataMap;

    while (std::getline(inputfile, line)) {
        // Extract input and output signals from the file
	if (line.find("INPUT(") == 0) {
            size_t start = 6; // Length of "INPUT("
            size_t end = line.find(")");
            if (end != std::string::npos) {
                inputData.push_back(line.substr(start, end - start));
            }
        } else if (line.find("OUTPUT(") == 0) {
            size_t start = 7; // Length of "OUTPUT("
            size_t end = line.find(")");
            if (end != std::string::npos) {
                outputData.push_back(line.substr(start, end - start));
            }
        } else if (!line.empty() && line[0] == 'G') {
	    // Extract graph data starting with 'G'
            size_t equalPos = line.find('=');
            if (equalPos != std::string::npos) {
                std::string key = line.substr(0, equalPos);
                std::string value = line.substr(equalPos + 1);

                // Extract values starting with 'G'
                size_t pos = value.find('G');
                while (pos != std::string::npos) {
                    size_t endPos = value.find_first_of(" ,)", pos);
                    if (endPos != std::string::npos) {
                        std::string subValue = value.substr(pos, endPos - pos);
                        dataMap[key].push_back(subValue);
                    }
                    pos = value.find('G', endPos);
                }
            }
        }
    }

    // Check if the specified input and output signals are valid
    bool checkInput = checkInputOutput(inputData, input);
    bool checkOutput = checkInputOutput(outputData, output);
    bool checkInputInOutput = checkInputOutput(outputData, input);
    bool checkOutputInInput = checkInputOutput(inputData, output);
    if (!checkInput && checkInputInOutput) {
        std::cout << "Signal " << input << " is not an input pin" << std::endl;
        return 1;
    } else if (!checkOutput && checkOutputInInput) {
        std::cout << "Signal " << output << " is not an output pin" << std::endl;
        return 1;
    } else if (!checkInput) {
        std::cout << "Signal " << input << " not found in file " << BenchmarkFile << std::endl;
        return 1;
    } else if (!checkOutput) {
        std::cout << "Signal " << output << " not found in file " << BenchmarkFile << std::endl;
        return 1;
    }

    // creating new map to store the edges with weight
    std::map<std::pair<std::string, std::string>, int> weightedEdges;

    // Iterate through dataMap to count occurrences of each key
    std::map<std::string, int> keyCount;
    // Iterate through dataMap to count occurrences of each key
    for (std::map<std::string, std::vector<std::string> >::const_iterator it = dataMap.begin(); it != dataMap.end(); ++it) {
	const std::string &key = it->first;
	const std::vector<std::string> &values = it->second;

	for (std::vector<std::string>::const_iterator valIt = values.begin(); valIt != values.end(); ++valIt) {
	    keyCount[*valIt]++;
	}
    }

    // Add weighted edges to the map
    for (std::map<std::string, std::vector<std::string> >::const_iterator it = dataMap.begin(); it != dataMap.end(); ++it) {
	const std::string &key = it->first;
	const std::vector<std::string> &values = it->second;

	for (std::vector<std::string>::const_iterator valIt = values.begin(); valIt != values.end(); ++valIt) {
	    int weight = keyCount[*valIt];  // Weight is the count of occurrences of key
	    weightedEdges[std::make_pair(*valIt, key)] = weight;
	}
    }
    
    
    
    // Store the weighted edges data into weight.txt file to read it further
    std::ofstream outputFile("weight.txt", std::ofstream::out | std::ofstream::trunc);

    for (std::map<std::pair<std::string, std::string>, int>::const_iterator it = weightedEdges.begin(); it != weightedEdges.end(); ++it) {
	const std::string &source = it->first.first;
	const std::string &target = it->first.second;
	int weight = it->second;

	// Store the data into weight.txt
	outputFile << source << " " << target << weight << "\n";
    }


    // Close the output file
    outputFile.close();
    
    
    // close the input file
    inputfile.close();
    
    // open weight.txt file
    ifstream inputFile("weight.txt");

    // Check if the file is opened successfully
    if (!inputFile.is_open()) {
        cerr << "Error opening the file." << endl;
        return 1; // return an error code
    }

    // Read the data from the file
    string start, end;
    int weight;

    while (inputFile >> start >> end >> weight) {
        // Update the values into the text file
	Edge edge;
        edge.start = start;
        edge.end = end;
        edge.weight = weight;
        edges.push_back(edge);
    }

    // Close the file
    inputFile.close();

    string startNode = input;
    string endNode = output;
    
    // Sending data to Dijkstra's function
    map<string, pair<int, stack<string> > > result = dijkstra(edges, startNode, endNode);

    // Output the result for the specified start and end nodes
    cout << "Shortest path from " << startNode << " to " << endNode;
    cout << " is " << result[endNode].first << " \n(Path: ";
    stack<string> path = result[endNode].second;
    if (path.empty()) {
        cout << "No Path";
    } else {
        stack<string> reversedPath;
        while (!path.empty()) {
            reversedPath.push(path.top());
            path.pop();
        }
        while (!reversedPath.empty()) {
            cout << reversedPath.top();
            reversedPath.pop();
            if (!reversedPath.empty()) {
                cout << " --> ";
            }
        }
    }
    cout << ")\n";

    return 0;
}
