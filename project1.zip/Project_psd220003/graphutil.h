#ifndef graphutil_h
#define graphutil_h
#include <string>

using namespace std;

//Declare variables used in graph creation from gates
//gate node to hold input/output variables
struct gate {
  string name;
  int fanout;
  gate* next;
};

//line node to mimic the actual gate functionality with delay
struct line {
  string source;
  string dest;
  int delay;
  int line_no = 0;
  line* next;
};

//Methods to create and print input/output variable nodes with required details
struct gate* CreateVar(string &name);
struct line* CreateGate(string s, string d);

//Method to clear whitespaces in netlist definitions
string clearwhitespace(string str);
#endif
