#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include "graphutil.h"

const int MAX_DELAY=-1;
using namespace std;

/*status definitions for dijkstra's
 * unseen = -1;
 * fringe = 0;
 * see = 1;
 * We modify each node status as above
 */

// method to identify if any fringes are available
bool CheckFringe(map<string,int> status, int total) {
  bool exists = false;
  for(auto it: status) {
    if(it.second == 0) {
      exists = true;
      break;
    }
  }
  return exists;
}

// method to identify the least distant intermediate node from current position
string GetMinFringe(map<string,int> delay, map<string,int> status, int total) {
  int min_delay = MAX_DELAY;
  string min_fringe = "";
  for(auto status_itr = status.begin(); status_itr != status.end(); status_itr++) {
    if(status[status_itr->first] == 0 && delay[status_itr->first] > min_delay) {
      min_delay = delay[status_itr->first];
      min_fringe = status_itr->first;
    } 
  }
  return min_fringe;
}

// method to find the shortest path using dijkstra's algorithm
void DijkstraCriticalPath(map<gate*,vector<gate*>> m, string s, string d) {
  // variables to store and track intermediate node status, parent and delay
  map<string,int> status;
  map<string,string> parent;
  map<string,int> delay;
  int net_delay=0;

  // set initial status, parent and delays of each node
  for(auto i=m.begin(); i!=m.end(); i++) {
    for(auto inp:i->second) {
      status[i->first->name] = -1;
      status[inp->name] = -1;
      parent[i->first->name] = i->first->name;
      parent[inp->name] = inp->name;
      delay[i->first->name] = MAX_DELAY;
      delay[inp->name] = MAX_DELAY;
    }
  }

  // mark the status of source as 'seen' and continue
  status[s] = 1;
  int count = 0;

  // get all the nodes attached to our source node as fringes
  for(auto it1=m.begin(); it1!=m.end(); it1++) {
    for(auto it2:it1->second) {
      if(it2->name == s) {
        status[it1->first->name] = 0;
        parent[it1->first->name] = s;
        delay[it1->first->name] = it1->first->fanout;
        //delay[it1->first->name] = it2->fanout;
      }
    }
  }

  // pointer to iterate inside graph
  auto temp_ptr = m.begin();

  int threshold=0;

  // while there are any fringes continue to find shortest path
  while(CheckFringe(status,m.size())) {
    auto it1 = m;
    if(threshold ==100000) {
      cout << "Combinational loop threshold occurred" <<endl;
      exit(0);
    }
   /* 
    cout <<"Printing status"<<endl;
    for(auto it: status)
      cout << it.first << " " << it.second <<endl;
    cout <<"Printing delay"<<endl;
    for(auto it: delay)
      cout << it.first << " " << it.second <<endl;
    cout <<"Printing parent"<<endl;
    for(auto it: parent)
      cout << it.first << " " << it.second <<endl;
   */

    // find the least fringe from given node
    string minFringe = GetMinFringe(delay,status,m.size());
    // cout << minFringe <<endl;

    // mark given fringe as 'seen' and continue
    status[minFringe] = 1;

    // get all nodes attached to fringes and apply algorithm iteratively
    for(auto it1 = m.begin();it1 != m.end(); it1++) {
      for(auto it2:it1->second) {
        if(it2->name == minFringe) {
          if(status[it1->first->name] == -1) {
            status[it1->first->name] = 0;
            parent[it1->first->name] = minFringe;
            delay[it1->first->name] = delay[minFringe]+it1->first->fanout;
            //delay[it1->first->name] = delay[minFringe]+it2->fanout;
            parent[it1->first->name] = minFringe;
          }
          else if((status[it1->first->name] = 0) && \
                  (delay[it1->first->name] < delay[minFringe]+it1->first->fanout)) {
            delay[it1->first->name] = delay[minFringe]+it1->first->fanout;
            //delay[it1->first->name] = delay[minFringe]+it2->fanout;
            parent[it1->first->name] = minFringe;
          }
        }
      }
    }
   threshold++;
  }

  // print the path and total delay
  if(status[d] != 1) {
    cout << "No path exists between source and destination" <<endl;
  }
  else {
    cout << "Net delay: " << delay[d]+1 <<endl;
    cout << "Path is: "<<endl;
    cout << d;
    while(d!=s) {
      d = parent[d];
      cout << " <-- " << d;
    }
    cout << endl;
  }
}
