#include <iostream>
#include <fstream>
#include <map>
#include <algorithm>
#include "createnet.cpp"
#include "graphutil.h"
#include "dijkstra.cpp"

using namespace std;

extern vector<string> inputs;
extern vector<string> outputs;

int main(int argc, char** argv) {
  // creating a map datatype to store the graph network
  map<gate*,vector<gate*>> net;
  // boolean variable to check file exists in working directory
  bool file_exists;
  // boolean variable to check if source/destination exists in netlist
  bool source_exists, dest_exists;
  // creating pointer to check if the file exists
  fstream f(argv[1]);
  // return type for checking if file exists
  file_exists = f.good();

  // condition to check number of arguments passed
  if(argc != 4) {
    cout << "Incorrect number of arguments." <<endl;
    return 0;
  }
  if(file_exists) {
    // create graph from netlist if file exists
    net = CreateGraphfromNetlist(argv[1]);
    cout << "Graph network created." <<endl;
    // print graph network built from netlist
    // PrintNetwork(net);
    // print the created network as adjacency list
    //PrintAdjList(net);

    // setting flags for source and destination nodes
   // for(auto it=net.begin();it != net.end();it++) {
      for(auto v_it:inputs) {
        //cout << v_it <<endl;
        if(argv[2] == v_it) {
          source_exists = true;
        }
      }
      for(auto v_it:outputs) {
        //cout << v_it <<endl;
        if(argv[3] == v_it) {
          dest_exists = true;
        }
      }
   // }
    // condition to check if given variables exists in file as either
    // inputs or outputs
    if(source_exists && dest_exists) {
      cout << "Starting Dijkstra's" <<endl;
      // calling dijkstra's algorithm for input and output nodes
      DijkstraCriticalPath(net,argv[2],argv[3]);
    }
    // check if source exists
    else if (!(source_exists)) {
      cout << "signal " << argv[2] << " not found in file " << argv[1] << endl; 
    }
    // check if destination exists
    else {
      cout << "signal " << argv[3] << " not found in file " << argv[1] << endl;
    }
  }
  else {
    cout << "Wrong file name" <<endl;
  }
  return 0;
}
