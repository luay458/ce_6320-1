#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <algorithm>
#include <sstream>
#include <typeinfo>
#include "graphutil.h"

using namespace std;

// variable to track no. of edges in graph from netlist gates
static long long line_count = 0;
static long long gate_number = 0;
static long long line_number = 0;

vector<gate*> nodes_out;
vector<gate*> fanout;

// containers to keep both input and output nodes seperately
vector <string> inputs;
vector <string> outputs;

// variable to track no. of nodes in graph from netlist variables
static long long node_count = 0;

// method definition to create variables in hardware
gate* CreateVar(string &varname) {
  gate* var = new gate;
  var->name = varname;
  var->fanout = 0;
  var->next = NULL;
  gate_number++;
  return var;
}

// method definition to create gates in hardware
line* CreateGate(string sname, string dname) {
  line* gate_node = new line;
  gate_node->source = sname;
  gate_node->dest = dname;
  gate_node->delay = gate_node->delay+1;
  gate_node->line_no = 0;
  gate_node->next = NULL;
  return gate_node;
}

// method to clear whitespaces between netlist definitions
string clearwhitespace(string str) {
  str.erase(remove(str.begin(), str.end(), ' '), str.end()); 
  return str;
}

// method to create graph from netlist file passed as "filename" string input
map<gate*,vector<gate*>> CreateGraphfromNetlist(string filename) {
  int graph_size = 0;
  // file pointer to open/close files
  ifstream fp;
  // variables to store each data element.
  string data,node_out;

  // graph elements built from circuit variables and gates
  map<gate*,vector<gate*>> network;
  
  // get only netlist definitions instead of whole file contnet
  string comment = "G";
  string inps = "I";
  string otps = "O";
  
  fp.open(filename);
  while(getline(fp,data)) {
    /*if(data.find(comment,0) == 0) {
      int pos = data.find("gat",0);
      while(pos != string::npos) {
        graph_size++;
        pos = data.find("gat",pos+1);
      }
    }*/

    // get all the input nodes and push into a vector to track
    if(data.find(inps,0) == 0) {
      int pos = data.find(inps,0);
      string gatenames;
      bool insidebrackets = false;
      for(char c:data) {
        if(c == '(') {
          insidebrackets = true;
          gatenames.clear();
        }
        else if(c == ')') {
          insidebrackets = false;
          if(!gatenames.empty()) {
            inputs.push_back(gatenames);
          }
        }
        else if(insidebrackets) {
          gatenames += c;
        }
      }
    }

    // get all the output nodes and push into a vector to track
    if(data.find(otps,0) == 0) {
      int pos = data.find(otps,0);
      string gatenames;
      bool insidebrackets = false;
      for(char c:data) {
        if(c == '(') {
          insidebrackets = true;
          gatenames.clear();
        }
        else if(c == ')') {
          insidebrackets = false;
          if(!gatenames.empty()) {
            outputs.push_back(gatenames);
          }
        }
        else if(insidebrackets) {
          gatenames += c;
        }
      }      
    }

    if(data.find(comment,0) == 0) {
      int pos = data.find("gat",0);
      while(pos != string::npos) {
        graph_size++;
        pos = data.find("gat",pos+1);
      }

      // print number of nodes in graph
    
      int p=data.find(" ");
      //cout <<endl<<"Output node: " << data.substr(0,p) << endl;
      // assign output gate variable name to node_out
      node_out = data.substr(0,p);
      // increment total nodes in graph to allocate space
      node_count = node_count+1;
      gate* new_var = new gate;
      new_var = CreateVar(node_out);
      //cout << "new_var created and pointed"<<endl;
      // add output node into outputs container
      nodes_out.push_back(new_var);
      //cout << "new_var Added to output nodes: "<<endl;
      //Remove whitespaces so that only required data is processed
      data = clearwhitespace(data);
      //cout <<"Input node: ";
      bool insidebrackets = false;
      vector<gate*> nodes_in;
      string vars;
      for(char c: data) {
        //Check for first occurrence of open bracket and obtain input nodes
        if( c == '(') {
          insidebrackets = true;
          vars.clear();
        }
        else if (c == ')') {
          insidebrackets = false;
          if(!vars.empty()) {
            //cout << vars;
            //Push into input nodes vector to create edges with output node
            //nodes_in.push_back(vars);   
            node_count += 1;

            //Create input node and push into inputs container
            gate* var_in = new gate;
            var_in = CreateVar(vars);
            //Create edge  between input node and output node
            var_in->next = new_var;
            nodes_in.push_back(var_in);
            fanout.push_back(var_in);
            //cout << "Created input node " << vars << endl; 
          }
        }
        else if (c==',' && insidebrackets) {
          if(!vars.empty()) {
            //cout << vars << ",";
            //Push into input nodes vector to create edges with output node
            //nodes_in.push_back(vars);
            node_count += 1;
            //Create input node and push into inputs container
            gate* var_in = new gate;
            var_in = CreateVar(vars);
            //Create edge  between input node and output node
            var_in->next = new_var;
            nodes_in.push_back(var_in);
            fanout.push_back(var_in);
          }
          vars.clear();
        }
        else if (insidebrackets) {
          vars += c;
        }
      }
      network.insert(make_pair(new_var,nodes_in));
    }
  }
  //cout << "Graph size: " << graph_size << endl;
  for (auto it = network.begin(); it != network.end(); it++) {
    int f = 0;
    //cout << it->first->name;
    string temp = it->first->name;
      for(auto s:fanout) {
        if(temp == s->name) {
         // cout << s->name <<" ";
          f++;
        }
      }
    it->first->fanout = f;
  }
  //cout << endl;
  //cout << "Total Inputs: " << nodes_in.size() << endl;
  //cout << "Total nodes: " << node_count << endl;
  /*for(auto i:fanout) {
    cout << i->name << " " ;
  }
  cout <<endl;*/
  fp.close();
  return network;
}


// method to print graph adjacency list
void PrintNetwork(map<gate*,vector<gate*>> n) {
  cout << "Printing graph network with delays" << endl;
  for (auto it = n.begin(); it != n.end(); it++) {
    cout << it->first->name << "(" << it->first->fanout << ")" << "--> ";
    for(auto s:it->second) {
      cout << s->name <<" ";
    }
    cout << endl;
  }
}

// method to print with next locations 
void PrintAdjList(map<gate*,vector<gate*>> n) {
  cout << "Printing graph network with next location of nodes" << endl;
  for (auto it = n.begin(); it != n.end(); it++) {
    cout << it->first->name << "(" << it->first->fanout << ")" << "next location: "<< it->first->next <<"--> ";
    for(auto s:it->second) {
      cout << s->name <<" next location: " << s->next <<" ";
    }
    cout << endl;
  }
}
