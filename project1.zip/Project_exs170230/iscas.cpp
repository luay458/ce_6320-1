/*
Evgeniy Swann MS CE
CE6320.001 Project
Using ISCAS’85 benchmark list to make a directed weighted graph.
Using Dijkstra's algorithm to find shortest path between a specific input/output pair.
I am using the variation, where the fanout from a node specifies the weight.
if A->B; A->C; A->D, then all 3 have a weight of 3.
Like the first figure in the email from the TA, Abdeljaber, Luay on 11/14/23.
*/

/*
Inclusions:
iostream for output and testing.
fstream to read the file.
sstream for sting parsing.
vector for dynamic storage.
unordered map as the baseline for the context of the problem.
queue and limits for ease with Dijkstra's algorithm.


I am not using namespace standard, since it appears t be a good coding practice to use std:: instead
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <limits>

/*
To tackle the transfer of the benchmark lists into a graph form, I decided to use an adjacency matrix.
I am using a 2D vector to store the edges and their weights.
I am using an unordered map to link gate names to their indices on the matrix.
*/
struct AdjacencyMatrix{

    //map gate names to their indices
    std::unordered_map<std::string, int> vertices;

    //2D index vector to store edge weights
    std::vector<std::vector<int>> matrix;

    //default initialization of an empty matrix
    //All additions are done through subsequent functions
    AdjacencyMatrix() = default;

    /*
    void addVertex; no return type;
    This function takes a string as a constant, meaning no modifications will take place.
    It is passed by reference to avoid copying.
    */
    void addVertex( const std::string& vertex) {

        //We check if the vertex already exists within the map. We don't want to have duplicates
        if(vertices.find(vertex) == vertices.end()){
            //we set the index to current size of the map
            int index = vertices.size();
            //we set the new vertex to the max index -> it will be added at the end
            vertices[vertex] = index;
            //we first fill out the corresponding column within the matrix with 0s
            //this is done to avoid having an extra column at the end
            for(auto& row : matrix) {
                    row.push_back(0);
            }
            //Then we proceed to fillout the new row with 0s
            matrix.push_back(std::vector<int>(vertices.size(), 0));

        }
    }


    /*
    void addEdge; no return;
    This function takes strings u and v, calculating the edge weight between them.
    Since in this project, there are no specific weight: they are 1 unless the fanout >1
    we calculate the weight based on existing edges of the initial vertex, u in this case.
    */
    void addEdge(const std::string& u, const std::string& v) {
        //the vertices are already added by the previous function
        //we can pull the index from the map, to connect to its position on the matrix.
        int indexU = vertices[u];
        int indexV = vertices[v];
        //placeholder to record the new weight
        //initialized to 0 in case there is no existing edges for the vertex.
        int newWeight= 0;
        /*
        Weight depends on existing edges, so we iterate through the row,
        looking for non-zero values, increasing them by 1 for the incoming edge.
        we use newWeight to record the new weight value.
        The only reason it's recorded every time, is due to little difference between a = b, and an if statement.
        */
        for (int& weight : matrix[indexU]) {
            if (weight > 0) {
                weight += 1;
                newWeight = weight;
            }
        }

        //if weight is still 0 after loop, then it's the first edge for this vertex
        //thus it's weight is 1
        if(newWeight == 0) matrix[indexU][indexV] = 1;
        //otherwise, weight is equivalent to weight of any other existing edge
        else matrix[indexU][indexV] = newWeight;

    }

    /*
    Dijkstra's algorithm; returns 2 vectors: distance and predecessors. Final path length and the gates that make it up
    We only take a constant reference to the starting input gate. Additionally this function will not modify any of the
    Adjacency matrix structure (post- const)
    */
    std::pair<std::vector<int>, std::vector<int>> dijkstra(const std::string& start) const {

        //Distances to every node, initialized to match the size of the matrix.
        //additionally initially filled with maximum int value, to act as infinite distance.
        std::vector<int> distances(matrix.size(), std::numeric_limits<int>::max());

        //vector to keep track of the current path. Same size as matrix,
        //initialized to -1 as in not in current path
        //the index of the gate previous to current will be recorded
        std::vector<int> previous(matrix.size(), -1);

        //vector for visited nodes. This prevent me from going to the combinational loops
        //false as in not visited yet
        std::vector<bool> visited(matrix.size(), false);

        //matrix index of the input gate
        int startIndex = vertices.at(start);

        //initialize distance to self as 0
        distances[startIndex] = 0;

        //We use a priority queue to explore the graph.
        //It uses a pair of ints as the element. Distance, followed by index of the gate within the matrix.
        //The pair gets stored within a vector of int pairs.
        //finally the comparator is "greater", which turns this priority queue into a min-heap type structure
        //where lowest pair gets priority
        std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> pq;

        //first node -> starting node
        pq.push({0, startIndex});

        //We are going to loop while the priority queue has elements
        while (!pq.empty()) {

                //pop the top element (lowest has priority)
                //get the index of the gate from it
            int u = pq.top().second;
            pq.pop();

            //if this gate has already been visited, we go to the next iteration
            if (visited[u]) {
                continue;
            }
            //otherwise, add the gate index to the visited vector
            visited[u] = true;

            //Here we iterate through every edge of gate 'u'
            for (size_t v = 0; v < matrix[u].size(); ++v) {

                    //Here we compare the following:
                    //We make sure that the weight of the edge is positive, since 0 implies no edge
                    //We make sure that the v node hasn't been visited already
                    //we make sure that the total distance from current node to next is lower than the total at that node.
                    //in other words if u -> v will have total distance 10, but we already explored a path to v with distance 9, we will skip that
                if (matrix[u][v] > 0 && !visited[v] && distances[v] > distances[u] + matrix[u][v]) {
                    //record the new distance to the node, using current total + edge weight
                    distances[v] = distances[u] + matrix[u][v];
                    //store previous gate index for current gate
                    previous[v] = u;
                    //push distance to v + index of v back to pq
                    pq.push({distances[v], v});
                }
            }
        }
        //return the distances to gates & path
        return {distances, previous};
    }

    /*
    printPath with no return type.
    This function is used specifically to print the path from input gate to output gate
    We take constant reference to vector previous, and a copy of output gate index
    This function is not allowed to modify any of the objects within the structure.
    */
    void printPath(const std::vector<int>& previous, int outputIndex) const {
        //create string vector to store path
        std::vector<std::string> path;
        //earlier in Dijkstra's we initialized all gates to -1
        //while the gates we traversed for the shortest path, store the index of previous node
        //here we assign an int to the output gate index, and traverse the previous vector backwards, until we hit input gate
        //which will have -1
        for (int i = outputIndex; i != -1; i = previous[i]) {
                //we call getGateName helper function to pull
                //the gate name from the vertices map, using the index
                //then push the gate to 'path'
            path.push_back(getGateName(i));
        }

        //this is terminal output loop
        //since the path is currently reversed, we reverse it using rbegin()
        //similarly we use rend() as the end position before the first gate in 'path' (last output gate)
        for (auto i = path.rbegin(); i != path.rend(); ++i) {
                //since i is a pointer, we need the string
            std::cout << *i;
            //we don't want an arrow after the output gate
            if (i + 1 != path.rend()) {
                std::cout << " -> ";
            }
        }
    }

    /*
    This is a helper for printPath.
    returns a string with gate name, takes a copy of gate index
    we simply iterate over vertices map, looking for our gate
    Similarly, this function doesn't make changes to existing vars within the struct
    */
    std::string getGateName(int index) const {
        //gate auto iterator, by reference
        for (const auto& gate : vertices) {
                //once found, return
            if (gate.second == index) {
                return gate.first;
            }
        }
    }
};

/*
Int checkgate, returns 0, 1, or 2, depending on outcome.
This is a helper function to error-check based on bad input, such as wrong input/output gate.
It takes a constant reference to IOmap, a map I use specifically for inputs and outputs later in code;
also const references to gate and type, which are gate name, like G1gat, and whether it's INPUT/OUTPUT.
*/
int checkGate( const std::unordered_map<std::string, std::string>& IOmap, const std::string& gate, const std::string& type) {

    //using auto for compiler to automatically pick a proper variable for iterator
    //Here I am looking for the map index of the gate in question.
    auto index = IOmap.find(gate);

    //we check if the index corresponds to the end of the map
    //in other words if there is no such gate.
    if(index != IOmap.end()){
            //if the gate exists, we check if it's the correct type
            if(index->second == type) {
                    //both name and type match -> return 0
                    return 0;

            } else {
                //if gate is there but type is wrong -> return 1
                return 1;
            }

    //if the gate is not present, we return 2, specifying that this gate is neither input nor output
    } else {

        return 2;
    }



}


/*
int Parser returns values 0 through 5, to specify error codes.
This function is in charge of reading through and parsing through the bench files.
It takes a reference to the adjacency matrix, and performs a number of transformations on it, as it stores different nodes and edges.
It takes constant references to file name, input gate name, and output gate name.
*/
int parser(AdjacencyMatrix& graph, const std::string& file, const std::string& in, const std::string& out){

    //we use this integer to store error code
    int checkError = 0;
    //we open the specified file
    std::ifstream infile(file);
    //if file does not exist, we return 1, specifying wrong file name
    if(!infile) return 1;
    //sting line will be used to hold lines of file, as we iterate through them
    std::string line;
    //we use an unordered map of string/string to store input/output gate names, and specifying the input/output type.
    std::unordered_map<std::string, std::string> IOmap;

    /*
    main loop, every iteration we read in new line
    */
    while(std::getline(infile, line)){
            //we disregard empty lines, and lines starting with #
          if(line.empty() ||line[0] == '#'){
            continue;
          }
            //we initialize string stream to perform extraction on it later
          std::istringstream iss(line);

        // this vector will hold string 'tokens' as we extract them
        std::vector<std::string> tokens;

        //the gates are typically separated by special characters, such as
        std::string token;

        //in this loop we attempt to tokenize the string, separating gates into their own tokens
        //we will later eliminate any special characters and useless strings
        while (iss >> token) {
            // we skip empty tokens
            if (!token.empty()) {
                tokens.push_back(token);
            }
        }
        //we use another vector to store 'clean' tokens for later addition to the matrix
        std::vector<std::string> finalTokens;

        //Here we iterate through every token in the vector
        for (size_t i = 0; i < tokens.size(); ++i) {
                //temp variable to hold current token
            const std::string& currentToken = tokens[i];

            //here we check for input/output gates, as those will be within the same 'token'
            if (currentToken.compare(0, 5, "INPUT") == 0 || currentToken.compare(0, 6, "OUTPUT") == 0) {

                //the only useless characters here are the parentheses
                //we store the location for type/gate extraction
                size_t openParenPos = currentToken.find('(');
                size_t closeParenPos = currentToken.find(')');

                //we assume the proper input file, with proper format for extraction
                //the type, INPUT/OUTPUT will be from 0th index until '('
                std::string type = currentToken.substr(0, openParenPos);
                //the name will be '('+1 and will be the length of ') - ( - 1'
                std::string gateName = currentToken.substr(openParenPos + 1, closeParenPos - openParenPos - 1);
                //we then store the gate name and type in IOmap
                IOmap[gateName] = type;
                //else it is not an INPUT/OUTPUT gate, so the parsing changes.
            } else {
                //within the benchmark lists, 'G' at the start of gate name remains constant.
                //First gate is also the intermediate outpute, while the rest are intermediate inputs.
                size_t gPos = currentToken.find('G');
                //while loop is executed so long as the 'G' is within the token.
                //With proper format and no errors, this loop will only execute once
                //but in case one of the lines in the lists is missing a space, and 2 gates end up
                //within the same token, they can both be extracted separately.
                while (gPos != std::string::npos) {
                    //find location from 'G' to a special character, that can be present:
                    // '='    ','    '('    ')'    ' '
                    //find_first_of lets us find the index
                    size_t nextSpecialChar = currentToken.find_first_of("=(), ", gPos);
                    //we extract the gate token 'gToken'
                    std::string gToken = currentToken.substr(gPos, nextSpecialChar - gPos);
                    //gtoken is pushed into finaltokens vector
                    finalTokens.push_back(gToken);

                    //check if there is another gate within the token
                    gPos = currentToken.find('G', nextSpecialChar);
                }
            }
        }

        //for each new clean string - clean gate in finalTokens
        //we want to create a vertex, by calling addvertex function
        for(const std::string& i : finalTokens){
                graph.addVertex(i);

        }

        //after adding the vertices we want to add edges
        //since we will always send the first gate as destination (v) we modify
        //the for loop slightly
        for (size_t i = 1; i < finalTokens.size(); ++i){
                graph.addEdge(finalTokens[i], finalTokens[0]);

        }

    }
    //after having the adjacency matrix completed, we check for errors
    //in regards to gates, input/output
    //we return specific codes, that are better explained in the main function
    checkError = checkGate(IOmap, in, "INPUT");
    if(checkError == 1) return 4;
    else if (checkError == 2) return 2;
    checkError = checkGate(IOmap, out, "OUTPUT");
    if(checkError == 1) return 5;
    else if (checkError == 2) return 3;


}

/*
main driver, return 0 or 1, if successful/erroneous
we take exactly 4 arguments from command line.
The correctness of the arguments is checked in execution of the code

*/
int main(int argc, char *argv[]) {

    //if the # of arguments is anything other than 4, we terminate
    if (argc != 4) {
        std::cout << "Incorrect number of arguments";
        return 1;
    }

    //initialize the graph
    AdjacencyMatrix graph;
    //assign file, input, and output to strings
    std::string file = argv[1];
    std::string in = argv[2];
    std::string out = argv[3];

    //initiate input check for error checking, and call the parser with given arguments
    int inputCheck = parser(graph, file, in, out);

    //after parser is done it's going to return a code 0-5 to identify errors
    //we use switch to terminate and display a specific message if 1-5 are detected
    //1: wrong file
    //2: input signal is wrong
    //3: output signal is wrong
    //4: input signal is an output signal
    //5: output signal is an input signal
    //we were not asked to check for all errors, therefore we terminate the second a single error is encountered
    switch(inputCheck){
    case 1:
        std::cout << "Wrong file name";
        return 1;
    case 2:
        std::cout << "Signal " << in << " not found in file " << file;
        return 1;
    case 3:
        std::cout << "Signal " << out << " not found in file " << file;
        return 1;
    case 4:
        std::cout << "Signal " << in << " not an input pin";
        return 1;
    case 5:
        std::cout << "Signal " << out << " not an output pin";
        return 1;
    default:
        break;
    }

    //here we finally call dijkstra's algorithm, and pass the input gate string
    //dijkstra has 2 return vectors, we use auto to let the compiler choose proper holding variable
    auto result = graph.dijkstra(in);
    //create 2 vectors for distances to gates and gate path of previous gates
    //split 'result' into first and second.
    std::vector<int> distances = result.first;
    std::vector<int> previous = result.second;
    //pull the index of the output gate we are looking for
    int outputIndex = graph.vertices.at(out);

    //if distance equals to max int value, there is no path, it's infinity
    //I output no path and the max int to show infinite distance
    if (distances[outputIndex] == std::numeric_limits<int>::max()) {
        std::cout << in << " -> " << out << " no path: " << std::numeric_limits<int>::max() << std::endl;
        //otherwise if distance < max int value, there is a path
        // we call helper function printPath, to backtrack
    } else {
        std::cout << in << " -> " << out << " shortest path: ";
        // Print the path, using output index and previous vector
        graph.printPath(previous, outputIndex);
        std:: cout << " = " << distances[outputIndex] << std::endl;
    }

    //terminate upon successful completion
    return 0;
}

