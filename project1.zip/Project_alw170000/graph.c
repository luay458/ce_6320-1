#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include "graph.h"

//Structure to hold graph before calculations
struct graph{
    char* input;	//input string and index in names map
    int in;
    char* output;	//output string and index in names map
    int out;

    int numVerts;       //Number of verticess

    int** graph;	//Graph
    char *names[];	//names map
};

//Read file and build graph
struct graph* buildGraph(char *benchFile, char *in, char *out){
    //Signals for checking correct input and output signals
    int inFound = -1;
    int outFound = -1;

    //Create new graph struct for reading into
    struct graph* newGraph = malloc(sizeof(struct graph));
    newGraph->numVerts = 0;

    //Save name of input and output signals
    newGraph->input = malloc(sizeof(char)*strlen(in));
    strncpy(newGraph->input, in, strlen(in));
    newGraph->output = malloc(sizeof(char)*strlen(out));
    strncpy(newGraph->output, out, strlen(out));

    //Open file, output error if file does not exist
    FILE *bench = fopen(benchFile, "r");
    if( bench == NULL ){
        printf("Wrong file name\n");
	free(newGraph->input);
	free(newGraph->output);
	free(newGraph);
	return NULL;
    }

    //Variables for use in parsing file
    char *token, *token2;
    char *saveptr, *saveptr2;

    //Read file line by line
    char line[1024];
    while (fgets(line, 1024, bench)) {
        //check for comment or empty line
        if(line[0] == '#' || line[0] == '\r' || line[0] == '\n'){
            continue;
	}

	//check inputs and outputs
	if(strncmp(line, "INPUT", 5) == 0){
	    token = strtok_r(line, "()", &saveptr);
            token = strtok_r(NULL, "()", &saveptr);
	    //check for input signal
            if(strcmp(token, newGraph->input) == 0){
                inFound = 1;
	    }
	    //check if output signal is listed as input
	    if(strcmp(token, newGraph->output) == 0){
	        printf("Signal %s is not an output pin\n", newGraph->output);
	        free(newGraph->input);
		free(newGraph->output);
		free(newGraph);
	        return NULL;
	    }
	    //if line is an input, move to next line, all parsing for this style of line is complete
	    continue;
	}
	if(strncmp(line, "OUTPUT", 6) == 0){
	    token = strtok_r(line, "()", &saveptr);
	    token = strtok_r(NULL, "()", &saveptr);
	    //check for output signal
	    if(strcmp(token, newGraph->output) == 0){
                outFound = 1;
            }
	    //check if input is listed as output
	    if(strcmp(token, newGraph->input) == 0){
	        printf("Signal %s is not an input pin\n", newGraph->input);
	        free(newGraph->input);
		free(newGraph->output);
		free(newGraph);
	        return NULL;
            }
	    //no further parsing needed for this line
	    continue;
	}

	//output error if input/output is wrong
	if(inFound == -1){
            printf("Signal %s not found in file %s\n", newGraph->input, benchFile);
	    free(newGraph->input);
	    free(newGraph->output);
	    free(newGraph);
	    return NULL;
	}
	if(outFound == -1){
	    printf("Signal %s not found in file %s\n", newGraph->output, benchFile);
	    free(newGraph->input);
	    free(newGraph->output);
	    free(newGraph);
	    return NULL;
	}

	//Process gates to find number of verticies
        token = strtok_r(line, " =", &saveptr);
	
	//check if gate is in list
	int i;
	int vertFound = -1;
	for(i = 0; i < newGraph->numVerts; i++){
            if(strcmp(token, newGraph->names[i]) == 0){
                vertFound = i;
		break;
	    }
	}

	//Add to list if not in list
	if(vertFound == -1){
	    newGraph->numVerts++;
            newGraph = realloc(newGraph, sizeof(struct graph) + sizeof(char*) * newGraph->numVerts);
	    newGraph->names[newGraph->numVerts - 1] = malloc(sizeof(char) * strlen(token));
	    strcpy(newGraph->names[newGraph->numVerts - 1], token);
	}

	//Process after gate
        token = strtok_r(NULL, " =", &saveptr);
	token2 = strtok_r(token, "(,)", &saveptr2);
	token2 = strtok_r(NULL, "(,)", &saveptr2);
	
	//process all tokens in string
	while(strcmp(token, "") != 0){
	    while(strcmp(token2, "") != 0){
	        //if char is return or newline, move to next token, check both since both are used in bench files
	        if(token2[0] == '\r' || token2[0] == '\n'){
                    break;
	        }

                //check if vertex is in list
                vertFound = -1;
		for(i = 0; i < newGraph->numVerts; i++){
		    if(strcmp(token2, newGraph->names[i]) == 0){
		        vertFound = i;
			break;
		    }
		}
               
	        //Add to list if not in list
		if(vertFound == -1){
		    newGraph->numVerts++;
		    newGraph = realloc(newGraph, sizeof(struct graph) + sizeof(char*) * newGraph->numVerts);
		    newGraph->names[newGraph->numVerts - 1] = malloc(sizeof(char) * strlen(token2));
		    strcpy(newGraph->names[newGraph->numVerts - 1], token2);
		}
		
		token2 = strtok_r(NULL, " (,)", &saveptr2);
		//this is a end of line condition
	        if(token2 == NULL){
                    break;
	        }
	    }
            token = strtok_r(NULL, " =", &saveptr);
	    if(token == NULL){
                break;
	    }
	    token2 = strtok_r(token, "(,)", &saveptr2);
	}
    }

    //reset read file and allocate graph now that size is known
    rewind(bench);
    newGraph->graph = malloc(sizeof(int *) * newGraph->numVerts);
    int i;
    for(i = 0; i < newGraph->numVerts; i++){
        newGraph->graph[i] = malloc(sizeof(int) * newGraph->numVerts);
	int j;
	for(j = 0; j < newGraph->numVerts; j++){
            newGraph->graph[i][j] = 0;
	}
    }


    //read file again
    while (fgets(line, 1024, bench)) {
        //check for comment or empty line
	if(line[0] == '#' || line[0] == '\r' || line[0] == '\n'){
	    continue;
	}

        //We do not need to process these lines again
	if(strncmp(line, "INPUT", 5) == 0){
            continue;
	}
        if(strncmp(line, "OUTPUT", 6) == 0){
	    continue;
	}

	//we are finding sources and destinations to populate graph here
	char *token, *token2;
	char *saveptr, *saveptr2;
	int src, dest;
	token = strtok_r(line, " =", &saveptr);

        //find destination index
        for(i = 0; i < newGraph->numVerts; i++){
            if(strcmp(token, newGraph->names[i]) == 0){
                dest = i;
                break;
            }
        }

        //find sources to that gate
	token = strtok_r(NULL, " =", &saveptr);
	token2 = strtok_r(token, "(,)", &saveptr2);
	token2 = strtok_r(NULL, "(,)", &saveptr2);
	
	while(strcmp(token, "") != 0){
	    while(strcmp(token2, "") != 0){
	        //move to next token after token is complete
	        if(token2[0] == '\r' || token2[0] == '\n'){
	            break;
	        }

                //find source index
		for(i = 0; i < newGraph->numVerts; i++){
		    if(strcmp(token2, newGraph->names[i]) == 0){
		        src = i;
		        break;
		    }
		}
		
		//set graph to true for that edge
		newGraph->graph[src][dest] = 1;

                //move to next token
		token2 = strtok_r(NULL, " (,)", &saveptr2);
		if(token2 == NULL){
		    break;
		}

	    }
	    token = strtok_r(NULL, " =", &saveptr);
	    if(token == NULL){
	        break;
            }
            token2 = strtok_r(token, "(,)", &saveptr2);
        }
    }

    //close file
    fclose(bench);

    //set indexes for path to test
    for(i = 0; i < newGraph->numVerts; i++){
        if(strcmp(newGraph->input, newGraph->names[i]) == 0){
            newGraph->in = i;
        }
	if(strcmp(newGraph->output, newGraph->names[i]) == 0){ 
	    newGraph->out = i;
        }
    }

    //edit graph to be based on weights
    int j;
    int weight;
    for(i = 0; i < newGraph->numVerts; i++){
        //calculate weight based on number of vertexes in row
        weight = 0;
        for(j = 0; j < newGraph->numVerts; j++){
	    if(newGraph->graph[i][j] > 0){
                weight++;
	    }
	}
	//this is usually for output nodes - otherwise weight would be 0, not wanted
	if(weight == 0){
            weight++;
	}

        //for any value in column with a weight, set to weight for that edge
        for(j = 0; j < newGraph->numVerts; j++){
            if(newGraph->graph[j][i] > 0){
                newGraph->graph[j][i] = weight; 
            }
        }

    }

    return newGraph;
}

//Shortest path calculation
void shortestPath(struct graph* g){
    //create and initialize values for algorithm
    int visited[g->numVerts];
    int distance[g->numVerts];
    int previous[g->numVerts];

    int i;
    for(i = 0; i < g->numVerts; i++){
        visited[i] = -1;
	distance[i] = INT_MAX;
	previous[i] = -1;
    }

    //loop to perform algorithm, start at input
    int exit = -1;
    int visit = g->in;
    distance[visit] = 0;
    while(exit == -1){
        //visit node
        visited[visit] = 1;

	//check neighbors for shorter path
	if(distance[visit] != INT_MAX){
	    for(i = 0; i < g->numVerts; i++){
	        if(g->graph[visit][i] > 0 && g->graph[visit][i] + distance[visit] < distance[i]){
                    distance[i] = g->graph[visit][i] + distance[visit];
		    previous[i] = visit;
	        }
	    }
	}

        //find next node to visit
	int next = -1;
	for(i = 0; i < g->numVerts; i++){
            if(visited[i] == -1){
	        if(next == -1){
                    next = i;
		} else if (distance[i] < distance[next]) {
		    next = i;
		}
	    }
	}
	
	//exit if all nodes are visited
	if(next == -1){
            exit = 1;
	} else {
            visit = next;
	}
    }

    //for testing purposes - print table for algorithm
    /*for(i = 0; i < g->numVerts; i++){
        printf("%s: %d, %d, %d\n", g->names[i], visited[i], distance[i], previous[i]);
    }*/

    //output for no path between input and output
    if(distance[g->out] == INT_MAX){
        printf("No path between %s and %s found.\n", g->names[g->in], g->names[g->out]);
	return;
    }

    //find path for outputting
    int* path;
    int length = 0;
    int trav = g->out;
    exit = -1;
    while(exit == -1){
        //add node to list
        length++;
        path = realloc(path, sizeof(int)*length);
	path[length - 1] = trav;

        //exit once at input
	trav = previous[trav];
	if(trav == -1){
            exit = 1;
	}
    }

    //list is in reverse order, just output in reverse
    for(i = length; i > 0; i--){
        printf("%s --> ", g->names[path[i - 1]]);
    }
    //output length
    printf("Length: %d\n", distance[g->out]);

}

//Deconstructor for a graph
void deleteGraph(struct graph* g){
    // Testing for correctness of building graph - adjancency matrix for graph
    /*int i, j;
    for(i = 0; i < g->numVerts; i++){
        printf("%s: ", g->names[i]);
	if(strlen(g->names[i]) != 6){
            printf(" ");
	}
        for(j = 0; j < g->numVerts; j++){
	    printf("%d,", g->graph[i][j]);
	}
	printf("\n");
    }*/

    //free allocated space in arrays
    free(g->input);
    free(g->output);
    
    int i;
    for(i = 0; i < g->numVerts; i++){
        free(g->names[i]);
	free(g->graph[i]);
    }

    //free arrays and structure itself
    free(g->graph);
    free(g);
    return;
}
