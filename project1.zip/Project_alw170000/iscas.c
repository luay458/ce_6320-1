#include <stdio.h>
#include "graph.h"

//main file for project - only applies functions in graph.c
int main(int argc, char *argv[]){
    //check the number of arguments
    if (argc != 4){
        printf("Incorrect number of arguments\n");
	return 1;
    }

    //construct the graph, read file and build graph
    struct graph* g = buildGraph(argv[1], argv[2], argv[3]);

    //this is an error condition, error message will print from construction
    if (g == NULL){
	return 1;
    }

    //run shortest path algorithm
    shortestPath(g);

    //delete graph structure - clean up allocated memory
    deleteGraph(g);

    return 0;
}
