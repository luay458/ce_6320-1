#ifndef GRAPH
#define GRAPH

//Structure to hold graph
struct graph;

//Function to build graph from bench file
struct graph* buildGraph(char*, char*, char*);

//Function to find shortest path
void shortestPath(struct graph*);

//Function to delete graph after use
void deleteGraph(struct graph*);

#endif
