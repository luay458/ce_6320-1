#ifndef EDGE_H
#define EDGE_H


// definition of edge structure which represents an edge in the graph 
struct Edge {
    int target_vertex;
    int edge_weight;
};

#endif

