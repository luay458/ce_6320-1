#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define MAX_LINE_LENGTH 65536
#define MAX_NODES 10000 // Adjust based on the expected size of the circuit

typedef struct {
    int targetNode;
    int weight;
} Edge;

typedef struct {
    Edge *edges;
    int numEdges;
    char nodeName[MAX_LINE_LENGTH];
    int isInput;
    int isOutput;
    int fanOut;
} Node;

typedef struct {
    Node *nodes;
    int numNodes;
} Graph;

Graph* createGraph() {
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    if (!graph) {
        fprintf(stderr, "Failed to allocate memory for graph.\n");
        exit(EXIT_FAILURE);
    }
    graph->nodes = (Node *)calloc(MAX_NODES, sizeof(Node));
    if (!graph->nodes) {
        fprintf(stderr, "Failed to allocate memory for nodes.\n");
        free(graph);
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < MAX_NODES; ++i) {
        graph->nodes[i].edges = (Edge *)calloc(MAX_NODES, sizeof(Edge));
        if (!graph->nodes[i].edges) {
            fprintf(stderr, "Failed to allocate memory for edges.\n");
            while (--i >= 0) free(graph->nodes[i].edges);
            free(graph->nodes);
            free(graph);
            exit(EXIT_FAILURE);
        }
    }
    graph->numNodes = 0;
    return graph;
}

void freeGraph(Graph *graph) {
    if (graph) {
        if (graph->nodes) {
            for (int i = 0; i < MAX_NODES; ++i) {
                free(graph->nodes[i].edges);
            }
            free(graph->nodes);
        }
        free(graph);
    }
}

int addNode(Graph *graph, char *nodeName) {
    int i;
    for (i = 0; i < graph->numNodes; i++) {
        if (strcmp(graph->nodes[i].nodeName, nodeName) == 0) {
            return i;
        }
    }
    strcpy(graph->nodes[graph->numNodes].nodeName, nodeName);
    graph->nodes[graph->numNodes].numEdges = 0;
    graph->nodes[graph->numNodes].isInput = 0;
    graph->nodes[graph->numNodes].isOutput = 0;
    graph->nodes[graph->numNodes].fanOut = 0;
    return graph->numNodes++;
}

int findNodeIndex(Graph *graph, const char *nodeName) {
    for (int i = 0; i < graph->numNodes; i++) {
        if (strcmp(graph->nodes[i].nodeName, nodeName) == 0) {
            return i;
        }
    }
    return -1; // Node not found
}
void addEdge(Graph *graph, int srcNodeIndex, int destNodeIndex, int weight) {
    graph->nodes[srcNodeIndex].edges[graph->nodes[srcNodeIndex].numEdges].targetNode = destNodeIndex;
    graph->nodes[srcNodeIndex].edges[graph->nodes[srcNodeIndex].numEdges].weight = weight;
    graph->nodes[srcNodeIndex].numEdges++;
}

void parseBenchFile(char *fileName, Graph *graph) {
    FILE *file = fopen(fileName, "r");
    char line[MAX_LINE_LENGTH], *token, nodeName[MAX_LINE_LENGTH];
    int srcNodeIndex, destNodeIndex, isInput;

    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#') continue; // Skip comments

        token = strtok(line, " =(),");
        if (strcmp(token, "INPUT") == 0 || strcmp(token, "OUTPUT") == 0) {
            isInput = strcmp(token, "INPUT") == 0;
            while ((token = strtok(NULL, " =(),\n\r")) != NULL) {            
		int nodeIndex = addNode(graph, token);
                if (isInput) graph->nodes[nodeIndex].isInput = 1;
                else graph->nodes[nodeIndex].isOutput = 1;
            }
        } else {
            strcpy(nodeName, token);
            srcNodeIndex = addNode(graph, nodeName);

            while ((token = strtok(NULL, " =(),\n\r")) != NULL) {
                destNodeIndex = addNode(graph, token);
                addEdge(graph, destNodeIndex, srcNodeIndex, 1); // Default weight, will be updated
            }
        }
    }

    fclose(file);
}

void calculateFanOutsAndUpdateDelays(Graph *graph) {
    int i, j;
    for (i = 0; i < graph->numNodes; i++) {
        graph->nodes[i].fanOut = 0; // Reset fanOut before counting
    }
    
    for (i = 0; i < graph->numNodes; i++) {
        for (j = 0; j < graph->nodes[i].numEdges; j++) {
            int targetNodeIndex = graph->nodes[i].edges[j].targetNode;
            graph->nodes[targetNodeIndex].fanOut++;
        }
    }

    for (i = 0; i < graph->numNodes; i++) {
        for (j = 0; j < graph->nodes[i].numEdges; j++) {
            int targetNodeIndex = graph->nodes[i].edges[j].targetNode;
            graph->nodes[i].edges[j].weight = graph->nodes[targetNodeIndex].fanOut;
        }
    }
}

void dijkstra(Graph *graph, int sourceIndex, int *distances, int *predecessors) {
    int visited[MAX_NODES] = {0};
    int i, j;

    // Initialize distances and predecessors
    for (i = 0; i < graph->numNodes; i++) {
        distances[i] = INT_MAX;
        predecessors[i] = -1;
    }
    distances[sourceIndex] = 0;

    // Loop for each vertex in the graph
    for (i = 0; i < graph->numNodes; i++) {
        // Find the vertex with the minimum distance
        int minDistance = INT_MAX;
        int minIndex = -1;
        for (j = 0; j < graph->numNodes; j++) {
            if (!visited[j] && distances[j] <= minDistance) {
                minDistance = distances[j];
                minIndex = j;
            }
        }

        // Mark the vertex as visited
        visited[minIndex] = 1;

        // Update the distances of the adjacent vertices
        for (j = 0; j < graph->nodes[minIndex].numEdges; j++) {
            int edgeTarget = graph->nodes[minIndex].edges[j].targetNode;
            int edgeWeight = graph->nodes[minIndex].edges[j].weight;
            if (!visited[edgeTarget] && (minDistance + edgeWeight) < distances[edgeTarget]) {
                distances[edgeTarget] = minDistance + edgeWeight;
                predecessors[edgeTarget] = minIndex;
            }
        }
    }
}

void printPathAndDelay(Graph *graph, int sourceIndex, int destinationIndex, int *predecessors) {
    int stack[MAX_NODES];  // Use a stack to reconstruct the path
    int top = -1;  // Stack pointer
    int totalDelay = 0;
    int currentNodeIndex = destinationIndex;

    // Reconstruct the path by pushing nodes onto the stack
    while (currentNodeIndex != -1 && currentNodeIndex != sourceIndex) {
        stack[++top] = currentNodeIndex;
        currentNodeIndex = predecessors[currentNodeIndex];
    }
    stack[++top] = sourceIndex;  // Add the source at the end

    // Pop the stack to print the path and calculate the delay
    printf("Path: ");
    while (top > 0) {
        int nodeIndex = stack[top];
        int nextNodeIndex = stack[top - 1];
        printf("%s -> ", graph->nodes[nodeIndex].nodeName);

        // Find the edge between the current node and the next to calculate the delay
        for (int i = 0; i < graph->nodes[nodeIndex].numEdges; i++) {
            if (graph->nodes[nodeIndex].edges[i].targetNode == nextNodeIndex) {
                totalDelay += graph->nodes[nodeIndex].edges[i].weight;
                break;
            }
        }
        top--;
    }
    printf("%s\n", graph->nodes[stack[top]].nodeName);  // Print the source node

    printf("Total delay: %d units\n", totalDelay);
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Incorrect number of arguments\n");
        return 1;
    }

    // Check if the bench file can be opened
    FILE *benchFile = fopen(argv[1], "r");
    if (!benchFile) {
        printf("Wrong file name\n");
        return 1;
    }
    fclose(benchFile);

    Graph *circuitGraph = createGraph();
    parseBenchFile(argv[1], circuitGraph);
    calculateFanOutsAndUpdateDelays(circuitGraph);

    int sourceIndex = findNodeIndex(circuitGraph, argv[2]);
    int destinationIndex = findNodeIndex(circuitGraph, argv[3]);

    // Check if source and destination nodes exist
    if (sourceIndex == -1 || destinationIndex == -1) {
        if (sourceIndex == -1) {
            printf("Signal Comet %s not found in file %s\n", argv[2], argv[1]);
        }
        if (destinationIndex == -1) {
            printf("Signal Comet %s not found in file %s\n", argv[3], argv[1]);
        }
        freeGraph(circuitGraph);
        return 1;
    }

    // Check if source is an input and destination is an output
    if (!circuitGraph->nodes[sourceIndex].isInput || !circuitGraph->nodes[destinationIndex].isOutput) {
        if (!circuitGraph->nodes[sourceIndex].isInput) {
            printf("Signal %s is not an input pin\n", argv[2]);
        } else {
            printf("Signal %s is not an output pin\n", argv[3]);
        }
        freeGraph(circuitGraph);
        return 1;
    }

    int *distances = (int *)calloc(circuitGraph->numNodes, sizeof(int));
    int *predecessors = (int *)calloc(circuitGraph->numNodes, sizeof(int));
    if (!distances || !predecessors) {
        fprintf(stderr, "Failed to allocate memory for distances or predecessors.\n");
        freeGraph(circuitGraph);
        return 1;
    }

    dijkstra(circuitGraph, sourceIndex, distances, predecessors);
    printPathAndDelay(circuitGraph, sourceIndex, destinationIndex, predecessors);

    free(distances);
    free(predecessors);
    freeGraph(circuitGraph);

    return 0;
}
