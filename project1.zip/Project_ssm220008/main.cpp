# include <iostream>
# include <cstdlib>
# include <string>
# include <fstream>
# include <sstream>
# include <cstring>
# include <vector>
# include <climits>


# define NO_PARENT -1


using namespace std;

// This function parses the file, removes the comments and returns the the rest of the text as a string
string parseTxt(char* fileName){
    ifstream parser(fileName, ifstream::in);
    string line;
    ostringstream output_stream;

    // remove comments
    while (getline(parser, line))
    {
        if(line[0] != '#' && line != ""){
            output_stream << line << endl;
        }
    }
    
    string output_str;
    output_str = output_stream.str();
    // return output string without comments
    return output_str;
}

// This function checks if the given node exists in the bench file as INPUT/OUTPUT
bool Nodelst(string parseTxt, string Nodetype, char* nodeName){
    string line;
    istringstream strmParsTxt(parseTxt);
    bool found = false;
    // To store inputs in stream
    stringstream ss;
    // A string to hold all the input nodes in an assignment
    string inputsLst;

    int inputNo = 0;
    while (getline(strmParsTxt, line)){
        if (line.find(Nodetype) == 0 ){
            line = line.substr( line.find('(') + 1, line.find(')') - line.find('(') - 1);

            inputsLst = inputNo > 0? inputsLst + " " + line : line;
            inputNo++;
        }
    }

    // store string into a stream
    ss << inputsLst;
    // Create a list of inputs
    string* inLst = new string[inputNo];

    // Store the values into the list
    int i = 0;
    while (ss){
        ss >> inLst[i];
        i++;
    }

    // Check if the input is in the input node list
    for (int i = 0; i < inputNo; i++){
        if (nodeName == inLst[i]){
            found = true;
            break;
        }
    }

    return found;
}

string rmvCommas(string txtWcommas){        // remove commas from the given string
    string txtWOcommas;
    int len = txtWcommas.length();
    for (int i = 0; i < len; i++){
        if(txtWcommas[i] != ',')
        txtWOcommas.push_back(txtWcommas[i]);
    }
    return txtWOcommas;
}

int countWords(string str1){                // Count the number of words in the string
    int count = 0;
    stringstream ss(str1);
    string temp;
    while(ss >> temp) count++;

    return count;
}


// Function to list all the nodes in the circuit without duplication
vector <string> parsing2getNodes(string parsedTxt){
    string line, outs;
    istringstream StreamTxt(parsedTxt);
    stringstream ss;
    string temp;
    vector <string> nodeVec;
    bool chkFlg;

    while (getline(StreamTxt, line)){       // parse the file line by line
        // ignore lines that are declaring inputs/outputs
        if(line.find("INPUT") == string::npos && line.find("OUTPUT") == string::npos){
            ss.clear();
            ss << line;
            ss >> outs; // = line.substr(0, line.find('=') - 1 );
            chkFlg = false;
            for (unsigned int i = 0; i < nodeVec.size(); i++){
                if (nodeVec[i] == outs){
                    chkFlg = true;
                    break;
                }
            }
            // if lefthand node of '=' sign doesn't exist in the vector add it
            if(chkFlg == false) nodeVec.push_back(outs);
            
            line = line.substr( line.find('(') + 1, line.find(')') - line.find('(') - 1);
            line = rmvCommas(line);
            ss.clear();
            ss.str("");

            ss << line;
            while (ss >> temp){
                chkFlg = false;
                for (unsigned int i = 0; i < nodeVec.size(); i++){
                    if(temp == nodeVec[i]){
                        chkFlg = true;
                        break;
                    }
                }
                // if righthand node of '=' sign doesn't exist in the vector add it
                if (chkFlg == false) nodeVec.push_back(temp);
            }
        }

    }
    return nodeVec;
}

// find the index of the node in the node list
int findInd(vector <string> nodeVec, string nodeName){
    int retInd;
    for (unsigned int i = 0; i < nodeVec.size(); i++){
        if (nodeName ==  nodeVec[i]){
            retInd = i;
        }  
    }
    return retInd;
}

// find the node with minimum distance from the current node
int minDistance(int dist[], bool sptSet[], int V)
{
	// Initialize min value
	int min = INT_MAX, min_index;

	for (int v = 0; v < V; v++)
		if (sptSet[v] == false && dist[v] <= min)
			min = dist[v], min_index = v;

	return min_index;
}

// construct the adjacency matrix and implement Dijkstra's algorithm
void DijkstraCalc (string parsTxt, vector <string> listVec, string src, string dest){
    istringstream parsedTxtStrm(parsTxt);
    string line;

    stringstream ss;
    string out, temp;

    int m,n;
    // initialize adjacency matrix with the size of available nodes
    int AdjM[listVec.size()][listVec.size()];

    for (unsigned int i = 0; i < listVec.size(); i++){
        for (unsigned int j = 0; j < listVec.size(); j++){
            AdjM[i][j] = 0;
        }
    }

    while (getline(parsedTxtStrm, line)){
        ss.clear();
        if (line.find('=') != string::npos){
            ss << line;
            ss >> out;

            m = findInd(listVec, out);

            line = line.substr( line.find('(') + 1, line.find(')') - line.find('(') - 1);
            line = rmvCommas(line);
            ss.clear();
            ss.str("");
            ss << line;
            while (ss >> temp){
                n = findInd(listVec, temp);
                AdjM[n][m] = 1;
            }

        }
    }

    // initialize weight matrix with the value of 0
    int WM[listVec.size()][listVec.size()];
    int w;
    for (unsigned int i = 0; i < listVec.size(); i++){
        
        for (unsigned int j = 0; j < listVec.size(); j++){
            WM[j][i] = 0;
        }
    }

    // initialize weight matrix with actual weight values
    for (unsigned int i = 0; i < listVec.size(); i++){
        w = 0;
        for (unsigned int j = 0; j < listVec.size(); j++){
            if (AdjM[i][j] == 1) w++;
        }
        for (unsigned int j = 0; j < listVec.size(); j++){
            if (AdjM[i][j] == 1) WM[i][j] = w;
        }
    }

    // implementing Dijkstra's Algorithm
    int V = listVec.size();
    int dist[V];
    bool sptSet[V];
    int pred[V];
    for (int i = 0; i < V; i++)
		dist[i] = INT_MAX, sptSet[i] = false, pred[i]= findInd(listVec, src);

    dist[findInd(listVec, src)] = 0;


    for (int count = 0; count < V - 1; count++) {
        int u = minDistance(dist, sptSet, V);
        sptSet[u] = true;
        for (int v = 0; v < V; v++){

            if (!sptSet[v] && WM[u][v]
                && dist[u] != INT_MAX
                && dist[u] + WM[u][v] < dist[v]){
                    dist[v] = dist[u] + WM[u][v];
                    pred[v] = u;
            }
        }
    }

    for(int i=0;i<V;i++)
        if(i!=findInd(listVec, src) && i == findInd(listVec, dest)) {
        cout << "Distance of node " << listVec[i] << " = " << dist[i];
        cout<<"\nPath:\t"<<listVec[i];
        int j=i;
        do{
            j=pred[j];
            cout<<" <- "<<listVec[j];
        }while(j!=findInd(listVec, src));
    }
    cout << endl;
}

int main(int argc, char** argv){

    if (argc != 4) cout << "Incorrect number of arguments" << endl;
    else {
        ifstream inputFile(argv[1]);
        if(!inputFile.good()) cout << "Wrong file name" << endl;
        else{
            string s;
            vector <string> nodeVec;
            s = parseTxt(argv[1]);
            // cout << s;

            bool inChk, outChk;

            inChk = Nodelst(s, "INPUT", argv[2]);
            outChk = Nodelst(s, "OUTPUT", argv[3]);

            // if(inChk && outChk) 
            if (!inChk && !outChk) cout << "Signal " << argv[2] << " and "<< argv[3] << " not found in the file " << argv[1] << endl;
            else if (!inChk) cout << "Signal " << argv[2] << " not found in the file " << argv[1] << endl;
            else if (!outChk) cout << "Signal " << argv[3] << " not found in the file " << argv[1] << endl;
            else {
                nodeVec = parsing2getNodes(s);

                string source(argv[2]);
                string dest(argv[3]);
                
                DijkstraCalc(s, nodeVec, source, dest);
            }
        }
    }

    return 0;
}