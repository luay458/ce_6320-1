#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <climits>
#include <algorithm>
#include <list>
#include <iterator>
#include <stack>

using namespace std;

const int INF = INT_MAX / 2; // To avoid overflow issues

// Structure to represent a gate in the circuit
struct Gate {
    string type;
    int gateDelay;
    list<Gate*> adjacencyList;
    string name;
    vector<string> inputs;
    int fanout;

    Gate(const string& t, const list<Gate*>& al, int gd, const string& n) : type(t), adjacencyList(al), gateDelay(gd), name(n) {}
};

Gate* findGateByName(const list<Gate*>& nodes, const string& name) {
    auto it = find_if(nodes.begin(), nodes.end(),
                           [name](const Gate* node) { return node->name == name; });

    return (it != nodes.end()) ? *it : nullptr;
}

Gate* createGate(const string& type, const list<Gate*>& adjacencyList, int gateDelay, const string& name) {
    return new Gate(type, adjacencyList, gateDelay, name);
}

// Class to represent the circuit and perform Dijkstra's algorithm
class Circuit {
private:
    list<Gate*> nodes;
    unordered_map<string, Gate*> gates;  // Map to store gates by name
    unordered_map<string, int> delays;  // Map to store delay values for each signal

public:
    unordered_map<string, string> parents;

    // Read the circuit description from a file and populate the gates and delays maps
    void readCircuit(const string &fileName) {
        ifstream file(fileName);

        if (!file.is_open()) {
            cout << "Wrong file name" << endl;
            exit(EXIT_FAILURE);
        }

        string line;
        while (getline(file, line)) {
            processLine(line);
        }

        file.close();
    }

    void processLine(string& line) {
        try
        {
            if (!line.empty())
            {
                if (line[0] == '#')
                {
                    // Skip comments
                    return;
                }

                // Process INPUT line
                if (line.find("INPUT") != string::npos)
                {
                    list<Gate *> adjacencyList;
                    size_t startIndex = line.find('(');
                    size_t endIndex = line.find(')');
                    string inputName = line.substr(startIndex + 1, endIndex - startIndex - 1);
                    auto node1 = createGate("INPUT", adjacencyList, 0, inputName);
                    nodes.push_back(node1);
                    gates[inputName] = node1;
                }

                // Process OUTPUT line
                else if (line.find("OUTPUT") != string::npos)
                {
                    list<Gate *> adjacencyList;
                    size_t startIndex = line.find('(');
                    size_t endIndex = line.find(')');
                    string name = line.substr(startIndex + 1, endIndex - startIndex - 1);
                    auto node = createGate("OUTPUT", adjacencyList, 0, name);
                    nodes.push_back(node);
                    gates[name] = node;
                }

                // Process intermediate gate equation
                else
                {
                    list<Gate *> adjacencyList;
                    string input = line;
                    string innerString = " = ";
                    size_t index = input.find(innerString);

                    string intermediateGateName = input.substr(0, index);
                    string inputString = input.substr(index + innerString.length());

                    Gate *node;
                    auto currIntNode = findGateByName(nodes, intermediateGateName);
                    if (currIntNode == nullptr)
                    {
                        node = createGate("INTERMEDIATE", adjacencyList, 0, intermediateGateName);
                        nodes.push_back(node);
                        gates[intermediateGateName] = node;
                    }
                    else
                    {
                        node = currIntNode;
                    }

                    size_t startIndex = inputString.find('(');
                    size_t endIndex = inputString.find(')');

                    if (startIndex != string::npos && endIndex != string::npos && startIndex < endIndex)
                    {
                        string contentInsideBrackets = inputString.substr(startIndex + 1, endIndex - startIndex - 1);
                        replace(contentInsideBrackets.begin(), contentInsideBrackets.end(), ',', ' ');

                        istringstream iss(contentInsideBrackets);
                        vector<string> intermediateInputGates{istream_iterator<string>{iss},
                                                                        istream_iterator<string>{}};

                        for (const auto &gates : intermediateInputGates)
                        {
                            auto targetNode = findGateByName(nodes, gates);
                            if (targetNode != nullptr)
                            {
                                auto newNode = findGateByName(nodes, node->name);
                                targetNode->adjacencyList.push_back(newNode);
                                if (targetNode->type == "OUTPUT")
                                {
                                    targetNode->gateDelay = 0;
                                }
                                else
                                {
                                    targetNode->gateDelay = targetNode->adjacencyList.size();
                                }
                            }
                        }
                    }
                }
                // Debug print the line
                // cout << line << endl;
            }
        }
        catch(const exception& e){
            // cerr << "Error processing line: " << e.what() << endl;
            // cerr << "Line: " << line << endl;
            cout<<"";
        }
    }


    int dijkstra(const string &startNode, const string &endNode) {
        // Priority queue to store nodes with their distance values
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;

        unordered_map<string, int> dist; // Map to store minimum distances from the start node
        const int INF = 1e9;

        // Initialize distances with INF
        for (const auto &entry : gates) {
            dist[entry.first] = INF;
        }

        // Distance from the start node to itself is 0
        dist[startNode] = 0;
        pq.push({0, startNode});

        // Dijkstra's algorithm
        while (!pq.empty()) {
            string current = pq.top().second;
            int currentDist = pq.top().first;
            pq.pop();

            const Gate &currentGate = *gates[current];

            // Update distances for neighboring nodes
            for (const Gate* nextGatePtr : currentGate.adjacencyList) {
                const string &next = nextGatePtr->name; // Modify this based on your Gate structure
                
                if (dist[nextGatePtr->name] > dist[currentGate.name] + currentGate.gateDelay ) {
                    dist[next] = dist[currentGate.name] + currentGate.gateDelay;
                    parents[next] = currentGate.name;
                    pq.push({dist[next], next});
                }
            }
        }

        return dist[endNode];
    }

    // Function to print the path from the source to the destination
    void printPath(const string &startNode, const string &endNode) {
        cout << "Path from " << startNode << " to " << endNode << ": ";

        // Retrieve and store the path using the parent information in a stack
        stack<string> pathStack;
        string currentNode = endNode;
        while (currentNode != startNode) {
            pathStack.push(currentNode);
            currentNode = parents[currentNode];
        }
        pathStack.push(startNode);

        // Print the path in reverse order
        while (!pathStack.empty()) {
            cout << pathStack.top();
            pathStack.pop();
            if (!pathStack.empty()) {
                cout << " -> ";
            }
        }

        cout << endl;
        }
};

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is provided
    if (argc != 4) {
        cout << "Incorrect number of arguments" << endl;
        return EXIT_FAILURE;
    }

    string fileName = argv[1];
    string startNode = argv[2];
    string endNode = argv[3];

    Circuit circuit;

    // Read the circuit description from the file
    circuit.readCircuit(fileName);

    // Calculate the shortest path in terms of delay using Dijkstra's algorithm
    int shortestPath = circuit.dijkstra(startNode, endNode);

    
    // Check if the destination node was found
    if (shortestPath == 1000000000 || shortestPath == 0) {
        cout << "Signal comet not found in file " << fileName<<endl;
        exit(0);
    }
    else {
        // Output the shortest path in terms of delay
        circuit.printPath(startNode, endNode);
        cout << "Shortest path delay from " << startNode << " to " << endNode << ": " << shortestPath << " units" << endl;
    }

    return 0;
}